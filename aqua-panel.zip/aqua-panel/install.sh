#!/bin/bash

###############################################################################
# AQUA PANEL - One-Click Installation Script
# Version: 1.0.0
# For: Ubuntu 20.04/22.04/24.04 & Debian 11/12
# Run: sudo bash install.sh
###############################################################################

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Configuration
PANEL_DIR="/var/www/aqua-panel"
DB_NAME="aqua_panel"
DB_USER="aquapanel"
DB_PASS=$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)
JWT_SECRET=$(openssl rand -base64 32 | tr -dc 'a-zA-Z0-9' | head -c 32)
SESSION_SECRET=$(openssl rand -base64 32 | tr -dc 'a-zA-Z0-9' | head -c 32)
PANEL_PORT=3000
LOG_FILE="/var/log/aqua-panel-install.log"
NGINX_CONF="/etc/nginx/sites-available/aqua-panel"

# Create log file
touch "$LOG_FILE" 2>/dev/null || LOG_FILE="/tmp/aqua-install.log"
exec > >(tee -a "$LOG_FILE") 2>&1

# Banner
clear
echo -e "${CYAN}"
echo "=============================================="
echo "    A Q U A   P A N E L   I N S T A L L E R"
echo "    Premium Minecraft Server Management"
echo "    Version 1.0.0"
echo "=============================================="
echo -e "${NC}"
echo ""

# Check root
if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}[ERROR] This script must be run as root!${NC}"
    echo "Use: sudo bash install.sh"
    exit 1
fi

# Functions
log() { echo -e "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"; }
info() { echo -e "${BLUE}[INFO]${NC} $1"; log "INFO: $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; log "SUCCESS: $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; log "WARN: $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; log "ERROR: $1"; exit 1; }

# Detect OS
detect_os() {
    info "Detecting operating system..."
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
        success "Detected: $OS $VER"
    else
        error "Cannot detect OS. Ubuntu/Debian required."
    fi
}

# Install Node.js 22.x
install_nodejs() {
    info "Installing Node.js 22.x..."
    if command -v node &> /dev/null; then
        NODE_VER=$(node -v)
        warn "Node.js already installed: $NODE_VER"
        return
    fi
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    apt install -y nodejs
    success "Node.js $(node -v) installed"
}

# Install MySQL
install_mysql() {
    info "Installing MySQL Server..."
    if command -v mysql &> /dev/null; then
        success "MySQL already installed"
        return
    fi
    apt install -y mysql-server
    systemctl start mysql
    systemctl enable mysql
    success "MySQL installed"
}

# Install Nginx
install_nginx() {
    info "Installing Nginx..."
    if command -v nginx &> /dev/null; then
        success "Nginx already installed"
        return
    fi
    apt install -y nginx
    systemctl start nginx
    systemctl enable nginx
    success "Nginx installed"
}

# Install PM2
install_pm2() {
    info "Installing PM2..."
    if command -v pm2 &> /dev/null; then
        success "PM2 already installed"
        return
    fi
    npm install -g pm2
    success "PM2 installed"
}

# Setup MySQL Database
setup_database() {
    info "Configuring MySQL Database..."
    
    # Create database
    mysql -e "CREATE DATABASE IF NOT EXISTS $DB_NAME CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null
    
    # Create user
    mysql -e "CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';" 2>/dev/null
    
    # Grant privileges
    mysql -e "GRANT ALL PRIVILEGES ON $DB_NAME.* TO '$DB_USER'@'localhost';" 2>/dev/null
    mysql -e "FLUSH PRIVILEGES;" 2>/dev/null
    
    success "Database configured"
}

# Create directories
create_directories() {
    info "Creating panel directories..."
    mkdir -p "$PANEL_DIR"/{server/{config,routes,middleware,models,database},public/{css,js,images},uploads,logs,backups,ssl}
    success "Directories created"
}

# Create .env file
create_env() {
    info "Creating environment file..."
    cat > "$PANEL_DIR/server/.env" << EOF
PORT=$PANEL_PORT
NODE_ENV=production
APP_NAME=Aqua Panel

DB_HOST=localhost
DB_PORT=3306
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASS
DB_NAME=$DB_NAME

JWT_SECRET=$JWT_SECRET
JWT_EXPIRE=30d
SESSION_SECRET=$SESSION_SECRET

ADMIN_EMAIL=admin@aquapanel.com
ADMIN_PASSWORD=Admin@123

MAX_FILE_SIZE=104857600
UPLOAD_PATH=./uploads
RATE_LIMIT_WINDOW=15
RATE_LIMIT_MAX=100
EOF
    success ".env created"
}

# Create package.json
create_package_json() {
    cat > "$PANEL_DIR/server/package.json" << 'EOF'
{
  "name": "aqua-panel",
  "version": "1.0.0",
  "description": "Aqua Panel - Premium Minecraft Server Management",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "express": "^4.21.0",
    "mysql2": "^3.11.0",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "dotenv": "^16.4.5",
    "cors": "^2.8.5",
    "helmet": "^7.1.0",
    "morgan": "^1.10.0",
    "socket.io": "^4.7.5",
    "express-session": "^1.18.0",
    "compression": "^1.7.4",
    "multer": "^1.4.5-lts.1",
    "uuid": "^10.0.0"
  }
}
EOF
}

# Create server.js
create_server_js() {
    cat > "$PANEL_DIR/server/server.js" << 'EOF'
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const path = require('path');
const session = require('express-session');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(compression());
app.use(morgan('combined'));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: process.env.SESSION_SECRET || 'secret',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 86400000 }
}));

// Static files - serve frontend HTML
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// Serve frontend pages
app.get('/', (req, res) => res.sendFile(path.join(__dirname, '..', 'landing.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, '..', 'register.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, '..', 'login.html')));
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, '..', 'dashboard.html')));
app.get('/console', (req, res) => res.sendFile(path.join(__dirname, '..', 'console.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, '..', 'admin.html')));

// Health check
app.get('/api/health', (req, res) => res.json({ status: 'ok', uptime: process.uptime() }));

// Socket.io
io.on('connection', (socket) => {
    console.log('User connected:', socket.id);
    socket.on('disconnect', () => console.log('User disconnected:', socket.id));
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Aqua Panel running on port ${PORT}`));
EOF
}

# Configure Nginx
configure_nginx() {
    info "Configuring Nginx..."
    cat > "$NGINX_CONF" << EOF
server {
    listen 80;
    server_name _;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:$PANEL_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_cache_bypass \$http_upgrade;
    }
    
    location /socket.io/ {
        proxy_pass http://localhost:$PANEL_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
EOF
    ln -sf "$NGINX_CONF" /etc/nginx/sites-enabled/
    rm -f /etc/nginx/sites-enabled/default
    nginx -t && systemctl reload nginx
    success "Nginx configured"
}

# Configure firewall
configure_firewall() {
    info "Configuring firewall..."
    ufw allow 22/tcp 2>/dev/null
    ufw allow 80/tcp 2>/dev/null
    ufw allow 443/tcp 2>/dev/null
    ufw allow $PANEL_PORT/tcp 2>/dev/null
    ufw --force enable 2>/dev/null
    success "Firewall configured"
}

# Install dependencies and start
install_and_start() {
    info "Installing NPM dependencies..."
    cd "$PANEL_DIR/server"
    npm install --production
    success "Dependencies installed"
    
    info "Starting Aqua Panel with PM2..."
    pm2 delete aqua-panel 2>/dev/null || true
    pm2 start server.js --name aqua-panel --time
    pm2 save
    pm2 startup systemd -u root --hp /root 2>/dev/null
    success "Panel started"
}

# Save credentials
save_credentials() {
    local IP=$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
    cat > /root/aqua-panel-credentials.txt << EOF
============================================
   AQUA PANEL - Installation Complete
============================================

Panel URL: http://$IP
Admin Email: admin@aquapanel.com
Admin Password: Admin@123

Database:
  Name: $DB_NAME
  User: $DB_USER
  Password: $DB_PASS

Installation: $PANEL_DIR
Log: $LOG_FILE

============================================
   FIRST REGISTERED USER = ADMIN
============================================
EOF
    chmod 600 /root/aqua-panel-credentials.txt
}

# Main
main() {
    detect_os
    info "Starting Aqua Panel installation..."
    
    apt update -y && apt upgrade -y
    apt install -y curl wget git unzip build-essential openssl
    
    install_nodejs
    install_mysql
    install_nginx
    install_pm2
    setup_database
    create_directories
    create_env
    create_package_json
    create_server_js
    configure_nginx
    configure_firewall
    install_and_start
    save_credentials
    
    echo ""
    echo -e "${GREEN}============================================${NC}"
    echo -e "${GREEN}   INSTALLATION COMPLETE!${NC}"
    echo -e "${GREEN}============================================${NC}"
    echo ""
    echo -e "Panel URL: ${CYAN}http://$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')${NC}"
    echo -e "Admin: ${CYAN}admin@aquapanel.com${NC}"
    echo -e "Password: ${CYAN}Admin@123${NC}"
    echo ""
    echo -e "Credentials saved: ${YELLOW}/root/aqua-panel-credentials.txt${NC}"
    echo ""
    echo "Commands:"
    echo "  pm2 status              - Check status"
    echo "  pm2 logs aqua-panel     - View logs"
    echo "  pm2 restart aqua-panel  - Restart"
    echo ""
}

# Run
main "$@"