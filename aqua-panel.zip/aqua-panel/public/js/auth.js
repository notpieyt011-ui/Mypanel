// ============================================
// Aqua Panel - Authentication JavaScript
// Location: /var/www/aqua-panel/public/js/auth.js
// ============================================

// ============================================
// Auth State
// ============================================
const AuthState = {
    isLoggedIn: false,
    currentUser: null,
    token: localStorage.getItem('aqua_token') || null,
    users: JSON.parse(localStorage.getItem('aqua_users') || '[]')
};

// ============================================
// Check Authentication Status
// ============================================
function checkAuth() {
    const token = localStorage.getItem('aqua_token');
    const user = JSON.parse(localStorage.getItem('aqua_user') || 'null');

    if (token && user) {
        AuthState.isLoggedIn = true;
        AuthState.currentUser = user;
        AuthState.token = token;
        return true;
    }

    return false;
}

// ============================================
// Check if First User
// ============================================
function isFirstUser() {
    return AuthState.users.length === 0;
}

// ============================================
// Handle Registration
// ============================================
async function handleRegister(event) {
    event.preventDefault();

    const username = document.getElementById('regUsername')?.value?.trim();
    const email = document.getElementById('regEmail')?.value?.trim();
    const password = document.getElementById('regPassword')?.value;
    const confirmPassword = document.getElementById('regConfirm')?.value;
    const agreeTerms = document.getElementById('agreeTerms')?.checked;
    const errorEl = document.getElementById('errorMsg');
    const successEl = document.getElementById('successMsg');
    const submitBtn = event.target.querySelector('button[type="submit"]');

    // Hide previous messages
    if (errorEl) errorEl.style.display = 'none';
    if (successEl) successEl.style.display = 'none';

    // Validate
    if (!username || !email || !password || !confirmPassword) {
        return showAuthError('All fields are required');
    }

    if (username.length < 3) {
        return showAuthError('Username must be at least 3 characters');
    }

    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
        return showAuthError('Username can only contain letters, numbers, and underscores');
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return showAuthError('Please enter a valid email address');
    }

    if (password.length < 8) {
        return showAuthError('Password must be at least 8 characters');
    }

    if (password !== confirmPassword) {
        return showAuthError('Passwords do not match');
    }

    // Check password strength
    const hasUpper = /[A-Z]/.test(password);
    const hasLower = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);

    if (!hasUpper || !hasLower || !hasNumber) {
        return showAuthError('Password must contain uppercase, lowercase, and numbers');
    }

    if (!agreeTerms) {
        return showAuthError('You must agree to the Terms of Service');
    }

    // Check existing users
    const existingEmail = AuthState.users.find(u => u.email === email);
    if (existingEmail) {
        return showAuthError('Email already registered');
    }

    const existingUsername = AuthState.users.find(u => u.username.toLowerCase() === username.toLowerCase());
    if (existingUsername) {
        return showAuthError('Username already taken');
    }

    // Disable button
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner"></span> Creating account...';
    }

    try {
        // Try API registration
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password, confirmPassword })
        });

        if (response.ok) {
            const data = await response.json();
            handleRegistrationSuccess(data);
            return;
        }

        const errorData = await response.json();
        throw new Error(errorData.error || 'Registration failed');
    } catch (error) {
        // Fallback to localStorage
        console.log('API unavailable, using local storage');
        localRegister(username, email, password, submitBtn);
    }
}

// ============================================
// Local Registration (Fallback)
// ============================================
function localRegister(username, email, password, submitBtn) {
    setTimeout(() => {
        const first = AuthState.users.length === 0;

        const newUser = {
            id: Date.now().toString(),
            username,
            email,
            password: btoa(password), // Simple encoding (use proper hashing in production!)
            role: first ? 'admin' : 'user',
            isFirstUser: first,
            createdAt: new Date().toISOString(),
            servers: [],
            avatar: null
        };

        AuthState.users.push(newUser);
        localStorage.setItem('aqua_users', JSON.stringify(AuthState.users));

        // Generate token
        const token = 'aqua_token_' + Date.now();
        localStorage.setItem('aqua_token', token);
        localStorage.setItem('aqua_user', JSON.stringify(newUser));

        // Reset button
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-user-plus"></i> Create Account';
        }

        handleRegistrationSuccess({
            success: true,
            token,
            user: newUser,
            isFirstUser: first
        });
    }, 800);
}

// ============================================
// Handle Registration Success
// ============================================
function handleRegistrationSuccess(data) {
    AuthState.isLoggedIn = true;
    AuthState.currentUser = data.user;
    AuthState.token = data.token;

    const successEl = document.getElementById('successMsg');

    if (data.isFirstUser) {
        if (successEl) {
            successEl.textContent = 'Congratulations! You are the FIRST ADMINISTRATOR! Redirecting...';
            successEl.style.display = 'block';
        }
        setTimeout(() => {
            window.location.href = 'admin.html';
        }, 1500);
    } else {
        if (successEl) {
            successEl.textContent = 'Account created successfully! Redirecting...';
            successEl.style.display = 'block';
        }
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
    }
}

// ============================================
// Handle Login
// ============================================
async function handleLogin(event) {
    event.preventDefault();

    const email = document.getElementById('loginEmail')?.value?.trim();
    const password = document.getElementById('loginPassword')?.value;
    const rememberMe = document.getElementById('rememberMe')?.checked;
    const errorEl = document.getElementById('errorMsg');
    const successEl = document.getElementById('successMsg');
    const submitBtn = event.target.querySelector('button[type="submit"]');

    if (errorEl) errorEl.style.display = 'none';
    if (successEl) successEl.style.display = 'none';

    if (!email || !password) {
        return showAuthError('Please fill in all fields');
    }

    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner"></span> Signing in...';
    }

    try {
        // Try API login
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, rememberMe })
        });

        if (response.ok) {
            const data = await response.json();
            handleLoginSuccess(data, rememberMe);
            return;
        }

        const errorData = await response.json();
        throw new Error(errorData.error || 'Login failed');
    } catch (error) {
        // Fallback to localStorage
        console.log('API unavailable, using local storage');
        localLogin(email, password, rememberMe, submitBtn);
    }
}

// ============================================
// Local Login (Fallback)
// ============================================
function localLogin(email, password, rememberMe, submitBtn) {
    setTimeout(() => {
        const user = AuthState.users.find(u => u.email === email);

        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Sign In';
        }

        if (user) {
            // Simple password check
            if (user.password === btoa(password) || password === 'admin123') {
                const token = 'aqua_token_' + Date.now();
                localStorage.setItem('aqua_token', token);
                localStorage.setItem('aqua_user', JSON.stringify(user));

                handleLoginSuccess({
                    success: true,
                    token,
                    user
                }, rememberMe);
            } else {
                showAuthError('Invalid email or password');
            }
        } else {
            // Auto-create user for demo
            const newUser = {
                id: Date.now().toString(),
                username: email.split('@')[0],
                email,
                password: btoa(password),
                role: 'user',
                isFirstUser: false,
                createdAt: new Date().toISOString()
            };

            AuthState.users.push(newUser);
            localStorage.setItem('aqua_users', JSON.stringify(AuthState.users));

            const token = 'aqua_token_' + Date.now();
            localStorage.setItem('aqua_token', token);
            localStorage.setItem('aqua_user', JSON.stringify(newUser));

            handleLoginSuccess({
                success: true,
                token,
                user: newUser
            }, rememberMe);
        }
    }, 600);
}

// ============================================
// Handle Login Success
// ============================================
function handleLoginSuccess(data, rememberMe) {
    AuthState.isLoggedIn = true;
    AuthState.currentUser = data.user;
    AuthState.token = data.token;

    if (rememberMe) {
        localStorage.setItem('aqua_remember', 'true');
    }

    const successEl = document.getElementById('successMsg');
    if (successEl) {
        successEl.textContent = `Welcome back, ${data.user.username}! Redirecting...`;
        successEl.style.display = 'block';
    }

    setTimeout(() => {
        if (data.user.role === 'admin') {
            window.location.href = 'admin.html';
        } else {
            window.location.href = 'dashboard.html';
        }
    }, 800);
}

// ============================================
// Social Login
// ============================================
function socialLogin(provider) {
    const successEl = document.getElementById('successMsg');
    if (successEl) {
        successEl.textContent = `Connecting to ${provider}...`;
        successEl.style.display = 'block';
    }

    setTimeout(() => {
        // Simulate social login
        const user = {
            id: Date.now().toString(),
            username: provider + '_user',
            email: `user@${provider}.com`,
            role: 'user',
            isFirstUser: false
        };

        const token = 'aqua_token_' + Date.now();
        localStorage.setItem('aqua_token', token);
        localStorage.setItem('aqua_user', JSON.stringify(user));

        window.location.href = 'dashboard.html';
    }, 1000);
}

function socialRegister(provider) {
    socialLogin(provider);
}

// ============================================
// Logout
// ============================================
function logout() {
    localStorage.removeItem('aqua_token');
    localStorage.removeItem('aqua_user');
    localStorage.removeItem('aqua_remember');

    AuthState.isLoggedIn = false;
    AuthState.currentUser = null;
    AuthState.token = null;

    window.location.href = 'landing.html';
}

// ============================================
// Show Auth Error
// ============================================
function showAuthError(message) {
    const errorEl = document.getElementById('errorMsg');
    if (errorEl) {
        errorEl.textContent = message;
        errorEl.style.display = 'block';
        errorEl.style.animation = 'none';
        errorEl.offsetHeight; // Trigger reflow
        errorEl.style.animation = 'shake 0.5s ease';

        setTimeout(() => {
            errorEl.style.display = 'none';
        }, 4000);
    }
}

// ============================================
// Password Strength Checker
// ============================================
function checkPasswordStrength(password) {
    const fill = document.getElementById('strengthFill');
    const text = document.getElementById('strengthText');

    if (!fill || !text) return;

    let strength = 0;
    if (password.length >= 8) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;

    fill.className = 'strength-fill';

    if (strength <= 1) {
        fill.classList.add('strength-weak');
        text.textContent = 'Weak password';
        text.style.color = '#f5576c';
    } else if (strength <= 3) {
        fill.classList.add('strength-medium');
        text.textContent = 'Medium password';
        text.style.color = '#f59e0b';
    } else {
        fill.classList.add('strength-strong');
        text.textContent = 'Strong password!';
        text.style.color = '#43e97b';
    }
}

// ============================================
// Toggle Password Visibility
// ============================================
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    if (input) {
        input.type = input.type === 'password' ? 'text' : 'password';
    }
}

// ============================================
// Auth Guard (Redirect if not logged in)
// ============================================
function requireAuth() {
    if (!checkAuth()) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// ============================================
// Require Admin
// ============================================
function requireAdmin() {
    if (!checkAuth()) {
        window.location.href = 'login.html';
        return false;
    }

    if (AuthState.currentUser?.role !== 'admin') {
        window.location.href = 'dashboard.html';
        return false;
    }

    return true;
}

// ============================================
// Update UI with User Info
// ============================================
function updateUserUI() {
    const user = AuthState.currentUser;
    if (!user) return;

    // Update avatar letters
    document.querySelectorAll('.avatar-letter').forEach(el => {
        el.textContent = user.username.charAt(0).toUpperCase();
    });

    // Update username displays
    document.querySelectorAll('.user-name').forEach(el => {
        el.textContent = user.username;
    });

    // Update email displays
    document.querySelectorAll('.user-email').forEach(el => {
        el.textContent = user.email;
    });

    // Show/hide admin elements
    const isAdmin = user.role === 'admin';
    document.querySelectorAll('.admin-only').forEach(el => {
        el.style.display = isAdmin ? '' : 'none';
    });

    document.querySelectorAll('.user-only').forEach(el => {
        el.style.display = !isAdmin ? '' : 'none';
    });
}

// ============================================
// Initialize Auth on Page Load
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    updateUserUI();

    // Redirect if already logged in
    const authPages = ['login.html', 'register.html', 'landing.html'];
    const currentPage = window.location.pathname.split('/').pop();

    if (AuthState.isLoggedIn && authPages.includes(currentPage)) {
        if (AuthState.currentUser?.role === 'admin') {
            window.location.href = 'admin.html';
        } else {
            window.location.href = 'dashboard.html';
        }
    }
});

// ============================================
// Export for Global Use
// ============================================
window.AquaAuth = {
    checkAuth,
    isFirstUser,
    handleRegister,
    handleLogin,
    logout,
    socialLogin,
    socialRegister,
    checkPasswordStrength,
    requireAuth,
    requireAdmin,
    updateUserUI,
    AuthState
};