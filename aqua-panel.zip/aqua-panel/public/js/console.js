// ============================================
// Aqua Panel - Console JavaScript
// Location: /var/www/aqua-panel/public/js/console.js
// ============================================

// ============================================
// Console State
// ============================================
const ConsoleState = {
    serverId: null,
    serverName: 'Survival SMP',
    serverIP: '192.168.1.100:25565',
    currentTab: 'console',
    isConnected: false,
    commandHistory: [],
    historyIndex: -1,
    autoScroll: true,
    socket: null
};

// ============================================
// Console Initialization
// ============================================
function initConsole() {
    // Auto-scroll console output
    const consoleOutput = document.getElementById('consoleOutput');
    if (consoleOutput) {
        consoleOutput.scrollTop = consoleOutput.scrollHeight;

        // Detect manual scroll to disable auto-scroll
        consoleOutput.addEventListener('scroll', () => {
            const isAtBottom = consoleOutput.scrollHeight - consoleOutput.scrollTop === consoleOutput.clientHeight;
            ConsoleState.autoScroll = isAtBottom;
        });
    }

    // Focus command input
    const commandInput = document.getElementById('consoleInput');
    if (commandInput) {
        commandInput.focus();

        // Click anywhere in console to focus input
        document.querySelector('.console-output')?.addEventListener('click', () => {
            commandInput.focus();
        });
    }

    // Connect to WebSocket (if available)
    connectWebSocket();

    // Load server stats
    loadServerStats();

    // Add sample console messages
    addSampleMessages();

    console.log('Console initialized for server:', ConsoleState.serverName);
}

// ============================================
// WebSocket Connection
// ============================================
function connectWebSocket() {
    try {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/socket.io/`;

        ConsoleState.socket = io(wsUrl, {
            transports: ['websocket', 'polling']
        });

        ConsoleState.socket.on('connect', () => {
            ConsoleState.isConnected = true;
            addConsoleLine('system', 'Connected to server WebSocket');
        });

        ConsoleState.socket.on('disconnect', () => {
            ConsoleState.isConnected = false;
            addConsoleLine('error', 'Disconnected from server');
        });

        ConsoleState.socket.on('console-output', (data) => {
            addConsoleLine(data.type || 'info', data.message);
        });

        ConsoleState.socket.on('server-stats', (stats) => {
            updateServerStats(stats);
        });

        ConsoleState.socket.on('player-join', (player) => {
            addConsoleLine('player', `${player} joined the game`);
        });

        ConsoleState.socket.on('player-leave', (player) => {
            addConsoleLine('player', `${player} left the game`);
        });

    } catch (error) {
        console.log('WebSocket not available, running in offline mode');
    }
}

// ============================================
// Tab Management
// ============================================
function switchTab(tabName, buttonElement) {
    // Update tab buttons
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });

    if (buttonElement) {
        buttonElement.classList.add('active');
    }

    // Hide all tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.style.display = 'none';
    });

    // Show selected tab content
    const targetTab = document.getElementById('tab-' + tabName);
    if (targetTab) {
        targetTab.style.display = 'block';
    }

    // Show/hide console based on tab
    const consoleSection = document.querySelector('.console-section');
    if (consoleSection) {
        consoleSection.style.display = (tabName === 'console') ? 'flex' : 'none';
    }

    // Show/hide status panel
    const statusPanel = document.getElementById('statusPanel');
    if (statusPanel) {
        statusPanel.style.display = (tabName === 'console') ? 'flex' : 'flex';
    }

    ConsoleState.currentTab = tabName;

    // Load tab-specific data
    switch (tabName) {
        case 'players':
            loadPlayerList();
            break;
        case 'files':
            loadFileList();
            break;
        case 'backups':
            loadBackupList();
            break;
        case 'plugins':
            loadPluginList();
            break;
    }
}

// ============================================
// Command Handling
// ============================================
function sendCommand() {
    const input = document.getElementById('consoleInput');
    if (!input) return;

    const command = input.value.trim();
    if (!command) return;

    // Add to history
    ConsoleState.commandHistory.push(command);
    ConsoleState.historyIndex = ConsoleState.commandHistory.length;

    // Display command in console
    addConsoleLine('command', `> ${command}`);

    // Process command
    processCommand(command);

    // Clear input
    input.value = '';
    input.focus();
}

function processCommand(command) {
    const cmd = command.toLowerCase().split(' ')[0];
    const args = command.split(' ').slice(1);

    // Simulate command responses
    const responses = {
        'help': 'Available commands: help, list, say, kick, ban, op, deop, save, stop, reload, time, weather, gamemode, tp, give, version, plugins, tps, status',
        'list': 'Online players (8): Player123, BuildMaster, CraftQueen, MinePro99, RedstoneKing, DiamondHunter, NetherExplorer, FarmMaster',
        'version': 'This server is running Paper 1.21.11 (MC: 1.21.11)',
        'tps': 'TPS from last 1m, 5m, 15m: 19.8, 19.5, 19.2',
        'status': `Server: ${ConsoleState.serverName}\nStatus: Online\nIP: ${ConsoleState.serverIP}\nPlayers: 8/50\nUptime: 3h 24m`,
        'plugins': 'Plugins (4): EssentialsX, WorldEdit, LuckPerms, Vault',
        'save': 'Saving world...\nWorld saved successfully.',
        'time': 'Current time: 1000 (day)',
        'weather': 'Current weather: clear',
        'say': args.length > 0 ? `[Server] ${args.join(' ')}` : 'Usage: say <message>',
        'kick': args.length > 0 ? `Kicked ${args[0]} from the server` : 'Usage: kick <player>',
        'ban': args.length > 0 ? `Banned ${args[0]} from the server` : 'Usage: ban <player>',
        'op': args.length > 0 ? `Made ${args[0]} a server operator` : 'Usage: op <player>',
        'deop': args.length > 0 ? `Removed ${args[0]} from server operators` : 'Usage: deop <player>',
        'gamemode': args.length >= 2 ? `Set ${args[1]}'s game mode to ${args[0]}` : 'Usage: gamemode <mode> [player]',
        'tp': args.length >= 2 ? `Teleported ${args[0]} to ${args[1]}` : 'Usage: tp <player> <target>',
        'give': args.length >= 3 ? `Gave ${args[2]} ${args[1]} to ${args[0]}` : 'Usage: give <player> <item> [amount]',
        'stop': 'Stopping server...\nServer stopped.',
        'reload': 'Reloading server...\nServer reloaded successfully.',
    };

    // Find response
    let response = null;
    if (responses[cmd]) {
        response = typeof responses[cmd] === 'function' ? responses[cmd](args) : responses[cmd];
    } else if (cmd.startsWith('/')) {
        response = `Unknown command: ${cmd}. Type "help" for help.`;
    } else {
        response = `Command executed: ${command}`;
    }

    // Add response to console
    if (response) {
        setTimeout(() => {
            const lines = response.split('\n');
            lines.forEach(line => {
                addConsoleLine('info', line);
            });
        }, 200);
    }

    // Send to server if connected
    if (ConsoleState.isConnected && ConsoleState.socket) {
        ConsoleState.socket.emit('console-command', { command });
    }
}

// ============================================
// Console Output
// ============================================
function addConsoleLine(type, message) {
    const output = document.getElementById('consoleOutput');
    if (!output) return;

    const line = document.createElement('div');
    line.className = `line c-${type}`;

    const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
    line.textContent = `[${timestamp}] ${message}`;

    output.appendChild(line);

    // Auto-scroll
    if (ConsoleState.autoScroll) {
        output.scrollTop = output.scrollHeight;
    }
}

function addSampleMessages() {
    const messages = [
        { type: 'system', text: 'Starting minecraft server version 1.21.11' },
        { type: 'system', text: 'Loading properties' },
        { type: 'system', text: 'Default game type: SURVIVAL' },
        { type: 'system', text: 'Generating keypair' },
        { type: 'system', text: 'Starting Minecraft server on *:25565' },
        { type: 'info', text: 'Preparing level "world"' },
        { type: 'info', text: 'Preparing start region for dimension minecraft:overworld' },
        { type: 'info', text: 'Time elapsed: 3456 ms' },
        { type: 'info', text: 'Done (6.123s)! For help, type "help"' },
        { type: 'player', text: 'Player123 joined the game' },
        { type: 'player', text: 'BuildMaster joined the game' },
        { type: 'player', text: 'CraftQueen joined the game' },
        { type: 'command', text: 'Player123 issued server command: /time set day' },
        { type: 'info', text: 'Set the time to 1000' },
        { type: 'player', text: 'MinePro99 joined the game' },
        { type: 'warn', text: "Can't keep up! Is the server overloaded? Running 2145ms behind" },
        { type: 'player', text: 'Player123: hey everyone!' },
        { type: 'player', text: 'BuildMaster: hello!' },
        { type: 'player', text: 'RedstoneKing joined the game' },
        { type: 'info', text: 'Auto-save started' },
        { type: 'info', text: 'Auto-save complete' },
    ];

    messages.forEach(msg => {
        addConsoleLine(msg.type, msg.text);
    });
}

// ============================================
// Server Stats
// ============================================
function loadServerStats() {
    // Simulated stats - replace with API call
    const stats = {
        cpu: 45,
        ram: { used: 2560, total: 4096 },
        disk: { used: 15360, total: 51200 },
        players: { online: 8, max: 50 },
        uptime: '3h 24m',
        tps: 19.8
    };

    updateServerStats(stats);
}

function updateServerStats(stats) {
    // Update CPU
    const cpuEl = document.querySelector('.stats-bar .val');
    if (cpuEl && stats.cpu !== undefined) {
        cpuEl.textContent = stats.cpu + '%';
    }

    // Update RAM
    const ramEls = document.querySelectorAll('.stats-bar .val');
    if (ramEls[1] && stats.ram) {
        ramEls[1].textContent = `${(stats.ram.used / 1024).toFixed(1)}GB / ${(stats.ram.total / 1024).toFixed(0)}GB`;
    }

    // Update Players
    if (ramEls[3] && stats.players) {
        ramEls[3].textContent = `${stats.players.online}/${stats.players.max}`;
    }

    // Update Uptime
    if (ramEls[4] && stats.uptime) {
        ramEls[4].textContent = stats.uptime;
    }

    // Update TPS
    if (ramEls[5] && stats.tps) {
        ramEls[5].textContent = stats.tps;
    }

    // Update status panel bars
    updateResourceBar('ram', stats.ram ? (stats.ram.used / stats.ram.total * 100) : 0);
    updateResourceBar('cpu', stats.cpu || 0);
    updateResourceBar('disk', stats.disk ? (stats.disk.used / stats.disk.total * 100) : 0);
}

function updateResourceBar(type, percentage) {
    const fill = document.querySelector(`.fill-${type}`);
    if (fill) {
        fill.style.width = percentage + '%';
    }
}

// ============================================
// Power Actions
// ============================================
function powerAction(action) {
    const actions = {
        start: { message: 'Starting server...', status: 'starting' },
        stop: { message: 'Stopping server...', status: 'stopping' },
        restart: { message: 'Restarting server...', status: 'restarting' },
        kill: { message: 'Force killing server...', status: 'stopped' }
    };

    const actionData = actions[action];
    if (!actionData) return;

    addConsoleLine('system', actionData.message);

    // Send to server if connected
    if (ConsoleState.isConnected && ConsoleState.socket) {
        ConsoleState.socket.emit('server-power', { action });
    }

    // Show toast
    showToast(actionData.message, 'info');

    // Update status after delay
    setTimeout(() => {
        if (action === 'stop' || action === 'kill') {
            addConsoleLine('system', 'Server stopped.');
            updateServerStatus('offline');
        } else if (action === 'start') {
            addConsoleLine('system', 'Server started successfully!');
            updateServerStatus('online');
        } else if (action === 'restart') {
            addConsoleLine('system', 'Server restarted successfully!');
            updateServerStatus('online');
        }
    }, 2000);
}

function updateServerStatus(status) {
    const statusDot = document.querySelector('.status-dot');
    const statusText = document.querySelector('.panel-box p');

    if (statusDot) {
        statusDot.className = 'status-dot';
        if (status === 'online') {
            statusDot.style.background = '#43e97b';
            statusDot.style.boxShadow = '0 0 10px #43e97b';
        } else {
            statusDot.style.background = '#f5576c';
            statusDot.style.boxShadow = 'none';
        }
    }

    if (statusText) {
        statusText.textContent = status === 'online' ? 'Online' : 'Offline';
        statusText.style.color = status === 'online' ? '#43e97b' : '#f5576c';
    }
}

// ============================================
// Player Management
// ============================================
function loadPlayerList() {
    const players = [
        { name: 'Player123', playtime: '2h', avatar: 'P' },
        { name: 'BuildMaster', playtime: '1.5h', avatar: 'B' },
        { name: 'CraftQueen', playtime: '1h', avatar: 'C' },
        { name: 'MinePro99', playtime: '45m', avatar: 'M' },
        { name: 'RedstoneKing', playtime: '30m', avatar: 'R' },
        { name: 'DiamondHunter', playtime: '25m', avatar: 'D' },
        { name: 'NetherExplorer', playtime: '20m', avatar: 'N' },
        { name: 'FarmMaster', playtime: '15m', avatar: 'F' },
    ];

    const playerList = document.getElementById('playerList');
    if (!playerList) return;

    playerList.innerHTML = players.map(player => `
        <div class="player-item">
            <div style="width:24px;height:24px;border-radius:6px;background:var(--gradient-1);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;">
                ${player.avatar}
            </div>
            <div>
                <strong>${player.name}</strong>
                <br><small style="color:var(--text-secondary);">Playing for ${player.playtime}</small>
            </div>
            <div class="item-actions">
                <button class="btn-item" style="background:#f5576c;" onclick="playerAction('kick', '${player.name}')">Kick</button>
                <button class="btn-item" style="background:#ef4444;" onclick="playerAction('ban', '${player.name}')">Ban</button>
                <button class="btn-item" style="background:#f59e0b;" onclick="playerAction('op', '${player.name}')">OP</button>
            </div>
        </div>
    `).join('');
}

function playerAction(action, playerName) {
    switch (action) {
        case 'kick':
            addConsoleLine('system', `Kicking ${playerName}...`);
            sendCommandToConsole(`kick ${playerName}`);
            showToast(`Kicked ${playerName}`, 'error');
            break;
        case 'ban':
            addConsoleLine('system', `Banning ${playerName}...`);
            sendCommandToConsole(`ban ${playerName}`);
            showToast(`Banned ${playerName}`, 'error');
            break;
        case 'op':
            addConsoleLine('system', `Opping ${playerName}...`);
            sendCommandToConsole(`op ${playerName}`);
            showToast(`Opped ${playerName}`, 'success');
            break;
    }
}

function sendCommandToConsole(command) {
    const input = document.getElementById('consoleInput');
    if (input) {
        input.value = command;
        sendCommand();
    }
}

// ============================================
// File Management
// ============================================
function loadFileList() {
    const files = [
        { name: 'plugins/', type: 'folder', size: '4 items' },
        { name: 'world/', type: 'folder', size: '-' },
        { name: 'world_nether/', type: 'folder', size: '-' },
        { name: 'world_the_end/', type: 'folder', size: '-' },
        { name: 'server.properties', type: 'file', size: '2.4 KB' },
        { name: 'bukkit.yml', type: 'file', size: '1.8 KB' },
        { name: 'spigot.yml', type: 'file', size: '3.2 KB' },
        { name: 'eula.txt', type: 'file', size: '0.5 KB' },
        { name: 'ops.json', type: 'file', size: '0.2 KB' },
        { name: 'whitelist.json', type: 'file', size: '0.3 KB' },
    ];

    const fileList = document.getElementById('fileList');
    if (!fileList) return;

    fileList.innerHTML = files.map(file => `
        <div class="file-item">
            <i class="fas fa-${file.type === 'folder' ? 'folder' : 'file'}" 
               style="color:${file.type === 'folder' ? '#f59e0b' : '#4facfe'};"></i>
            <span>${file.name}</span>
            <span style="margin-left:auto;font-size:10px;color:var(--text-secondary);">${file.size}</span>
        </div>
    `).join('');
}

// ============================================
// Backup Management
// ============================================
function loadBackupList() {
    const backups = [
        { name: 'backup-2025-05-20.zip', size: '245 MB', date: '2025-05-20' },
        { name: 'backup-2025-05-19.zip', size: '238 MB', date: '2025-05-19' },
        { name: 'backup-2025-05-18.zip', size: '240 MB', date: '2025-05-18' },
    ];

    const backupList = document.getElementById('backupList');
    if (!backupList) return;

    backupList.innerHTML = backups.map(backup => `
        <div class="file-item">
            <i class="fas fa-archive" style="color:#f59e0b;"></i>
            <span>${backup.name}</span>
            <span style="margin-left:auto;font-size:10px;color:var(--text-secondary);">${backup.size}</span>
            <div class="item-actions">
                <button class="btn-item" style="background:var(--gradient-3);">Download</button>
                <button class="btn-item" style="background:#f59e0b;">Restore</button>
                <button class="btn-item" style="background:#f5576c;">Delete</button>
            </div>
        </div>
    `).join('');
}

// ============================================
// Plugin Management
// ============================================
function loadPluginList() {
    const plugins = [
        { name: 'EssentialsX', version: '2.20.1', status: 'active' },
        { name: 'WorldEdit', version: '7.2.15', status: 'active' },
        { name: 'LuckPerms', version: '5.4.102', status: 'active' },
        { name: 'Vault', version: '1.7.3', status: 'active' },
    ];

    const pluginList = document.getElementById('pluginList');
    if (!pluginList) return;

    pluginList.innerHTML = plugins.map(plugin => `
        <div class="file-item">
            <i class="fas fa-plug" style="color:#43e97b;"></i>
            <span>${plugin.name} <small style="color:var(--text-secondary);">v${plugin.version}</small></span>
            <div class="item-actions">
                <button class="btn-item" style="background:#f5576c;">Disable</button>
                <button class="btn-item" style="background:#ef4444;">Remove</button>
            </div>
        </div>
    `).join('');
}

// ============================================
// Copy IP
// ============================================
function copyIP() {
    const ip = ConsoleState.serverIP;
    if (navigator.clipboard) {
        navigator.clipboard.writeText(ip).then(() => {
            showToast('IP Copied: ' + ip, 'success');
        });
    } else {
        const textarea = document.createElement('textarea');
        textarea.value = ip;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast('IP Copied: ' + ip, 'success');
    }
}

// ============================================
// Toast Notification
// ============================================
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) {
        const ctr = document.createElement('div');
        ctr.id = 'toastContainer';
        ctr.className = 'toast-container';
        document.body.appendChild(ctr);
    }

    const toastContainer = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(-10px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 2500);
}

// ============================================
// Mobile Panel Toggle
// ============================================
function toggleSidePanel() {
    const panel = document.getElementById('statusPanel');
    if (panel) {
        panel.classList.toggle('open');
    }
}

// ============================================
// Keyboard Shortcuts
// ============================================
document.addEventListener('keydown', (e) => {
    // Tab to focus command input
    if (e.key === 'Tab' && ConsoleState.currentTab === 'console') {
        e.preventDefault();
        const input = document.getElementById('consoleInput');
        if (input) input.focus();
    }

    // Ctrl+L to clear console
    if (e.ctrlKey && e.key === 'l') {
        e.preventDefault();
        const output = document.getElementById('consoleOutput');
        if (output) output.innerHTML = '';
    }

    // Up arrow for command history
    if (e.key === 'ArrowUp' && document.activeElement?.id === 'consoleInput') {
        e.preventDefault();
        if (ConsoleState.historyIndex > 0) {
            ConsoleState.historyIndex--;
            document.getElementById('consoleInput').value = 
                ConsoleState.commandHistory[ConsoleState.historyIndex];
        }
    }

    // Down arrow for command history
    if (e.key === 'ArrowDown' && document.activeElement?.id === 'consoleInput') {
        e.preventDefault();
        if (ConsoleState.historyIndex < ConsoleState.commandHistory.length - 1) {
            ConsoleState.historyIndex++;
            document.getElementById('consoleInput').value = 
                ConsoleState.commandHistory[ConsoleState.historyIndex];
        } else {
            ConsoleState.historyIndex = ConsoleState.commandHistory.length;
            document.getElementById('consoleInput').value = '';
        }
    }
});

// ============================================
// Initialize on Page Load
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    initConsole();

    // Check mobile
    if (window.innerWidth <= 768) {
        const mobileBtn = document.getElementById('mobilePanelBtn');
        if (mobileBtn) {
            mobileBtn.style.display = 'flex';
            mobileBtn.style.alignItems = 'center';
            mobileBtn.style.justifyContent = 'center';
        }
    }
});

// Handle window resize
window.addEventListener('resize', () => {
    const mobileBtn = document.getElementById('mobilePanelBtn');
    if (mobileBtn) {
        if (window.innerWidth <= 768) {
            mobileBtn.style.display = 'flex';
        } else {
            mobileBtn.style.display = 'none';
            const panel = document.getElementById('statusPanel');
            if (panel) panel.classList.remove('open');
        }
    }
});

// ============================================
// Export for Global Use
// ============================================
window.AquaConsole = {
    switchTab,
    sendCommand,
    powerAction,
    playerAction,
    copyIP,
    toggleSidePanel,
    showToast,
    ConsoleState
};