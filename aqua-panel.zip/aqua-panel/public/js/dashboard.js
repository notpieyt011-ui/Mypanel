// ============================================
// Aqua Panel - Dashboard JavaScript
// Location: /var/www/aqua-panel/public/js/dashboard.js
// ============================================

// ============================================
// Dashboard State
// ============================================
const DashboardState = {
    servers: [],
    stats: {
        total: 0,
        active: 0,
        health: 'Good',
        avgUsage: 0
    },
    isLoading: false,
    searchQuery: '',
    currentUser: JSON.parse(localStorage.getItem('aqua_user') || 'null')
};

// ============================================
// Dashboard Initialization
// ============================================
function initDashboard() {
    console.log('Initializing Aqua Panel Dashboard...');
    
    // Load user info
    loadUserInfo();
    
    // Load servers
    loadServers();
    
    // Load stats
    loadStats();
    
    // Setup search
    setupSearch();
    
    // Setup real-time updates
    setupRealTimeUpdates();
    
    // Check admin status
    checkAdminStatus();
}

// ============================================
// User Info
// ============================================
function loadUserInfo() {
    const user = DashboardState.currentUser;
    if (!user) {
        window.location.href = 'login.html';
        return;
    }

    // Update welcome message
    const welcomeMsg = document.getElementById('welcomeMsg');
    if (welcomeMsg) {
        welcomeMsg.textContent = `Welcome back, ${user.username}!`;
    }

    // Update avatar letters
    document.querySelectorAll('.avatar-letter, .user-initial').forEach(el => {
        el.textContent = user.username.charAt(0).toUpperCase();
    });

    // Update username displays
    document.querySelectorAll('.user-name-display').forEach(el => {
        el.textContent = user.username;
    });

    // Update email displays
    document.querySelectorAll('.user-email-display').forEach(el => {
        el.textContent = user.email;
    });
}

// ============================================
// Check Admin Status
// ============================================
function checkAdminStatus() {
    const user = DashboardState.currentUser;
    const isAdmin = user?.role === 'admin';

    // Show/hide admin elements
    document.querySelectorAll('.admin-only').forEach(el => {
        el.style.display = isAdmin ? '' : 'none';
    });

    // Admin header button
    const adminBtn = document.getElementById('adminHeaderBtn');
    if (adminBtn) {
        adminBtn.style.display = isAdmin ? 'flex' : 'none';
    }

    // Admin welcome banner
    const adminWelcome = document.getElementById('adminWelcome');
    if (adminWelcome) {
        adminWelcome.style.display = isAdmin ? 'block' : 'none';
    }

    // Admin nav button
    const navAdmin = document.getElementById('navAdmin');
    if (navAdmin) {
        navAdmin.style.display = isAdmin ? 'flex' : 'none';
    }
}

// ============================================
// Load Servers
// ============================================
async function loadServers() {
    DashboardState.isLoading = true;
    showLoadingState();

    try {
        // Try API first
        const token = localStorage.getItem('aqua_token');
        if (token) {
            const response = await fetch('/api/servers', {
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (response.ok) {
                const data = await response.json();
                DashboardState.servers = data.servers || [];
                renderServers();
                updateStats();
                return;
            }
        }
    } catch (error) {
        console.log('API unavailable, using demo servers');
    }

    // Demo servers
    DashboardState.servers = getDemoServers();
    renderServers();
    updateStats();
    DashboardState.isLoading = false;
}

// ============================================
// Demo Servers
// ============================================
function getDemoServers() {
    return [
        {
            id: 1,
            name: 'Survival SMP',
            uuid: '@f5vba2',
            ip: '192.168.1.100:25565',
            status: 'online',
            game: 'Paper',
            version: '1.21.11',
            location: 'New York, USA',
            locationFlag: 'US',
            players: { online: 8, max: 50 },
            cpu: 45,
            ram: { used: 2560, total: 4096 },
            disk: { used: 15360, total: 51200 },
            uptime: '3h 24m',
            network: { upload: '1.2 MB/s', download: '3.8 MB/s' },
            expiresIn: 28
        },
        {
            id: 2,
            name: 'Creative Build',
            uuid: '@a3x9k1',
            ip: '192.168.1.101:25566',
            status: 'online',
            game: 'Spigot',
            version: '1.21.11',
            location: 'London, UK',
            locationFlag: 'GB',
            players: { online: 3, max: 30 },
            cpu: 22,
            ram: { used: 1228, total: 2048 },
            disk: { used: 8192, total: 25600 },
            uptime: '1h 12m',
            network: { upload: '0.5 MB/s', download: '1.1 MB/s' },
            expiresIn: 15
        },
        {
            id: 3,
            name: 'Forge Modded',
            uuid: '@m7p2w4',
            ip: 'Pending...',
            status: 'installing',
            game: 'Forge',
            version: '1.21.4',
            location: 'Frankfurt, DE',
            locationFlag: 'DE',
            players: { online: 0, max: 20 },
            cpu: 0,
            ram: { used: 0, total: 6144 },
            disk: { used: 0, total: 102400 },
            uptime: '-',
            network: { upload: '-', download: '-' },
            expiresIn: 30,
            installProgress: 65
        }
    ];
}

// ============================================
// Render Servers
// ============================================
function renderServers() {
    const serverList = document.getElementById('serverList');
    const emptyState = document.getElementById('emptyState');

    if (!serverList) return;

    const servers = DashboardState.servers;

    if (servers.length === 0) {
        if (emptyState) emptyState.style.display = 'block';
        serverList.innerHTML = '';
        return;
    }

    if (emptyState) emptyState.style.display = 'none';

    serverList.innerHTML = servers.map(server => {
        const statusClass = `status-${server.status}`;
        const ramPercent = server.ram.total > 0 ? Math.round((server.ram.used / server.ram.total) * 100) : 0;
        const diskPercent = server.disk.total > 0 ? Math.round((server.disk.used / server.disk.total) * 100) : 0;

        if (server.status === 'installing') {
            return renderInstallingServer(server);
        }

        return `
            <div class="server-card" onclick="viewServer(${server.id})">
                <div class="server-card-header">
                    <div class="server-name-section">
                        <div class="server-icon">
                            <i class="fas fa-${server.game === 'Paper' ? 'cube' : server.game === 'Spigot' ? 'paint-brush' : 'cogs'}"></i>
                        </div>
                        <div>
                            <div class="server-name">${server.name}</div>
                            <div class="server-id">${server.uuid}</div>
                            <div class="server-ip-text">
                                ${server.ip}
                                <i class="fas fa-copy" style="cursor:pointer;font-size:9px;" 
                                   onclick="event.stopPropagation();copyServerIP('${server.ip}')"></i>
                            </div>
                        </div>
                    </div>
                    <span class="status-badge ${statusClass}">${server.status}</span>
                </div>

                <div class="server-tabs">
                    <button class="server-tab active" onclick="event.stopPropagation();switchCardTab(this,'status${server.id}')">Status</button>
                    <button class="server-tab" onclick="event.stopPropagation();switchCardTab(this,'resources${server.id}')">Resources</button>
                    <button class="server-tab" onclick="event.stopPropagation();switchCardTab(this,'network${server.id}')">Network</button>
                </div>

                <div class="server-card-body">
                    <div class="server-tab-content active" id="status${server.id}">
                        <div style="font-size:12px;color:var(--text-secondary);line-height:1.8;">
                            <div><i class="fas fa-microchip" style="width:20px;color:#667eea;"></i> ${server.game} ${server.version}</div>
                            <div><i class="fas fa-globe" style="width:20px;color:#4facfe;"></i> ${server.location}</div>
                            <div><i class="fas fa-users" style="width:20px;color:#43e97b;"></i> ${server.players.online} / ${server.players.max} Players</div>
                            <div><i class="fas fa-clock" style="width:20px;color:#f59e0b;"></i> Uptime: ${server.uptime}</div>
                        </div>
                    </div>

                    <div class="server-tab-content" id="resources${server.id}">
                        <div class="resource-row">
                            <div class="resource-label"><span>CPU</span><span>${server.cpu}%</span></div>
                            <div class="resource-bar">
                                <div class="resource-fill cpu" style="width:${server.cpu}%;"></div>
                            </div>
                        </div>
                        <div class="resource-row">
                            <div class="resource-label">
                                <span>RAM (${(server.ram.used/1024).toFixed(1)}GB / ${(server.ram.total/1024).toFixed(0)}GB)</span>
                                <span>${ramPercent}%</span>
                            </div>
                            <div class="resource-bar">
                                <div class="resource-fill ram" style="width:${ramPercent}%;"></div>
                            </div>
                        </div>
                        <div class="resource-row">
                            <div class="resource-label">
                                <span>Disk (${(server.disk.used/1024).toFixed(0)}GB / ${(server.disk.total/1024).toFixed(0)}GB)</span>
                                <span>${diskPercent}%</span>
                            </div>
                            <div class="resource-bar">
                                <div class="resource-fill disk" style="width:${diskPercent}%;"></div>
                            </div>
                        </div>
                    </div>

                    <div class="server-tab-content" id="network${server.id}">
                        <div class="network-row">
                            <div class="network-dir">
                                <i class="fas fa-arrow-up network-arrow up"></i><span>Upload</span>
                            </div>
                            <span>${server.network.upload}</span>
                        </div>
                        <div class="network-row" style="margin-top:8px;">
                            <div class="network-dir">
                                <i class="fas fa-arrow-down network-arrow down"></i><span>Download</span>
                            </div>
                            <span>${server.network.download}</span>
                        </div>
                    </div>
                </div>

                <div class="server-card-footer">
                    <a href="console.html" class="btn-card btn-console" onclick="event.stopPropagation();">
                        <i class="fas fa-terminal"></i> Console
                    </a>
                    <button class="btn-card btn-manage" onclick="event.stopPropagation();manageServer(${server.id})">
                        <i class="fas fa-cog"></i> Manage
                    </button>
                    ${server.status === 'online' ? `
                        <button class="btn-card btn-stop" onclick="event.stopPropagation();stopServer(${server.id})">
                            <i class="fas fa-stop"></i> Stop
                        </button>
                    ` : `
                        <button class="btn-card" style="background:var(--gradient-3);" onclick="event.stopPropagation();startServer(${server.id})">
                            <i class="fas fa-play"></i> Start
                        </button>
                    `}
                </div>
            </div>
        `;
    }).join('');
}

function renderInstallingServer(server) {
    return `
        <div class="server-card">
            <div class="server-card-header">
                <div class="server-name-section">
                    <div class="server-icon" style="background:var(--gradient-4);">
                        <i class="fas fa-cogs"></i>
                    </div>
                    <div>
                        <div class="server-name">${server.name}</div>
                        <div class="server-id">${server.uuid}</div>
                        <div class="server-ip-text">${server.ip}</div>
                    </div>
                </div>
                <span class="status-badge status-installing">Installing</span>
            </div>
            <div class="server-card-body">
                <div style="font-size:12px;color:var(--text-secondary);line-height:1.8;">
                    <div><i class="fas fa-microchip" style="width:20px;color:#667eea;"></i> ${server.game} ${server.version}</div>
                    <div><i class="fas fa-globe" style="width:20px;color:#4facfe;"></i> ${server.location}</div>
                    <div><i class="fas fa-spinner" style="width:20px;color:#f093fb;"></i> Installing... ${server.installProgress}%</div>
                </div>
                <div class="resource-bar" style="margin-top:10px;">
                    <div class="resource-fill cpu" style="width:${server.installProgress}%;animation:pulse 1.5s infinite;"></div>
                </div>
            </div>
            <div class="server-card-footer">
                <button class="btn-card btn-console" onclick="event.stopPropagation();viewInstallLog(${server.id})">
                    <i class="fas fa-list"></i> View Log
                </button>
                <button class="btn-card" style="background:#f5576c;" onclick="event.stopPropagation();cancelInstall(${server.id})">
                    <i class="fas fa-times"></i> Cancel
                </button>
            </div>
        </div>
    `;
}

// ============================================
// Server Actions
// ============================================
function viewServer(id) {
    const server = DashboardState.servers.find(s => s.id === id);
    if (server && server.status !== 'installing') {
        window.location.href = `console.html?id=${id}`;
    }
}

function manageServer(id) {
    window.location.href = `console.html?id=${id}`;
}

function startServer(id) {
    showToast('Starting server...', 'info');
    // API call to start server
    setTimeout(() => {
        updateServerStatus(id, 'online');
        showToast('Server started successfully!', 'success');
    }, 2000);
}

function stopServer(id) {
    if (confirm('Are you sure you want to stop this server?')) {
        showToast('Stopping server...', 'info');
        // API call to stop server
        setTimeout(() => {
            updateServerStatus(id, 'offline');
            showToast('Server stopped.', 'info');
        }, 2000);
    }
}

function viewInstallLog(id) {
    showToast('Opening installation log...', 'info');
}

function cancelInstall(id) {
    if (confirm('Cancel this installation?')) {
        DashboardState.servers = DashboardState.servers.filter(s => s.id !== id);
        renderServers();
        updateStats();
        showToast('Installation cancelled.', 'error');
    }
}

function updateServerStatus(id, status) {
    const server = DashboardState.servers.find(s => s.id === id);
    if (server) {
        server.status = status;
        renderServers();
        updateStats();
    }
}

// ============================================
// Stats
// ============================================
function loadStats() {
    // Update stats from servers
    updateStats();
}

function updateStats() {
    const servers = DashboardState.servers;
    const onlineServers = servers.filter(s => s.status === 'online');
    const totalRam = servers.reduce((sum, s) => sum + (s.ram?.used || 0), 0);

    const stats = {
        total: servers.length,
        active: onlineServers.length,
        health: onlineServers.length > 0 ? 'Good' : 'Warning',
        avgUsage: servers.length > 0 ? Math.round(servers.reduce((sum, s) => sum + (s.cpu || 0), 0) / servers.length) : 0,
        totalRam: totalRam
    };

    DashboardState.stats = stats;

    // Update display
    updateElement('statServers', stats.total);
    updateElement('statActive', stats.active);
    updateElement('statHealth', stats.health);
    updateElement('statUsage', stats.avgUsage + '%');
    updateElement('dashServers', stats.total);
    updateElement('dashRunning', stats.active);
    updateElement('dashRam', (stats.totalRam / 1024).toFixed(1) + ' GB');
}

function updateElement(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

// ============================================
// Card Tab Switching
// ============================================
function switchCardTab(button, tabId) {
    const card = button.closest('.server-card');
    if (!card) return;

    // Update tabs
    card.querySelectorAll('.server-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    button.classList.add('active');

    // Update content
    card.querySelectorAll('.server-tab-content').forEach(content => {
        content.classList.remove('active');
    });
    const target = card.querySelector('#' + tabId);
    if (target) target.classList.add('active');
}

// ============================================
// Search
// ============================================
function setupSearch() {
    const searchInput = document.querySelector('.search-input');
    if (!searchInput) return;

    searchInput.addEventListener('input', (e) => {
        DashboardState.searchQuery = e.target.value.toLowerCase();
        filterServers();
    });
}

function filterServers() {
    const query = DashboardState.searchQuery;
    if (!query) {
        renderServers();
        return;
    }

    const filtered = DashboardState.servers.filter(server => 
        server.name.toLowerCase().includes(query) ||
        server.game.toLowerCase().includes(query) ||
        server.location.toLowerCase().includes(query) ||
        server.uuid.toLowerCase().includes(query)
    );

    // Temporarily set servers for rendering
    const originalServers = DashboardState.servers;
    DashboardState.servers = filtered;
    renderServers();
    DashboardState.servers = originalServers;
}

// ============================================
// Copy Server IP
// ============================================
function copyServerIP(ip) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(ip).then(() => {
            showToast('IP Copied: ' + ip, 'success');
        });
    } else {
        const textarea = document.createElement('textarea');
        textarea.value = ip;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast('IP Copied: ' + ip, 'success');
    }
}

// ============================================
// Create Server
// ============================================
function createServer() {
    // Redirect to create server page or show modal
    window.location.href = 'admin.html#servers';
}

// ============================================
// Real-time Updates
// ============================================
function setupRealTimeUpdates() {
    // Update server stats every 30 seconds
    setInterval(() => {
        DashboardState.servers.forEach(server => {
            if (server.status === 'online') {
                // Simulate changing stats
                server.cpu = Math.floor(Math.random() * 30) + 15;
                server.ram.used = Math.floor(Math.random() * server.ram.total * 0.3) + server.ram.total * 0.4;
                server.players.online = Math.floor(Math.random() * 10) + 1;
            }
        });
        updateStats();
    }, 30000);
}

// ============================================
// Loading State
// ============================================
function showLoadingState() {
    const serverList = document.getElementById('serverList');
    if (serverList) {
        serverList.innerHTML = `
            <div style="text-align:center;padding:40px;">
                <div class="spinner spinner-lg"></div>
                <p style="margin-top:15px;color:var(--text-secondary);">Loading servers...</p>
            </div>
        `;
    }
}

// ============================================
// User Dropdown
// ============================================
function toggleDropdown() {
    const dropdown = document.getElementById('userDropdown');
    if (dropdown) {
        dropdown.classList.toggle('active');
    }
}

// Close dropdown when clicking outside
document.addEventListener('click', (e) => {
    const dropdown = document.getElementById('userDropdown');
    const avatar = document.getElementById('avatarBtn');
    if (dropdown && avatar && !avatar.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove('active');
    }
});

// ============================================
// Toast Notification
// ============================================
function showToast(message, type = 'info') {
    const container = document.getElementById('toastCtr') || document.getElementById('toastContainer');
    if (!container) {
        const ctr = document.createElement('div');
        ctr.id = 'toastContainer';
        ctr.className = 'toast-container';
        document.body.appendChild(ctr);
    }

    const toastContainer = document.getElementById('toastContainer') || document.getElementById('toastCtr');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(-10px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 2500);
}

// ============================================
// Logout
// ============================================
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('aqua_token');
        localStorage.removeItem('aqua_user');
        window.location.href = 'landing.html';
    }
}

// ============================================
// Initialize on Page Load
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    initDashboard();
});

// ============================================
// Export for Global Use
// ============================================
window.AquaDashboard = {
    initDashboard,
    loadServers,
    renderServers,
    viewServer,
    manageServer,
    startServer,
    stopServer,
    createServer,
    copyServerIP,
    toggleDropdown,
    showToast,
    logout,
    DashboardState
};