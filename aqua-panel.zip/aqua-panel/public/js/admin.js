// ============================================
// Aqua Panel - Admin Panel JavaScript
// Location: /var/www/aqua-panel/public/js/admin.js
// ============================================

// ============================================
// Global State
// ============================================
const AdminState = {
    currentPage: 'overview',
    currentTheme: localStorage.getItem('aqua_theme') || 'purple',
    currentFont: localStorage.getItem('aqua_font') || 'Inter',
    currentGlow: localStorage.getItem('aqua_glow') || 'purple',
    glowIntensity: {
        card: localStorage.getItem('aqua_glow_card') || 70,
        button: localStorage.getItem('aqua_glow_button') || 50,
        border: localStorage.getItem('aqua_glow_border') || 40,
        text: localStorage.getItem('aqua_glow_text') || 25
    },
    landingConfig: JSON.parse(localStorage.getItem('aqua_landing_config') || '{}')
};

// ============================================
// Page Navigation
// ============================================
function showPage(pageName) {
    // Hide all pages
    document.querySelectorAll('.section-page').forEach(page => {
        page.classList.remove('active');
    });

    // Show selected page
    const targetPage = document.getElementById('page-' + pageName);
    if (targetPage) {
        targetPage.classList.add('active');
        AdminState.currentPage = pageName;
    }

    // Update sidebar active state
    document.querySelectorAll('.sidebar-link').forEach(link => {
        link.classList.remove('active');
    });

    const activeLink = document.querySelector(`[onclick="showPage('${pageName}')"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Load page-specific data
    loadPageData(pageName);
}

// ============================================
// Load Page Data
// ============================================
function loadPageData(pageName) {
    switch (pageName) {
        case 'overview':
            loadDashboardStats();
            break;
        case 'users':
            loadUsersList();
            break;
        case 'themes':
            loadThemeSettings();
            break;
        case 'fonts':
            loadFontSettings();
            break;
        case 'glow':
            loadGlowSettings();
            break;
        case 'landing':
            loadLandingConfig();
            break;
    }
}

// ============================================
// Dashboard Stats
// ============================================
async function loadDashboardStats() {
    try {
        // Try API first
        const token = localStorage.getItem('aqua_token');
        if (token) {
            const response = await fetch('/api/admin/dashboard', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (response.ok) {
                const data = await response.json();
                updateStatsDisplay(data.stats);
                return;
            }
        }
    } catch (error) {
        console.log('Using demo stats');
    }

    // Demo stats
    updateStatsDisplay({
        servers: 24,
        users: 156,
        nodes: 5,
        locations: 9
    });
}

function updateStatsDisplay(stats) {
    const elements = {
        statServers: stats.servers || 0,
        statUsers: stats.users || 0,
        statNodes: stats.nodes || 0,
        statLocations: stats.locations || 0
    };

    Object.entries(elements).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    });
}

// ============================================
// Theme Management
// ============================================
function selectTheme(element) {
    // Remove selection from all
    document.querySelectorAll('.theme-dot').forEach(dot => {
        dot.classList.remove('selected');
    });

    // Add selection to clicked
    element.classList.add('selected');

    // Get theme name from background
    const bg = element.style.background;
    let themeName = 'purple';

    if (bg.includes('667eea')) themeName = 'purple';
    else if (bg.includes('f093fb')) themeName = 'pink';
    else if (bg.includes('4facfe')) themeName = 'blue';
    else if (bg.includes('43e97b')) themeName = 'green';
    else if (bg.includes('fa709a')) themeName = 'sunset';

    // Apply theme
    applyTheme(themeName);
}

function applyTheme(themeName) {
    // Remove all theme classes
    document.body.classList.remove(
        'theme-purple', 'theme-pink', 'theme-blue',
        'theme-green', 'theme-sunset', 'theme-midnight'
    );

    // Add selected theme class
    document.body.classList.add('theme-' + themeName);

    // Set data attribute
    document.documentElement.setAttribute('data-theme', themeName);

    // Update CSS variables
    const themes = {
        purple: { primary: '#667eea', secondary: '#764ba2' },
        pink: { primary: '#f093fb', secondary: '#f5576c' },
        blue: { primary: '#4facfe', secondary: '#00f2fe' },
        green: { primary: '#43e97b', secondary: '#38f9d7' },
        sunset: { primary: '#fa709a', secondary: '#fee140' }
    };

    const theme = themes[themeName];
    if (theme) {
        document.documentElement.style.setProperty('--gradient-1', 
            `linear-gradient(135deg, ${theme.primary} 0%, ${theme.secondary} 100%)`);
        document.documentElement.style.setProperty('--color-primary', theme.primary);
    }

    // Save to state and localStorage
    AdminState.currentTheme = themeName;
    localStorage.setItem('aqua_theme', themeName);

    showToast('Theme applied: ' + themeName.charAt(0).toUpperCase() + themeName.slice(1), 'success');
}

function loadThemeSettings() {
    // Highlight current theme
    const currentTheme = AdminState.currentTheme;
    document.querySelectorAll('.theme-dot').forEach(dot => {
        dot.classList.remove('selected');
        const bg = dot.style.background;
        if ((currentTheme === 'purple' && bg.includes('667eea')) ||
            (currentTheme === 'pink' && bg.includes('f093fb')) ||
            (currentTheme === 'blue' && bg.includes('4facfe')) ||
            (currentTheme === 'green' && bg.includes('43e97b')) ||
            (currentTheme === 'sunset' && bg.includes('fa709a'))) {
            dot.classList.add('selected');
        }
    });
}

// ============================================
// Font Management
// ============================================
function selectFont(fontName, element) {
    // Remove selection from all
    document.querySelectorAll('.font-option').forEach(opt => {
        opt.classList.remove('selected');
    });

    // Add selection to clicked
    if (element) element.classList.add('selected');

    // Apply font
    applyFont(fontName);
}

function applyFont(fontName) {
    // Remove all font classes
    document.body.classList.remove(
        'font-inter', 'font-poppins', 'font-plus-jakarta',
        'font-dm-sans', 'font-jetbrains-mono'
    );

    // Map font name to class
    const fontClassMap = {
        'Inter': 'font-inter',
        'Poppins': 'font-poppins',
        'Plus Jakarta Sans': 'font-plus-jakarta',
        'DM Sans': 'font-dm-sans',
        'JetBrains Mono': 'font-jetbrains-mono'
    };

    const fontClass = fontClassMap[fontName] || 'font-inter';
    document.body.classList.add(fontClass);

    // Set font family directly
    document.body.style.fontFamily = `'${fontName}', sans-serif`;

    // Save
    AdminState.currentFont = fontName;
    localStorage.setItem('aqua_font', fontName);

    showToast('Font applied: ' + fontName, 'success');
}

function loadFontSettings() {
    const currentFont = AdminState.currentFont;
    document.querySelectorAll('.font-option').forEach(opt => {
        opt.classList.remove('selected');
        const name = opt.querySelector('.font-name');
        if (name && name.textContent === currentFont) {
            opt.classList.add('selected');
        }
    });
}

// ============================================
// Glow Effects Management
// ============================================
function selectGlow(preset, element) {
    document.querySelectorAll('.glow-card').forEach(card => {
        card.classList.remove('selected');
    });

    if (element) element.classList.add('selected');

    AdminState.currentGlow = preset;
    localStorage.setItem('aqua_glow', preset);

    // Apply glow preset
    const glowColors = {
        purple: 'rgba(102, 126, 234, VAR)',
        pink: 'rgba(240, 147, 251, VAR)',
        blue: 'rgba(79, 172, 254, VAR)',
        green: 'rgba(67, 233, 123, VAR)',
        gold: 'rgba(245, 158, 11, VAR)'
    };

    if (glowColors[preset]) {
        document.documentElement.style.setProperty(
            '--glow-color-1',
            glowColors[preset].replace('VAR', '0.6')
        );
        document.documentElement.style.setProperty(
            '--glow-color-2',
            glowColors[preset].replace('VAR', '0.3')
        );
    }

    showToast('Glow preset applied: ' + preset, 'admin');
}

function updateGlowSlider(type, value) {
    const valueMap = {
        card: 'cardGlowVal',
        button: 'buttonGlowVal',
        border: 'borderGlowVal',
        text: 'textGlowVal'
    };

    const labelMap = {
        card: 'card',
        button: 'button',
        border: 'border',
        text: 'text'
    };

    // Update display
    const labelEl = document.getElementById(valueMap[type]);
    if (labelEl) labelEl.textContent = value + '%';

    // Save
    AdminState.glowIntensity[type] = parseInt(value);
    localStorage.setItem('aqua_glow_' + labelMap[type], value);

    // Apply
    const intensity = value / 100;
    const glowSize = 20 * intensity;
    document.documentElement.style.setProperty('--glow-intensity', glowSize + 'px');
}

function updatePulseSpeed(value) {
    const label = document.getElementById('pulseVal');
    if (label) label.textContent = value + ' seconds';
    document.documentElement.style.setProperty('--pulse-speed', value + 's');
    localStorage.setItem('aqua_pulse_speed', value);
}

function loadGlowSettings() {
    // Restore glow presets
    const currentGlow = AdminState.currentGlow;
    document.querySelectorAll('.glow-card').forEach(card => {
        card.classList.remove('selected');
        if (card.classList.contains('glow-' + currentGlow)) {
            card.classList.add('selected');
        }
    });

    // Restore sliders
    const sliders = {
        card: AdminState.glowIntensity.card,
        button: AdminState.glowIntensity.button,
        border: AdminState.glowIntensity.border,
        text: AdminState.glowIntensity.text
    };

    Object.entries(sliders).forEach(([type, value]) => {
        const slider = document.querySelector(`.slider[oninput*="${type}"]`);
        if (slider) slider.value = value;
        updateGlowSlider(type, value);
    });
}

// ============================================
// Landing Page Editor
// ============================================
function loadLandingConfig() {
    const config = AdminState.landingConfig;
    
    const fields = {
        heroTitle: config.heroTitle || 'Welcome to Aqua Panel',
        heroBadge: config.heroBadge || 'Now with Minecraft 1.21.11 & Bedrock 1.26',
        heroSubtitle: config.heroSubtitle || 'Premium Minecraft server management panel.',
        btnPrimaryText: config.btnPrimaryText || 'Get Started',
        btnPrimaryLink: config.btnPrimaryLink || 'register.html',
        btnSecondaryText: config.btnSecondaryText || 'Join our Discord',
        discordLink: config.discordLink || 'https://discord.gg/aquapanel',
        featuresTitle: config.featuresTitle || 'Why Choose Aqua Panel?',
        featuresSubtitle: config.featuresSubtitle || 'Everything you need to host Minecraft servers'
    };

    Object.entries(fields).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.value = value;
    });
}

function saveLandingPage() {
    const config = {
        heroTitle: document.getElementById('heroTitle')?.value,
        heroBadge: document.getElementById('heroBadge')?.value,
        heroSubtitle: document.getElementById('heroSubtitle')?.value,
        btnPrimaryText: document.getElementById('btnPrimaryText')?.value,
        btnPrimaryLink: document.getElementById('btnPrimaryLink')?.value,
        btnSecondaryText: document.getElementById('btnSecondaryText')?.value,
        discordLink: document.getElementById('discordLink')?.value,
        featuresTitle: document.getElementById('featuresTitle')?.value,
        featuresSubtitle: document.getElementById('featuresSubtitle')?.value
    };

    AdminState.landingConfig = config;
    localStorage.setItem('aqua_landing_config', JSON.stringify(config));

    showSuccess('landing');
}

// ============================================
// User Management
// ============================================
async function loadUsersList() {
    const userList = document.getElementById('userList');
    if (!userList) return;

    try {
        const token = localStorage.getItem('aqua_token');
        if (token) {
            const response = await fetch('/api/admin/users', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (response.ok) {
                const data = await response.json();
                renderUsersList(data.users);
                return;
            }
        }
    } catch (error) {
        console.log('Using demo users');
    }

    // Demo users
    const demoUsers = [
        { username: 'Admin User', email: 'admin@aquapanel.com', role: 'admin', server_count: 24, status: 'active' },
        { username: 'JohnDoe', email: 'john@email.com', role: 'user', server_count: 3, status: 'active' },
        { username: 'JaneSmith', email: 'jane@email.com', role: 'user', server_count: 1, status: 'active' }
    ];
    renderUsersList(demoUsers);
}

function renderUsersList(users) {
    const userList = document.getElementById('userList');
    if (!userList) return;

    userList.innerHTML = users.map(user => `
        <div class="data-card">
            <div class="data-card-header">
                <strong>${user.username}</strong>
                <span class="badge-tag ${user.role === 'admin' ? 'badge-admin' : 'badge-user'}">${user.role}</span>
            </div>
            <div class="data-desc">
                ${user.email} | Servers: ${user.server_count || 0} | Status: ${user.status}
            </div>
        </div>
    `).join('');
}

// ============================================
// Toast Notifications
// ============================================
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) {
        // Create container if not exists
        const ctr = document.createElement('div');
        ctr.id = 'toastContainer';
        ctr.className = 'toast-container';
        document.body.appendChild(ctr);
    }

    const toastContainer = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    toastContainer.appendChild(toast);

    // Auto remove after 3 seconds
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(-10px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ============================================
// Success Message
// ============================================
function showSuccess(type) {
    const msg = document.getElementById('success-' + type);
    if (msg) {
        msg.style.display = 'block';
        setTimeout(() => {
            msg.style.display = 'none';
        }, 3000);
    }
}

// ============================================
// Copy to Clipboard
// ============================================
function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            showToast('Copied to clipboard!', 'success');
        });
    } else {
        // Fallback
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast('Copied to clipboard!', 'success');
    }
}

// ============================================
// Logout
// ============================================
function logout() {
    localStorage.removeItem('aqua_token');
    localStorage.removeItem('aqua_user');
    window.location.href = 'landing.html';
}

// ============================================
// Initialize
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    console.log('Aqua Panel Admin - Initialized');

    // Apply saved theme
    applyTheme(AdminState.currentTheme);

    // Apply saved font
    applyFont(AdminState.currentFont);

    // Apply saved glow
    selectGlow(AdminState.currentGlow);

    // Load initial page data
    loadPageData('overview');
});

// ============================================
// Keyboard Shortcuts
// ============================================
document.addEventListener('keydown', (e) => {
    // Ctrl+S to save on landing page
    if (e.ctrlKey && e.key === 's') {
        if (AdminState.currentPage === 'landing') {
            e.preventDefault();
            saveLandingPage();
        }
    }

    // Escape to go back
    if (e.key === 'Escape') {
        if (AdminState.currentPage !== 'overview') {
            showPage('overview');
        }
    }
});

// ============================================
// Export for global use
// ============================================
window.AquaAdmin = {
    showPage,
    selectTheme,
    applyTheme,
    selectFont,
    applyFont,
    selectGlow,
    updateGlowSlider,
    updatePulseSpeed,
    saveLandingPage,
    showToast,
    copyToClipboard,
    logout,
    AdminState
};