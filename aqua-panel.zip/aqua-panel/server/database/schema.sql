-- ============================================
-- Aqua Panel - Database Schema
-- Location: /var/www/aqua-panel/server/database/schema.sql
-- Version: 1.0.0
-- ============================================

-- Create Database
CREATE DATABASE IF NOT EXISTS aqua_panel 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

USE aqua_panel;

-- ============================================
-- Users Table
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    is_first_user BOOLEAN DEFAULT FALSE,
    avatar VARCHAR(255) DEFAULT NULL,
    credits DECIMAL(10,2) DEFAULT 0.00,
    server_limit INT DEFAULT 5,
    status ENUM('active', 'suspended', 'banned') DEFAULT 'active',
    last_login TIMESTAMP NULL DEFAULT NULL,
    last_ip VARCHAR(45) DEFAULT NULL,
    last_active TIMESTAMP NULL DEFAULT NULL,
    last_password_change TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_username (username),
    UNIQUE KEY unique_email (email),
    INDEX idx_role (role),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Servers Table
-- ============================================
CREATE TABLE IF NOT EXISTS servers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uuid VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT DEFAULT NULL,
    user_id INT NOT NULL,
    node_id INT DEFAULT NULL,
    location_id INT DEFAULT NULL,
    egg_id INT DEFAULT NULL,
    memory INT DEFAULT 4096 COMMENT 'RAM in MB',
    cpu INT DEFAULT 200 COMMENT 'CPU percentage',
    disk INT DEFAULT 51200 COMMENT 'Disk in MB',
    allocation VARCHAR(100) DEFAULT NULL,
    game_type VARCHAR(50) DEFAULT 'paper',
    game_version VARCHAR(20) DEFAULT '1.21.11',
    status ENUM('installing', 'running', 'stopped', 'starting', 'stopping', 'error', 'suspended') DEFAULT 'installing',
    startup_command TEXT DEFAULT NULL,
    docker_image VARCHAR(255) DEFAULT NULL,
    expires_at DATE DEFAULT NULL,
    last_started TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_uuid (uuid),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_node_id (node_id),
    INDEX idx_location_id (location_id),
    INDEX idx_status (status),
    INDEX idx_expires_at (expires_at),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Nodes Table
-- ============================================
CREATE TABLE IF NOT EXISTS nodes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uuid VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT DEFAULT NULL,
    fqdn VARCHAR(255) NOT NULL COMMENT 'Fully Qualified Domain Name',
    scheme VARCHAR(10) DEFAULT 'https',
    total_memory INT NOT NULL COMMENT 'Total RAM in MB',
    total_disk INT NOT NULL COMMENT 'Total Disk in MB',
    allocated_memory INT DEFAULT 0 COMMENT 'Used RAM in MB',
    allocated_disk INT DEFAULT 0 COMMENT 'Used Disk in MB',
    port_range_start VARCHAR(50) DEFAULT NULL,
    port_range_end VARCHAR(50) DEFAULT NULL,
    daemon_listen INT DEFAULT 8080,
    daemon_sftp INT DEFAULT 2022,
    daemon_token VARCHAR(255) DEFAULT NULL,
    status ENUM('active', 'inactive', 'maintenance') DEFAULT 'active',
    last_ping TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_uuid (uuid),
    UNIQUE KEY unique_fqdn (fqdn),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Locations Table
-- ============================================
CREATE TABLE IF NOT EXISTS locations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    short_code VARCHAR(10) NOT NULL,
    description TEXT DEFAULT NULL,
    flag VARCHAR(10) DEFAULT NULL COMMENT 'Country flag emoji',
    country_code VARCHAR(5) DEFAULT NULL,
    city VARCHAR(100) DEFAULT NULL,
    timezone VARCHAR(50) DEFAULT 'UTC',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_short_code (short_code),
    INDEX idx_status (status),
    INDEX idx_country_code (country_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Eggs/Nests Table
-- ============================================
CREATE TABLE IF NOT EXISTS eggs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL COMMENT 'minecraft, proxy, etc',
    version VARCHAR(50) DEFAULT NULL,
    description TEXT DEFAULT NULL,
    docker_image VARCHAR(255) DEFAULT NULL,
    startup_command TEXT DEFAULT NULL,
    default_memory INT DEFAULT 4096,
    default_cpu INT DEFAULT 200,
    default_disk INT DEFAULT 51200,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_egg (name, type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- API Keys Table
-- ============================================
CREATE TABLE IF NOT EXISTS api_keys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    key_value VARCHAR(64) NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    permissions TEXT DEFAULT NULL,
    allowed_ips TEXT DEFAULT NULL,
    last_used TIMESTAMP NULL DEFAULT NULL,
    expires_at TIMESTAMP NULL DEFAULT NULL,
    status ENUM('active', 'revoked') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_key (key_value),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Settings Table
-- ============================================
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL,
    setting_value TEXT DEFAULT NULL,
    setting_type ENUM('string', 'boolean', 'integer', 'json', 'color', 'file') DEFAULT 'string',
    description VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Backups Table
-- ============================================
CREATE TABLE IF NOT EXISTS backups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uuid VARCHAR(36) NOT NULL,
    server_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    file_name VARCHAR(255) DEFAULT NULL,
    size BIGINT DEFAULT 0 COMMENT 'Size in bytes',
    path VARCHAR(500) DEFAULT NULL,
    checksum VARCHAR(64) DEFAULT NULL,
    type ENUM('full', 'partial', 'incremental') DEFAULT 'full',
    status ENUM('pending', 'running', 'completed', 'failed') DEFAULT 'pending',
    error_message TEXT DEFAULT NULL,
    completed_at TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
    UNIQUE KEY unique_uuid (uuid),
    INDEX idx_server_id (server_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Activity Logs Table
-- ============================================
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    server_id INT DEFAULT NULL,
    action VARCHAR(100) NOT NULL,
    description TEXT DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    user_agent TEXT DEFAULT NULL,
    metadata JSON DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_server_id (server_id),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Allocations Table
-- ============================================
CREATE TABLE IF NOT EXISTS allocations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    node_id INT NOT NULL,
    server_id INT DEFAULT NULL,
    ip_address VARCHAR(45) NOT NULL,
    port INT NOT NULL,
    type ENUM('primary', 'additional') DEFAULT 'primary',
    status ENUM('available', 'assigned') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (node_id) REFERENCES nodes(id) ON DELETE CASCADE,
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE SET NULL,
    UNIQUE KEY unique_ip_port (ip_address, port),
    INDEX idx_node_id (node_id),
    INDEX idx_server_id (server_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Admin Permissions Table
-- ============================================
CREATE TABLE IF NOT EXISTS admin_permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    permissions TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- INSERT DEFAULT DATA
-- ============================================

-- Default Eggs
INSERT INTO eggs (name, type, version, description, default_memory, default_cpu, default_disk) VALUES
('Paper', 'minecraft', '1.21.11', 'High performance Spigot fork with optimizations', 4096, 200, 51200),
('Spigot', 'minecraft', '1.21.11', 'Popular Minecraft server with plugin support', 4096, 200, 51200),
('Forge', 'minecraft', '1.21.4', 'Minecraft server with mod support', 6144, 300, 102400),
('Bedrock', 'minecraft', '1.26.0', 'Minecraft Bedrock Edition server', 2048, 100, 25600),
('BungeeCord', 'proxy', 'latest', 'Minecraft proxy server for network', 1024, 50, 10240),
('Velocity', 'proxy', 'latest', 'Modern Minecraft proxy server', 1024, 50, 10240)
ON DUPLICATE KEY UPDATE version=VALUES(version), description=VALUES(description);

-- Default Locations
INSERT INTO locations (name, short_code, description, flag, country_code, city, timezone) VALUES
('New York, USA', 'us-east', 'East Coast US data center', 'US', 'US', 'New York', 'America/New_York'),
('London, UK', 'uk-london', 'European data center', 'GB', 'GB', 'London', 'Europe/London'),
('Frankfurt, Germany', 'de-frankfurt', 'Central European data center', 'DE', 'DE', 'Frankfurt', 'Europe/Berlin'),
('Singapore', 'sg-singapore', 'Asian data center', 'SG', 'SG', 'Singapore', 'Asia/Singapore'),
('Mumbai, India', 'in-mumbai', 'South Asian data center', 'IN', 'IN', 'Mumbai', 'Asia/Kolkata'),
('Tokyo, Japan', 'jp-tokyo', 'East Asian data center', 'JP', 'JP', 'Tokyo', 'Asia/Tokyo'),
('Sydney, Australia', 'au-sydney', 'Oceanic data center', 'AU', 'AU', 'Sydney', 'Australia/Sydney'),
('Paris, France', 'fr-paris', 'Western European data center', 'FR', 'FR', 'Paris', 'Europe/Paris'),
('Sao Paulo, Brazil', 'br-saopaulo', 'South American data center', 'BR', 'BR', 'Sao Paulo', 'America/Sao_Paulo')
ON DUPLICATE KEY UPDATE description=VALUES(description);

-- Default Settings
INSERT INTO settings (setting_key, setting_value, setting_type, description) VALUES
('panel_name', 'Aqua Panel', 'string', 'Panel display name'),
('panel_logo', 'default', 'file', 'Panel logo file path'),
('panel_theme', 'purple', 'color', 'Default panel theme color'),
('panel_font', 'Inter', 'string', 'Default panel font family'),
('glow_intensity', '50', 'integer', 'Glow effect intensity (0-100)'),
('glow_preset', 'purple', 'string', 'Default glow color preset'),
('background_type', 'particles', 'string', 'Background animation type'),
('background_url', '', 'string', 'Custom background image URL'),
('registration_enabled', 'true', 'boolean', 'Allow new user registration'),
('max_servers_per_user', '5', 'integer', 'Maximum servers per user'),
('default_server_expiry', '30', 'integer', 'Default server expiry in days'),
('maintenance_mode', 'false', 'boolean', 'Enable maintenance mode'),
('language', 'en', 'string', 'Default panel language'),
('timezone', 'UTC', 'string', 'Default timezone'),
('discord_invite', '', 'string', 'Discord server invite URL'),
('footer_text', 'Aqua Panel - Premium Minecraft Server Management', 'string', 'Footer text')
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);

-- ============================================
-- VERIFICATION QUERY
-- ============================================
SELECT 
    'Database setup complete!' as status,
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'aqua_panel') as tables_created,
    (SELECT COUNT(*) FROM eggs) as default_eggs,
    (SELECT COUNT(*) FROM locations) as default_locations,
    (SELECT COUNT(*) FROM settings) as default_settings;