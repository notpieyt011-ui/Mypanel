// ============================================
// Aqua Panel - User Model
// Location: /var/www/aqua-panel/server/models/User.js
// ============================================

const { query, transaction } = require('../config/database');
const bcrypt = require('bcryptjs');

class User {

    // ============================================
    // CREATE USER
    // ============================================
    static async create({ username, email, password, role = 'user' }) {
        try {
            // Validate input
            if (!username || username.length < 3 || username.length > 50) {
                throw new Error('Username must be between 3 and 50 characters');
            }

            if (!/^[a-zA-Z0-9_]+$/.test(username)) {
                throw new Error('Username can only contain letters, numbers, and underscores');
            }

            if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                throw new Error('Please provide a valid email address');
            }

            if (!password || password.length < 8) {
                throw new Error('Password must be at least 8 characters');
            }

            // Check if first user
            const userCount = await query('SELECT COUNT(*) as count FROM users');
            const isFirstUser = userCount[0].count === 0;

            // Check for duplicate email
            const existingEmail = await query(
                'SELECT id FROM users WHERE email = ?',
                [email.toLowerCase()]
            );

            if (existingEmail.length > 0) {
                throw new Error('Email address is already registered');
            }

            // Check for duplicate username
            const existingUsername = await query(
                'SELECT id FROM users WHERE username = ?',
                [username]
            );

            if (existingUsername.length > 0) {
                throw new Error('Username is already taken');
            }

            // Hash password
            const salt = await bcrypt.genSalt(12);
            const hashedPassword = await bcrypt.hash(password, salt);

            // Assign role (first user is admin)
            const finalRole = isFirstUser ? 'admin' : role;

            // Insert user
            const result = await query(
                `INSERT INTO users (
                    username, 
                    email, 
                    password, 
                    role, 
                    is_first_user,
                    server_limit,
                    credits,
                    status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')`,
                [
                    username,
                    email.toLowerCase(),
                    hashedPassword,
                    finalRole,
                    isFirstUser,
                    isFirstUser ? 999 : 5,
                    isFirstUser ? 1000.00 : 0.00
                ]
            );

            // Log activity
            await query(
                `INSERT INTO activity_logs (user_id, action, description) 
                 VALUES (?, 'register', ?)`,
                [result.insertId, isFirstUser ? 'First user registered as ADMIN' : 'User registered']
            );

            // Return user data (without password)
            return {
                id: result.insertId,
                username,
                email: email.toLowerCase(),
                role: finalRole,
                isFirstUser,
                credits: isFirstUser ? 1000.00 : 0.00,
                serverLimit: isFirstUser ? 999 : 5,
                status: 'active'
            };

        } catch (error) {
            console.error('User.create error:', error.message);
            throw error;
        }
    }

    // ============================================
    // FIND USER BY ID
    // ============================================
    static async findById(id) {
        try {
            const users = await query(
                `SELECT 
                    id, username, email, role, is_first_user,
                    avatar, credits, server_limit, status,
                    last_login, last_ip, created_at, updated_at
                 FROM users WHERE id = ?`,
                [id]
            );

            if (users.length === 0) return null;

            const user = users[0];

            // Get server count
            const serverCount = await query(
                'SELECT COUNT(*) as count FROM servers WHERE user_id = ?',
                [id]
            );

            // Get running server count
            const runningCount = await query(
                "SELECT COUNT(*) as count FROM servers WHERE user_id = ? AND status = 'running'",
                [id]
            );

            // Get API key count
            const apiKeyCount = await query(
                "SELECT COUNT(*) as count FROM api_keys WHERE user_id = ? AND status = 'active'",
                [id]
            );

            // Get total resources used
            const resources = await query(
                `SELECT 
                    COALESCE(SUM(memory), 0) as total_memory,
                    COALESCE(SUM(disk), 0) as total_disk,
                    COALESCE(SUM(cpu), 0) as total_cpu
                 FROM servers WHERE user_id = ?`,
                [id]
            );

            return {
                ...user,
                serverCount: serverCount[0].count,
                runningServers: runningCount[0].count,
                activeApiKeys: apiKeyCount[0].count,
                totalMemoryUsed: resources[0].total_memory,
                totalDiskUsed: resources[0].total_disk,
                totalCpuUsed: resources[0].total_cpu,
                permissions: User.getPermissions(user.role, user.is_first_user)
            };

        } catch (error) {
            console.error('User.findById error:', error.message);
            throw error;
        }
    }

    // ============================================
    // FIND USER BY EMAIL
    // ============================================
    static async findByEmail(email) {
        try {
            const users = await query(
                'SELECT * FROM users WHERE email = ?',
                [email.toLowerCase()]
            );

            return users.length > 0 ? users[0] : null;

        } catch (error) {
            console.error('User.findByEmail error:', error.message);
            throw error;
        }
    }

    // ============================================
    // FIND USER BY USERNAME
    // ============================================
    static async findByUsername(username) {
        try {
            const users = await query(
                'SELECT * FROM users WHERE username = ?',
                [username]
            );

            return users.length > 0 ? users[0] : null;

        } catch (error) {
            console.error('User.findByUsername error:', error.message);
            throw error;
        }
    }

    // ============================================
    // VERIFY PASSWORD
    // ============================================
    static async verifyPassword(user, password) {
        try {
            if (!user || !user.password) return false;
            return await bcrypt.compare(password, user.password);
        } catch (error) {
            console.error('User.verifyPassword error:', error.message);
            throw error;
        }
    }

    // ============================================
    // UPDATE USER
    // ============================================
    static async update(id, data) {
        try {
            const allowedFields = [
                'username', 'email', 'role', 'status',
                'server_limit', 'credits', 'avatar'
            ];

            const updates = [];
            const params = [];

            for (const [key, value] of Object.entries(data)) {
                if (allowedFields.includes(key) && value !== undefined) {
                    // Validate specific fields
                    if (key === 'email' && value) {
                        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                            throw new Error('Invalid email format');
                        }
                        params.push(value.toLowerCase());
                    } else if (key === 'status' && value) {
                        const validStatuses = ['active', 'suspended', 'banned'];
                        if (!validStatuses.includes(value)) {
                            throw new Error(`Invalid status: ${value}`);
                        }
                        params.push(value);
                    } else {
                        params.push(value);
                    }
                    updates.push(`${key} = ?`);
                }
            }

            if (updates.length === 0) return false;

            params.push(id);

            await query(
                `UPDATE users SET ${updates.join(', ')} WHERE id = ?`,
                params
            );

            return true;

        } catch (error) {
            console.error('User.update error:', error.message);
            throw error;
        }
    }

    // ============================================
    // CHANGE PASSWORD
    // ============================================
    static async changePassword(id, oldPassword, newPassword) {
        try {
            // Validate new password
            if (!newPassword || newPassword.length < 8) {
                throw new Error('New password must be at least 8 characters');
            }

            // Get current user
            const users = await query('SELECT password FROM users WHERE id = ?', [id]);

            if (users.length === 0) {
                throw new Error('User not found');
            }

            // Verify old password
            const isValid = await bcrypt.compare(oldPassword, users[0].password);

            if (!isValid) {
                throw new Error('Current password is incorrect');
            }

            // Check if new password is same as old
            const isSamePassword = await bcrypt.compare(newPassword, users[0].password);
            if (isSamePassword) {
                throw new Error('New password must be different from current password');
            }

            // Hash new password
            const salt = await bcrypt.genSalt(12);
            const hashedPassword = await bcrypt.hash(newPassword, salt);

            // Update password
            await query(
                'UPDATE users SET password = ?, last_password_change = NOW() WHERE id = ?',
                [hashedPassword, id]
            );

            return true;

        } catch (error) {
            console.error('User.changePassword error:', error.message);
            throw error;
        }
    }

    // ============================================
    // DELETE USER
    // ============================================
    static async delete(id) {
        try {
            return await transaction(async (connection) => {
                // Get user info
                const [users] = await connection.execute(
                    'SELECT * FROM users WHERE id = ?',
                    [id]
                );

                if (users.length === 0) {
                    throw new Error('User not found');
                }

                const user = users[0];

                // Prevent deleting the first admin
                if (user.is_first_user) {
                    throw new Error('Cannot delete the primary administrator account');
                }

                // Free node resources from user's servers
                const [servers] = await connection.execute(
                    'SELECT node_id, memory, disk FROM servers WHERE user_id = ?',
                    [id]
                );

                for (const server of servers) {
                    await connection.execute(
                        `UPDATE nodes 
                         SET allocated_memory = allocated_memory - ?,
                             allocated_disk = allocated_disk - ?
                         WHERE id = ?`,
                        [server.memory, server.disk, server.node_id]
                    );
                }

                // Free allocations
                await connection.execute(
                    `UPDATE allocations 
                     SET server_id = NULL, status = 'available' 
                     WHERE server_id IN (SELECT id FROM servers WHERE user_id = ?)`,
                    [id]
                );

                // Delete related records
                await connection.execute('DELETE FROM activity_logs WHERE user_id = ?', [id]);
                await connection.execute('DELETE FROM api_keys WHERE user_id = ?', [id]);
                await connection.execute('DELETE FROM admin_permissions WHERE user_id = ?', [id]);
                await connection.execute('DELETE FROM backups WHERE server_id IN (SELECT id FROM servers WHERE user_id = ?)', [id]);
                await connection.execute('DELETE FROM servers WHERE user_id = ?', [id]);

                // Delete user
                const [result] = await connection.execute(
                    'DELETE FROM users WHERE id = ?',
                    [id]
                );

                return result.affectedRows > 0;
            });

        } catch (error) {
            console.error('User.delete error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET ALL USERS
    // ============================================
    static async findAll(filters = {}) {
        const {
            search = null,
            role = null,
            status = null,
            page = 1,
            limit = 20,
            sortBy = 'created_at',
            sortOrder = 'DESC'
        } = filters;

        try {
            let sql = `
                SELECT 
                    u.id, u.username, u.email, u.role, u.is_first_user,
                    u.avatar, u.credits, u.server_limit, u.status,
                    u.last_login, u.created_at,
                    (SELECT COUNT(*) FROM servers WHERE user_id = u.id) as server_count,
                    (SELECT COUNT(*) FROM servers WHERE user_id = u.id AND status = 'running') as running_servers
                FROM users u
            `;

            const conditions = [];
            const params = [];

            if (search) {
                conditions.push('(u.username LIKE ? OR u.email LIKE ?)');
                params.push(`%${search}%`, `%${search}%`);
            }

            if (role) {
                conditions.push('u.role = ?');
                params.push(role);
            }

            if (status) {
                conditions.push('u.status = ?');
                params.push(status);
            }

            if (conditions.length > 0) {
                sql += ' WHERE ' + conditions.join(' AND ');
            }

            // Validate sort field
            const allowedSortFields = ['id', 'username', 'email', 'role', 'status', 'created_at', 'server_count', 'credits'];
            const sortField = allowedSortFields.includes(sortBy) ? sortBy : 'created_at';
            const sortDir = sortOrder === 'ASC' ? 'ASC' : 'DESC';

            sql += ` ORDER BY ${sortField} ${sortDir}`;

            const offset = (page - 1) * limit;
            sql += ' LIMIT ? OFFSET ?';
            params.push(parseInt(limit), parseInt(offset));

            const [users, countResult] = await Promise.all([
                query(sql, params),
                query('SELECT COUNT(*) as total FROM users')
            ]);

            return {
                users,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: countResult[0].total,
                    pages: Math.ceil(countResult[0].total / limit)
                }
            };

        } catch (error) {
            console.error('User.findAll error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET USER STATISTICS
    // ============================================
    static async getStats(userId) {
        try {
            const stats = await query(
                `SELECT 
                    (SELECT COUNT(*) FROM servers WHERE user_id = ?) as total_servers,
                    (SELECT COUNT(*) FROM servers WHERE user_id = ? AND status = 'running') as running_servers,
                    (SELECT COUNT(*) FROM servers WHERE user_id = ? AND status = 'stopped') as stopped_servers,
                    (SELECT COALESCE(SUM(memory), 0) FROM servers WHERE user_id = ?) as total_memory_used,
                    (SELECT COALESCE(SUM(disk), 0) FROM servers WHERE user_id = ?) as total_disk_used,
                    (SELECT COUNT(*) FROM api_keys WHERE user_id = ? AND status = 'active') as active_api_keys,
                    (SELECT COUNT(*) FROM activity_logs WHERE user_id = ?) as total_actions,
                    (SELECT COUNT(*) FROM backups b JOIN servers s ON b.server_id = s.id WHERE s.user_id = ?) as total_backups
                `,
                [userId, userId, userId, userId, userId, userId, userId, userId]
            );

            return stats[0];

        } catch (error) {
            console.error('User.getStats error:', error.message);
            throw error;
        }
    }

    // ============================================
    // UPDATE LAST LOGIN
    // ============================================
    static async updateLastLogin(id, ip) {
        try {
            await query(
                'UPDATE users SET last_login = NOW(), last_ip = ? WHERE id = ?',
                [ip, id]
            );
        } catch (error) {
            console.error('User.updateLastLogin error:', error.message);
            throw error;
        }
    }

    // ============================================
    // CHECK IF FIRST USER AVAILABLE
    // ============================================
    static async isFirstUserAvailable() {
        try {
            const result = await query('SELECT COUNT(*) as count FROM users');
            return result[0].count === 0;
        } catch (error) {
            console.error('User.isFirstUserAvailable error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET USER PERMISSIONS
    // ============================================
    static getPermissions(role, isFirstUser) {
        // Super admin (first user) gets all permissions
        if (isFirstUser) {
            return ['*'];
        }

        const permissions = {
            admin: [
                'users.read', 'users.write', 'users.delete',
                'servers.read', 'servers.write', 'servers.delete',
                'nodes.read', 'nodes.write', 'nodes.delete',
                'locations.read', 'locations.write', 'locations.delete',
                'settings.read', 'settings.write',
                'api.read', 'api.write', 'api.delete',
                'database.read', 'database.backup',
                'logs.read', 'plugins.manage'
            ],
            user: [
                'servers.read', 'servers.write',
                'profile.read', 'profile.write',
                'api.read', 'api.write'
            ]
        };

        return permissions[role] || permissions.user;
    }

    // ============================================
    // SUSPEND USER
    // ============================================
    static async suspend(id) {
        try {
            await query(
                "UPDATE users SET status = 'suspended' WHERE id = ?",
                [id]
            );

            // Stop all user's running servers
            await query(
                "UPDATE servers SET status = 'suspended' WHERE user_id = ? AND status = 'running'",
                [id]
            );

            return true;
        } catch (error) {
            console.error('User.suspend error:', error.message);
            throw error;
        }
    }

    // ============================================
    // UNSUSPEND USER
    // ============================================
    static async unsuspend(id) {
        try {
            await query(
                "UPDATE users SET status = 'active' WHERE id = ?",
                [id]
            );

            return true;
        } catch (error) {
            console.error('User.unsuspend error:', error.message);
            throw error;
        }
    }

    // ============================================
    // BAN USER
    // ============================================
    static async ban(id, reason = null) {
        try {
            await query(
                "UPDATE users SET status = 'banned' WHERE id = ?",
                [id]
            );

            // Stop all user's servers
            await query(
                "UPDATE servers SET status = 'stopped' WHERE user_id = ?",
                [id]
            );

            // Revoke all API keys
            await query(
                "UPDATE api_keys SET status = 'revoked' WHERE user_id = ?",
                [id]
            );

            if (reason) {
                await query(
                    `INSERT INTO activity_logs (user_id, action, description) 
                     VALUES (?, 'user_banned', ?)`,
                    [id, `User banned. Reason: ${reason}`]
                );
            }

            return true;
        } catch (error) {
            console.error('User.ban error:', error.message);
            throw error;
        }
    }

    // ============================================
    // ADD CREDITS
    // ============================================
    static async addCredits(id, amount) {
        try {
            if (amount <= 0) {
                throw new Error('Amount must be positive');
            }

            await query(
                'UPDATE users SET credits = credits + ? WHERE id = ?',
                [amount, id]
            );

            return true;
        } catch (error) {
            console.error('User.addCredits error:', error.message);
            throw error;
        }
    }

    // ============================================
    // DEDUCT CREDITS
    // ============================================
    static async deductCredits(id, amount) {
        try {
            if (amount <= 0) {
                throw new Error('Amount must be positive');
            }

            const users = await query('SELECT credits FROM users WHERE id = ?', [id]);

            if (users.length === 0) {
                throw new Error('User not found');
            }

            if (users[0].credits < amount) {
                throw new Error('Insufficient credits');
            }

            await query(
                'UPDATE users SET credits = credits - ? WHERE id = ?',
                [amount, id]
            );

            return true;
        } catch (error) {
            console.error('User.deductCredits error:', error.message);
            throw error;
        }
    }
}

module.exports = User;