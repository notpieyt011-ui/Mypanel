// ============================================
// Aqua Panel - Server Model
// Location: /var/www/aqua-panel/server/models/Server.js
// ============================================

const { query, transaction } = require('../config/database');
const { v4: uuidv4 } = require('uuid');

class Server {

    // ============================================
    // CREATE SERVER
    // ============================================
    static async create(data) {
        const {
            name,
            userId,
            nodeId,
            locationId,
            eggId = null,
            memory = 4096,
            cpu = 200,
            disk = 51200,
            allocation = null,
            gameType = 'paper',
            gameVersion = '1.21.11',
            description = null,
            expiresInDays = 30,
            startupCommand = null,
            dockerImage = null
        } = data;

        try {
            // Validate required fields
            if (!name || name.length < 2 || name.length > 100) {
                throw new Error('Server name must be between 2 and 100 characters');
            }

            if (!userId) {
                throw new Error('User ID is required');
            }

            if (!nodeId) {
                throw new Error('Node ID is required');
            }

            if (!locationId) {
                throw new Error('Location ID is required');
            }

            // Validate resource limits
            if (memory < 1024 || memory > 65536) {
                throw new Error('Memory must be between 1024 MB and 65536 MB');
            }

            if (cpu < 50 || cpu > 800) {
                throw new Error('CPU must be between 50% and 800%');
            }

            if (disk < 5120 || disk > 512000) {
                throw new Error('Disk must be between 5120 MB and 512000 MB');
            }

            // Check node exists and is active
            const node = await query(
                'SELECT * FROM nodes WHERE id = ? AND status = ?',
                [nodeId, 'active']
            );

            if (node.length === 0) {
                throw new Error('Node not found or inactive');
            }

            const nodeData = node[0];
            const availableMemory = nodeData.total_memory - (nodeData.allocated_memory || 0);
            const availableDisk = nodeData.total_disk - (nodeData.allocated_disk || 0);

            if (memory > availableMemory) {
                throw new Error(`Insufficient node memory. Available: ${availableMemory}MB, Requested: ${memory}MB`);
            }

            if (disk > availableDisk) {
                throw new Error(`Insufficient node disk. Available: ${availableDisk}MB, Requested: ${disk}MB`);
            }

            // Check user server limit
            const userData = await query(
                'SELECT server_limit FROM users WHERE id = ?',
                [userId]
            );

            if (userData.length > 0) {
                const serverCount = await query(
                    'SELECT COUNT(*) as count FROM servers WHERE user_id = ?',
                    [userId]
                );

                if (serverCount[0].count >= userData[0].server_limit) {
                    throw new Error(`Server limit reached (${userData[0].server_limit} max)`);
                }
            }

            // Calculate expiry date
            const expiresAt = new Date();
            expiresAt.setDate(expiresAt.getDate() + expiresInDays);

            // Generate UUID
            const serverUuid = uuidv4();

            // Create server in transaction
            const serverId = await transaction(async (connection) => {
                // Insert server
                const [result] = await connection.execute(
                    `INSERT INTO servers (
                        uuid, name, description, user_id, node_id, location_id,
                        egg_id, memory, cpu, disk, allocation, game_type,
                        game_version, expires_at, startup_command, docker_image, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'installing')`,
                    [
                        serverUuid, name, description, userId, nodeId, locationId,
                        eggId, memory, cpu, disk, allocation, gameType,
                        gameVersion, expiresAt, startupCommand, dockerImage
                    ]
                );

                const newServerId = result.insertId;

                // Update node allocated resources
                await connection.execute(
                    `UPDATE nodes 
                     SET allocated_memory = allocated_memory + ?,
                         allocated_disk = allocated_disk + ?
                     WHERE id = ?`,
                    [memory, disk, nodeId]
                );

                // Auto-assign allocation if not provided
                if (!allocation) {
                    const [availableAlloc] = await connection.execute(
                        `SELECT * FROM allocations 
                         WHERE node_id = ? AND status = 'available' 
                         LIMIT 1`,
                        [nodeId]
                    );

                    if (availableAlloc.length > 0) {
                        const alloc = availableAlloc[0];
                        await connection.execute(
                            `UPDATE allocations 
                             SET server_id = ?, status = 'assigned' 
                             WHERE id = ?`,
                            [newServerId, alloc.id]
                        );

                        await connection.execute(
                            `UPDATE servers 
                             SET allocation = ? 
                             WHERE id = ?`,
                            [`${alloc.ip_address}:${alloc.port}`, newServerId]
                        );
                    }
                }

                return newServerId;
            });

            // Log activity
            await query(
                `INSERT INTO activity_logs (user_id, server_id, action, description) 
                 VALUES (?, ?, 'server_create', ?)`,
                [userId, serverId, `Created server: ${name}`]
            );

            // Return created server
            return await Server.findById(serverId);

        } catch (error) {
            console.error('Server.create error:', error.message);
            throw error;
        }
    }

    // ============================================
    // FIND SERVER BY ID
    // ============================================
    static async findById(id) {
        try {
            const servers = await query(
                `SELECT 
                    s.*,
                    u.username as owner_username,
                    u.email as owner_email,
                    n.name as node_name,
                    n.fqdn as node_fqdn,
                    l.name as location_name,
                    l.flag as location_flag,
                    l.country_code as location_country,
                    e.name as egg_name,
                    e.type as egg_type,
                    (SELECT COUNT(*) FROM backups WHERE server_id = s.id) as backup_count,
                    DATEDIFF(s.expires_at, NOW()) as days_remaining
                FROM servers s
                LEFT JOIN users u ON s.user_id = u.id
                LEFT JOIN nodes n ON s.node_id = n.id
                LEFT JOIN locations l ON s.location_id = l.id
                LEFT JOIN eggs e ON s.egg_id = e.id
                WHERE s.id = ?`,
                [id]
            );

            if (servers.length === 0) return null;

            const server = servers[0];

            // Get allocations
            const allocations = await query(
                'SELECT * FROM allocations WHERE server_id = ?',
                [id]
            );

            // Get recent activity
            const recentActivity = await query(
                `SELECT * FROM activity_logs 
                 WHERE server_id = ? 
                 ORDER BY created_at DESC 
                 LIMIT 20`,
                [id]
            );

            // Get backups
            const backups = await query(
                `SELECT id, uuid, name, size, type, status, created_at 
                 FROM backups 
                 WHERE server_id = ? 
                 ORDER BY created_at DESC 
                 LIMIT 10`,
                [id]
            );

            return {
                ...server,
                allocations,
                recentActivity,
                backups,
                daysUntilExpiry: server.days_remaining || 0
            };

        } catch (error) {
            console.error('Server.findById error:', error.message);
            throw error;
        }
    }

    // ============================================
    // FIND SERVER BY UUID
    // ============================================
    static async findByUuid(uuid) {
        try {
            const servers = await query('SELECT id FROM servers WHERE uuid = ?', [uuid]);
            
            if (servers.length === 0) return null;
            
            return await Server.findById(servers[0].id);
            
        } catch (error) {
            console.error('Server.findByUuid error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET ALL SERVERS
    // ============================================
    static async findAll(filters = {}) {
        const {
            userId = null,
            nodeId = null,
            locationId = null,
            status = null,
            search = null,
            gameType = null,
            expiringSoon = false,
            page = 1,
            limit = 20,
            sortBy = 'created_at',
            sortOrder = 'DESC'
        } = filters;

        try {
            let sql = `
                SELECT 
                    s.*,
                    u.username as owner_username,
                    n.name as node_name,
                    l.name as location_name,
                    l.flag as location_flag,
                    e.name as egg_name,
                    DATEDIFF(s.expires_at, NOW()) as days_remaining
                FROM servers s
                LEFT JOIN users u ON s.user_id = u.id
                LEFT JOIN nodes n ON s.node_id = n.id
                LEFT JOIN locations l ON s.location_id = l.id
                LEFT JOIN eggs e ON s.egg_id = e.id
            `;

            const conditions = [];
            const params = [];

            if (userId) {
                conditions.push('s.user_id = ?');
                params.push(userId);
            }

            if (nodeId) {
                conditions.push('s.node_id = ?');
                params.push(nodeId);
            }

            if (locationId) {
                conditions.push('s.location_id = ?');
                params.push(locationId);
            }

            if (status) {
                conditions.push('s.status = ?');
                params.push(status);
            }

            if (gameType) {
                conditions.push('s.game_type = ?');
                params.push(gameType);
            }

            if (search) {
                conditions.push('(s.name LIKE ? OR s.uuid LIKE ? OR u.username LIKE ?)');
                params.push(`%${search}%`, `%${search}%`, `%${search}%`);
            }

            if (expiringSoon) {
                conditions.push('s.expires_at <= DATE_ADD(NOW(), INTERVAL 7 DAY) AND s.expires_at > NOW()');
            }

            if (conditions.length > 0) {
                sql += ' WHERE ' + conditions.join(' AND ');
            }

            // Validate sort field
            const allowedSortFields = ['name', 'status', 'memory', 'cpu', 'disk', 'created_at', 'expires_at', 'days_remaining'];
            const sortField = allowedSortFields.includes(sortBy) ? sortBy : 'created_at';
            const sortDir = sortOrder === 'ASC' ? 'ASC' : 'DESC';

            sql += ` ORDER BY ${sortField} ${sortDir}`;

            const offset = (page - 1) * limit;
            sql += ' LIMIT ? OFFSET ?';
            params.push(parseInt(limit), parseInt(offset));

            const [servers, countResult] = await Promise.all([
                query(sql, params),
                query('SELECT COUNT(*) as total FROM servers')
            ]);

            return {
                servers,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: countResult[0].total,
                    pages: Math.ceil(countResult[0].total / limit)
                }
            };

        } catch (error) {
            console.error('Server.findAll error:', error.message);
            throw error;
        }
    }

    // ============================================
    // UPDATE SERVER
    // ============================================
    static async update(id, data) {
        try {
            const allowedFields = [
                'name', 'description', 'memory', 'cpu', 'disk',
                'game_version', 'status', 'allocation', 'node_id',
                'location_id', 'egg_id', 'expires_at'
            ];

            const updates = [];
            const params = [];

            for (const [key, value] of Object.entries(data)) {
                if (allowedFields.includes(key) && value !== undefined) {
                    updates.push(`${key} = ?`);
                    params.push(value);
                }
            }

            if (updates.length === 0) return false;

            // If changing node, update resource allocations
            if (data.node_id) {
                const oldServer = await query(
                    'SELECT node_id, memory, disk FROM servers WHERE id = ?',
                    [id]
                );

                if (oldServer.length > 0) {
                    const old = oldServer[0];

                    // Free old node resources
                    await query(
                        `UPDATE nodes 
                         SET allocated_memory = allocated_memory - ?,
                             allocated_disk = allocated_disk - ?
                         WHERE id = ?`,
                        [old.memory, old.disk, old.node_id]
                    );

                    // Allocate new node resources
                    const newMemory = data.memory || old.memory;
                    const newDisk = data.disk || old.disk;

                    await query(
                        `UPDATE nodes 
                         SET allocated_memory = allocated_memory + ?,
                             allocated_disk = allocated_disk + ?
                         WHERE id = ?`,
                        [newMemory, newDisk, data.node_id]
                    );
                }
            }

            params.push(id);

            await query(
                `UPDATE servers SET ${updates.join(', ')} WHERE id = ?`,
                params
            );

            return true;

        } catch (error) {
            console.error('Server.update error:', error.message);
            throw error;
        }
    }

    // ============================================
    // DELETE SERVER
    // ============================================
    static async delete(id) {
        try {
            return await transaction(async (connection) => {
                // Get server info
                const [servers] = await connection.execute(
                    'SELECT * FROM servers WHERE id = ?',
                    [id]
                );

                if (servers.length === 0) {
                    throw new Error('Server not found');
                }

                const server = servers[0];

                // Free node resources
                await connection.execute(
                    `UPDATE nodes 
                     SET allocated_memory = allocated_memory - ?,
                         allocated_disk = allocated_disk - ?
                     WHERE id = ?`,
                    [server.memory, server.disk, server.node_id]
                );

                // Free allocations
                await connection.execute(
                    `UPDATE allocations 
                     SET server_id = NULL, status = 'available' 
                     WHERE server_id = ?`,
                    [id]
                );

                // Delete backups
                await connection.execute(
                    'DELETE FROM backups WHERE server_id = ?',
                    [id]
                );

                // Delete activity logs
                await connection.execute(
                    'DELETE FROM activity_logs WHERE server_id = ?',
                    [id]
                );

                // Delete server
                const [result] = await connection.execute(
                    'DELETE FROM servers WHERE id = ?',
                    [id]
                );

                return result.affectedRows > 0;
            });

        } catch (error) {
            console.error('Server.delete error:', error.message);
            throw error;
        }
    }

    // ============================================
    // UPDATE SERVER STATUS
    // ============================================
    static async updateStatus(id, status) {
        try {
            const validStatuses = [
                'installing', 'running', 'stopped', 'starting', 
                'stopping', 'error', 'suspended'
            ];

            if (!validStatuses.includes(status)) {
                throw new Error(`Invalid status: ${status}`);
            }

            await query(
                'UPDATE servers SET status = ? WHERE id = ?',
                [status, id]
            );

            if (status === 'running') {
                await query(
                    'UPDATE servers SET last_started = NOW() WHERE id = ?',
                    [id]
                );
            }

            return true;

        } catch (error) {
            console.error('Server.updateStatus error:', error.message);
            throw error;
        }
    }

    // ============================================
    // EXTEND SERVER EXPIRY
    // ============================================
    static async extendExpiry(id, days) {
        try {
            if (days < 1 || days > 365) {
                throw new Error('Days must be between 1 and 365');
            }

            const servers = await query(
                'SELECT expires_at FROM servers WHERE id = ?',
                [id]
            );

            if (servers.length === 0) {
                throw new Error('Server not found');
            }

            const currentExpiry = servers[0].expires_at 
                ? new Date(servers[0].expires_at) 
                : new Date();

            currentExpiry.setDate(currentExpiry.getDate() + days);

            await query(
                'UPDATE servers SET expires_at = ? WHERE id = ?',
                [currentExpiry, id]
            );

            return {
                newExpiry: currentExpiry,
                daysAdded: days
            };

        } catch (error) {
            console.error('Server.extendExpiry error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET SERVER STATISTICS
    // ============================================
    static async getStats(serverId) {
        try {
            const stats = await query(
                `SELECT 
                    s.*,
                    (SELECT COUNT(*) FROM backups WHERE server_id = s.id) as backup_count,
                    (SELECT COUNT(*) FROM activity_logs WHERE server_id = s.id) as activity_count,
                    DATEDIFF(s.expires_at, NOW()) as days_remaining,
                    TIMESTAMPDIFF(SECOND, s.created_at, NOW()) as seconds_since_creation
                FROM servers s
                WHERE s.id = ?`,
                [serverId]
            );

            if (stats.length === 0) return null;

            return stats[0];

        } catch (error) {
            console.error('Server.getStats error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET RESOURCE USAGE (Simulated)
    // ============================================
    static async getResourceUsage(serverId) {
        try {
            const server = await query(
                'SELECT memory, cpu, disk FROM servers WHERE id = ?',
                [serverId]
            );

            if (server.length === 0) return null;

            return {
                memory: {
                    allocated: server[0].memory,
                    used: Math.floor(Math.random() * server[0].memory * 0.8),
                    percent: Math.floor(Math.random() * 80)
                },
                cpu: {
                    allocated: server[0].cpu,
                    used: Math.floor(Math.random() * server[0].cpu * 0.7),
                    percent: Math.floor(Math.random() * 70)
                },
                disk: {
                    allocated: server[0].disk,
                    used: Math.floor(Math.random() * server[0].disk * 0.5),
                    percent: Math.floor(Math.random() * 50)
                },
                players: {
                    online: Math.floor(Math.random() * 20),
                    max: 50
                },
                uptime: Math.floor(Math.random() * 86400),
                tps: (Math.random() * 5 + 15).toFixed(1)
            };

        } catch (error) {
            console.error('Server.getResourceUsage error:', error.message);
            throw error;
        }
    }

    // ============================================
    // BULK DELETE SERVERS
    // ============================================
    static async bulkDelete(serverIds) {
        try {
            let deletedCount = 0;

            for (const id of serverIds) {
                try {
                    await Server.delete(id);
                    deletedCount++;
                } catch (err) {
                    console.error(`Failed to delete server ${id}:`, err.message);
                }
            }

            return deletedCount;

        } catch (error) {
            console.error('Server.bulkDelete error:', error.message);
            throw error;
        }
    }

    // ============================================
    // BULK UPDATE STATUS
    // ============================================
    static async bulkUpdateStatus(serverIds, status) {
        try {
            const validStatuses = ['running', 'stopped', 'suspended'];

            if (!validStatuses.includes(status)) {
                throw new Error(`Invalid bulk status: ${status}`);
            }

            await query(
                `UPDATE servers SET status = ? WHERE id IN (?)`,
                [status, serverIds]
            );

            return serverIds.length;

        } catch (error) {
            console.error('Server.bulkUpdateStatus error:', error.message);
            throw error;
        }
    }

    // ============================================
    // CHECK EXPIRED SERVERS
    // ============================================
    static async checkExpiredServers() {
        try {
            const expiredServers = await query(
                `SELECT id, name, user_id 
                 FROM servers 
                 WHERE expires_at < NOW() 
                 AND status != 'stopped'
                 AND status != 'suspended'`
            );

            if (expiredServers.length > 0) {
                const serverIds = expiredServers.map(s => s.id);

                await query(
                    `UPDATE servers SET status = 'stopped' WHERE id IN (?)`,
                    [serverIds]
                );

                // Log for each server
                for (const server of expiredServers) {
                    await query(
                        `INSERT INTO activity_logs (user_id, server_id, action, description) 
                         VALUES (?, ?, 'server_expired', ?)`,
                        [server.user_id, server.id, `Server expired: ${server.name}`]
                    );
                }
            }

            return expiredServers.length;

        } catch (error) {
            console.error('Server.checkExpiredServers error:', error.message);
            throw error;
        }
    }
}

module.exports = Server;