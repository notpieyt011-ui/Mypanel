// ============================================
// Aqua Panel - Location Model
// Location: /var/www/aqua-panel/server/models/Location.js
// ============================================

const { query, transaction } = require('../config/database');

class Location {

    // ============================================
    // CREATE LOCATION
    // ============================================
    static async create(data) {
        const {
            name,
            shortCode,
            description = null,
            flag = null,
            countryCode = null,
            city = null,
            timezone = 'UTC',
            createdBy = null
        } = data;

        try {
            // Validate required fields
            if (!name || name.length < 2 || name.length > 100) {
                throw new Error('Location name must be between 2 and 100 characters');
            }

            if (!shortCode || shortCode.length < 2 || shortCode.length > 10) {
                throw new Error('Short code must be between 2 and 10 characters');
            }

            // Validate short code format (lowercase, numbers, hyphens only)
            if (!/^[a-z0-9-]+$/.test(shortCode)) {
                throw new Error('Short code can only contain lowercase letters, numbers, and hyphens');
            }

            // Check for duplicate short code
            const existingCode = await query(
                'SELECT id FROM locations WHERE short_code = ?',
                [shortCode.toLowerCase()]
            );

            if (existingCode.length > 0) {
                throw new Error('A location with this short code already exists');
            }

            // Check for duplicate name
            const existingName = await query(
                'SELECT id FROM locations WHERE name = ?',
                [name]
            );

            if (existingName.length > 0) {
                throw new Error('A location with this name already exists');
            }

            // Validate country code
            const validCountryCodes = [
                'US', 'GB', 'DE', 'FR', 'JP', 'SG', 'AU', 'BR', 'IN',
                'CA', 'NL', 'KR', 'HK', 'RU', 'ZA', 'AE', 'SE', 'NO',
                'FI', 'DK', 'PL', 'IT', 'ES', 'PT', 'MX', 'AR', 'CL'
            ];

            if (countryCode && !validCountryCodes.includes(countryCode.toUpperCase())) {
                throw new Error(`Invalid country code: ${countryCode}`);
            }

            // Create location
            const result = await query(
                `INSERT INTO locations (
                    name, short_code, description, flag, 
                    country_code, city, timezone
                ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [
                    name,
                    shortCode.toLowerCase(),
                    description,
                    flag,
                    countryCode ? countryCode.toUpperCase() : null,
                    city,
                    timezone
                ]
            );

            // Log activity if user provided
            if (createdBy) {
                await query(
                    `INSERT INTO activity_logs (user_id, action, description) 
                     VALUES (?, 'location_create', ?)`,
                    [createdBy, `Created location: ${name} (${shortCode})`]
                );
            }

            // Return created location
            return await Location.findById(result.insertId);

        } catch (error) {
            console.error('Location.create error:', error.message);
            throw error;
        }
    }

    // ============================================
    // FIND LOCATION BY ID
    // ============================================
    static async findById(id) {
        try {
            const locations = await query(
                `SELECT 
                    l.*,
                    (SELECT COUNT(*) FROM servers WHERE location_id = l.id) as server_count,
                    (SELECT COUNT(*) FROM servers WHERE location_id = l.id AND status = 'running') as running_servers,
                    (SELECT COUNT(*) FROM servers WHERE location_id = l.id AND status = 'stopped') as stopped_servers,
                    (SELECT COUNT(*) FROM servers WHERE location_id = l.id AND status = 'installing') as installing_servers,
                    (SELECT COUNT(*) FROM servers WHERE location_id = l.id AND status = 'error') as error_servers,
                    (SELECT COUNT(DISTINCT user_id) FROM servers WHERE location_id = l.id) as unique_users,
                    (SELECT COUNT(DISTINCT node_id) FROM servers WHERE location_id = l.id) as active_nodes,
                    (SELECT SUM(memory) FROM servers WHERE location_id = l.id) as total_memory_allocated,
                    (SELECT SUM(disk) FROM servers WHERE location_id = l.id) as total_disk_allocated,
                    (SELECT SUM(cpu) FROM servers WHERE location_id = l.id) as total_cpu_allocated
                FROM locations l
                WHERE l.id = ?`,
                [id]
            );

            if (locations.length === 0) return null;

            const location = locations[0];

            // Get servers in this location
            const servers = await query(
                `SELECT s.id, s.name, s.status, s.memory, s.cpu, s.disk,
                        u.username as owner_name,
                        n.name as node_name
                 FROM servers s
                 LEFT JOIN users u ON s.user_id = u.id
                 LEFT JOIN nodes n ON s.node_id = n.id
                 WHERE s.location_id = ?
                 ORDER BY s.created_at DESC
                 LIMIT 10`,
                [id]
            );

            // Get game type distribution
            const gameTypes = await query(
                `SELECT game_type, COUNT(*) as count
                 FROM servers
                 WHERE location_id = ?
                 GROUP BY game_type
                 ORDER BY count DESC`,
                [id]
            );

            // Get servers expiring soon (within 7 days)
            const expiringServers = await query(
                `SELECT COUNT(*) as count
                 FROM servers
                 WHERE location_id = ?
                 AND expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)`,
                [id]
            );

            return {
                ...location,
                servers,
                gameTypeDistribution: gameTypes,
                expiringServers: expiringServers[0].count,
                memoryUsagePercent: location.total_memory_allocated > 0 ? 
                    Math.round((location.total_memory_allocated / (location.total_memory_allocated + 1000)) * 100) : 0
            };

        } catch (error) {
            console.error('Location.findById error:', error.message);
            throw error;
        }
    }

    // ============================================
    // FIND LOCATION BY SHORT CODE
    // ============================================
    static async findByShortCode(shortCode) {
        try {
            const locations = await query(
                'SELECT id FROM locations WHERE short_code = ?',
                [shortCode.toLowerCase()]
            );

            if (locations.length === 0) return null;

            return await Location.findById(locations[0].id);

        } catch (error) {
            console.error('Location.findByShortCode error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET ALL LOCATIONS
    // ============================================
    static async findAll(filters = {}) {
        const {
            status = null,
            countryCode = null,
            search = null,
            page = 1,
            limit = 50,
            sortBy = 'name',
            sortOrder = 'ASC'
        } = filters;

        try {
            let sql = `
                SELECT 
                    l.*,
                    (SELECT COUNT(*) FROM servers WHERE location_id = l.id) as server_count,
                    (SELECT COUNT(*) FROM servers WHERE location_id = l.id AND status = 'running') as running_servers
                FROM locations l
            `;

            const conditions = [];
            const params = [];

            if (status) {
                conditions.push('l.status = ?');
                params.push(status);
            }

            if (countryCode) {
                conditions.push('l.country_code = ?');
                params.push(countryCode.toUpperCase());
            }

            if (search) {
                conditions.push('(l.name LIKE ? OR l.city LIKE ? OR l.country_code LIKE ? OR l.description LIKE ?)');
                params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
            }

            if (conditions.length > 0) {
                sql += ' WHERE ' + conditions.join(' AND ');
            }

            // Validate sort field
            const allowedSortFields = ['name', 'short_code', 'country_code', 'city', 'server_count', 'created_at'];
            const sortField = allowedSortFields.includes(sortBy) ? sortBy : 'name';
            const sortDir = sortOrder === 'ASC' ? 'ASC' : 'DESC';

            sql += ` ORDER BY ${sortField} ${sortDir}`;

            const offset = (page - 1) * limit;
            sql += ' LIMIT ? OFFSET ?';
            params.push(parseInt(limit), parseInt(offset));

            const [locations, countResult] = await Promise.all([
                query(sql, params),
                query('SELECT COUNT(*) as total FROM locations')
            ]);

            return {
                locations,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: countResult[0].total,
                    pages: Math.ceil(countResult[0].total / limit)
                }
            };

        } catch (error) {
            console.error('Location.findAll error:', error.message);
            throw error;
        }
    }

    // ============================================
    // UPDATE LOCATION
    // ============================================
    static async update(id, data) {
        try {
            const allowedFields = [
                'name', 'short_code', 'description', 'flag',
                'country_code', 'city', 'timezone', 'status'
            ];

            const updates = [];
            const params = [];

            for (const [key, value] of Object.entries(data)) {
                if (allowedFields.includes(key) && value !== undefined) {
                    // Validate specific fields
                    if (key === 'short_code' && value) {
                        if (!/^[a-z0-9-]+$/.test(value)) {
                            throw new Error('Short code can only contain lowercase letters, numbers, and hyphens');
                        }
                        params.push(value.toLowerCase());
                    } else if (key === 'status' && value) {
                        const validStatuses = ['active', 'inactive'];
                        if (!validStatuses.includes(value)) {
                            throw new Error(`Invalid status: ${value}`);
                        }
                        // Check if deactivating with servers
                        if (value === 'inactive') {
                            const serverCount = await query(
                                'SELECT COUNT(*) as count FROM servers WHERE location_id = ?',
                                [id]
                            );
                            if (serverCount[0].count > 0) {
                                throw new Error('Cannot deactivate location with active servers');
                            }
                        }
                        params.push(value);
                    } else {
                        params.push(value);
                    }
                    updates.push(`${key} = ?`);
                }
            }

            if (updates.length === 0) return false;

            params.push(id);

            await query(
                `UPDATE locations SET ${updates.join(', ')} WHERE id = ?`,
                params
            );

            return true;

        } catch (error) {
            console.error('Location.update error:', error.message);
            throw error;
        }
    }

    // ============================================
    // DELETE LOCATION
    // ============================================
    static async delete(id) {
        try {
            // Check if location has servers
            const serverCount = await query(
                'SELECT COUNT(*) as count FROM servers WHERE location_id = ?',
                [id]
            );

            if (serverCount[0].count > 0) {
                throw new Error(`Cannot delete location with ${serverCount[0].count} server(s). Reassign servers first.`);
            }

            const result = await query('DELETE FROM locations WHERE id = ?', [id]);

            return result.affectedRows > 0;

        } catch (error) {
            console.error('Location.delete error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET LOCATION STATISTICS
    // ============================================
    static async getStats(locationId) {
        try {
            const stats = await query(
                `SELECT 
                    COUNT(*) as total_servers,
                    SUM(CASE WHEN status = 'running' THEN 1 ELSE 0 END) as running,
                    SUM(CASE WHEN status = 'stopped' THEN 1 ELSE 0 END) as stopped,
                    SUM(CASE WHEN status = 'installing' THEN 1 ELSE 0 END) as installing,
                    SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as errors,
                    SUM(memory) as total_memory,
                    SUM(disk) as total_disk,
                    SUM(cpu) as total_cpu,
                    COUNT(DISTINCT user_id) as unique_users,
                    COUNT(DISTINCT node_id) as active_nodes
                FROM servers
                WHERE location_id = ?`,
                [locationId]
            );

            if (stats.length === 0) return null;

            // Get game type breakdown
            const gameTypes = await query(
                `SELECT game_type, COUNT(*) as count
                 FROM servers
                 WHERE location_id = ?
                 GROUP BY game_type
                 ORDER BY count DESC`,
                [locationId]
            );

            // Get monthly server creation trend (last 6 months)
            const monthlyTrend = await query(
                `SELECT 
                    DATE_FORMAT(created_at, '%Y-%m') as month,
                    COUNT(*) as count
                 FROM servers
                 WHERE location_id = ?
                 AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
                 GROUP BY month
                 ORDER BY month ASC`,
                [locationId]
            );

            return {
                ...stats[0],
                gameTypeBreakdown: gameTypes,
                monthlyTrend
            };

        } catch (error) {
            console.error('Location.getStats error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET SUPPORTED COUNTRIES
    // ============================================
    static getSupportedCountries() {
        return [
            { code: 'US', name: 'United States', flag: 'US', continent: 'North America' },
            { code: 'GB', name: 'United Kingdom', flag: 'GB', continent: 'Europe' },
            { code: 'DE', name: 'Germany', flag: 'DE', continent: 'Europe' },
            { code: 'FR', name: 'France', flag: 'FR', continent: 'Europe' },
            { code: 'JP', name: 'Japan', flag: 'JP', continent: 'Asia' },
            { code: 'SG', name: 'Singapore', flag: 'SG', continent: 'Asia' },
            { code: 'AU', name: 'Australia', flag: 'AU', continent: 'Oceania' },
            { code: 'BR', name: 'Brazil', flag: 'BR', continent: 'South America' },
            { code: 'IN', name: 'India', flag: 'IN', continent: 'Asia' },
            { code: 'CA', name: 'Canada', flag: 'CA', continent: 'North America' },
            { code: 'NL', name: 'Netherlands', flag: 'NL', continent: 'Europe' },
            { code: 'KR', name: 'South Korea', flag: 'KR', continent: 'Asia' },
            { code: 'ZA', name: 'South Africa', flag: 'ZA', continent: 'Africa' },
            { code: 'AE', name: 'UAE', flag: 'AE', continent: 'Asia' },
            { code: 'IT', name: 'Italy', flag: 'IT', continent: 'Europe' },
            { code: 'ES', name: 'Spain', flag: 'ES', continent: 'Europe' },
            { code: 'MX', name: 'Mexico', flag: 'MX', continent: 'North America' },
            { code: 'PL', name: 'Poland', flag: 'PL', continent: 'Europe' },
            { code: 'SE', name: 'Sweden', flag: 'SE', continent: 'Europe' },
            { code: 'HK', name: 'Hong Kong', flag: 'HK', continent: 'Asia' }
        ];
    }

    // ============================================
    // GET LOCATIONS BY CONTINENT
    // ============================================
    static async getByContinent(continent) {
        try {
            const continentMap = {
                'north_america': ['US', 'CA', 'MX'],
                'south_america': ['BR', 'AR', 'CL'],
                'europe': ['GB', 'DE', 'FR', 'NL', 'SE', 'PL', 'IT', 'ES', 'DK', 'FI', 'NO'],
                'asia': ['JP', 'SG', 'IN', 'KR', 'HK', 'AE'],
                'oceania': ['AU'],
                'africa': ['ZA']
            };

            const countryCodes = continentMap[continent] || [];

            if (countryCodes.length === 0) return [];

            const locations = await query(
                `SELECT l.*,
                        (SELECT COUNT(*) FROM servers WHERE location_id = l.id) as server_count
                 FROM locations l
                 WHERE l.country_code IN (?) AND l.status = 'active'
                 ORDER BY l.name ASC`,
                [countryCodes]
            );

            return locations;

        } catch (error) {
            console.error('Location.getByContinent error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET POPULAR LOCATIONS
    // ============================================
    static async getPopular(limit = 5) {
        try {
            const locations = await query(
                `SELECT 
                    l.*,
                    COUNT(s.id) as server_count
                 FROM locations l
                 LEFT JOIN servers s ON l.id = s.location_id
                 WHERE l.status = 'active'
                 GROUP BY l.id
                 ORDER BY server_count DESC
                 LIMIT ?`,
                [limit]
            );

            return locations;

        } catch (error) {
            console.error('Location.getPopular error:', error.message);
            throw error;
        }
    }

    // ============================================
    // BULK CREATE DEFAULT LOCATIONS
    // ============================================
    static async createDefaults(createdBy = 1) {
        const defaults = [
            { name: 'New York, USA', shortCode: 'us-east', flag: 'US', countryCode: 'US', city: 'New York', timezone: 'America/New_York', description: 'East Coast US data center' },
            { name: 'London, UK', shortCode: 'uk-london', flag: 'GB', countryCode: 'GB', city: 'London', timezone: 'Europe/London', description: 'European data center' },
            { name: 'Frankfurt, Germany', shortCode: 'de-frankfurt', flag: 'DE', countryCode: 'DE', city: 'Frankfurt', timezone: 'Europe/Berlin', description: 'Central European data center' },
            { name: 'Singapore', shortCode: 'sg-singapore', flag: 'SG', countryCode: 'SG', city: 'Singapore', timezone: 'Asia/Singapore', description: 'Asian data center' },
            { name: 'Mumbai, India', shortCode: 'in-mumbai', flag: 'IN', countryCode: 'IN', city: 'Mumbai', timezone: 'Asia/Kolkata', description: 'South Asian data center' }
        ];

        const created = [];

        for (const loc of defaults) {
            try {
                const existing = await query(
                    'SELECT id FROM locations WHERE short_code = ?',
                    [loc.shortCode]
                );

                if (existing.length === 0) {
                    const result = await Location.create({
                        ...loc,
                        shortCode: loc.shortCode,
                        countryCode: loc.countryCode,
                        createdBy
                    });
                    created.push(result);
                }
            } catch (err) {
                console.error(`Failed to create default location ${loc.name}:`, err.message);
            }
        }

        return created;
    }
}

module.exports = Location;