// ============================================
// Aqua Panel - Node Model
// Location: /var/www/aqua-panel/server/models/Node.js
// ============================================

const { query, transaction } = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');

class Node {

    // ============================================
    // CREATE NODE
    // ============================================
    static async create(data) {
        const {
            name,
            description = null,
            fqdn,
            totalMemory,
            totalDisk,
            portRangeStart = null,
            portRangeEnd = null,
            daemonListen = 8080,
            daemonSftp = 2022,
            scheme = 'https',
            createdBy = null
        } = data;

        try {
            // Validate required fields
            if (!name || name.length < 2 || name.length > 100) {
                throw new Error('Node name must be between 2 and 100 characters');
            }

            if (!fqdn || fqdn.length < 3) {
                throw new Error('FQDN (Fully Qualified Domain Name) is required');
            }

            // Validate FQDN format
            const fqdnRegex = /^([a-zA-Z0-9]+(-[a-zA-Z0-9]+)*\.)+[a-zA-Z]{2,}$/;
            if (!fqdnRegex.test(fqdn)) {
                throw new Error('Invalid FQDN format (e.g., node1.aquapanel.com)');
            }

            if (!totalMemory || totalMemory < 1024) {
                throw new Error('Total memory must be at least 1024 MB');
            }

            if (!totalDisk || totalDisk < 10240) {
                throw new Error('Total disk must be at least 10240 MB');
            }

            // Check for duplicate FQDN
            const existingFqdn = await query(
                'SELECT id FROM nodes WHERE fqdn = ?',
                [fqdn.toLowerCase()]
            );

            if (existingFqdn.length > 0) {
                throw new Error('A node with this FQDN already exists');
            }

            // Check for duplicate name
            const existingName = await query(
                'SELECT id FROM nodes WHERE name = ?',
                [name]
            );

            if (existingName.length > 0) {
                throw new Error('A node with this name already exists');
            }

            // Generate UUID and daemon token
            const nodeUuid = uuidv4();
            const daemonToken = crypto.randomBytes(32).toString('hex');

            // Create node in transaction
            const nodeId = await transaction(async (connection) => {
                // Insert node
                const [result] = await connection.execute(
                    `INSERT INTO nodes (
                        uuid, name, description, fqdn, scheme,
                        total_memory, total_disk, allocated_memory, allocated_disk,
                        port_range_start, port_range_end,
                        daemon_listen, daemon_sftp, daemon_token
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?, ?)`,
                    [
                        nodeUuid, name, description, fqdn.toLowerCase(), scheme,
                        totalMemory, totalDisk,
                        portRangeStart, portRangeEnd,
                        daemonListen, daemonSftp, daemonToken
                    ]
                );

                const newNodeId = result.insertId;

                // Generate allocations from port range
                if (portRangeStart && portRangeEnd) {
                    const startParts = portRangeStart.split(':');
                    const endParts = portRangeEnd.split(':');

                    if (startParts.length === 2 && endParts.length === 2) {
                        const ip = startParts[0];
                        const startPort = parseInt(startParts[1]);
                        const endPort = parseInt(endParts[1]);

                        if (startPort <= endPort && (endPort - startPort) <= 1000) {
                            const allocationValues = [];
                            for (let port = startPort; port <= endPort; port++) {
                                allocationValues.push([
                                    newNodeId, null, ip, port, 'primary', 'available'
                                ]);
                            }

                            if (allocationValues.length > 0) {
                                await connection.query(
                                    `INSERT INTO allocations (node_id, server_id, ip_address, port, type, status) 
                                     VALUES ?`,
                                    [allocationValues]
                                );
                            }
                        }
                    }
                }

                return newNodeId;
            });

            // Log activity
            if (createdBy) {
                await query(
                    `INSERT INTO activity_logs (user_id, action, description) 
                     VALUES (?, 'node_create', ?)`,
                    [createdBy, `Created node: ${name} (${fqdn})`]
                );
            }

            // Return created node
            return await Node.findById(nodeId);

        } catch (error) {
            console.error('Node.create error:', error.message);
            throw error;
        }
    }

    // ============================================
    // FIND NODE BY ID
    // ============================================
    static async findById(id) {
        try {
            const nodes = await query(
                `SELECT 
                    n.*,
                    (SELECT COUNT(*) FROM servers WHERE node_id = n.id) as server_count,
                    (SELECT COUNT(*) FROM servers WHERE node_id = n.id AND status = 'running') as running_servers,
                    (SELECT COUNT(*) FROM servers WHERE node_id = n.id AND status = 'stopped') as stopped_servers,
                    (SELECT COUNT(*) FROM allocations WHERE node_id = n.id) as total_allocations,
                    (SELECT COUNT(*) FROM allocations WHERE node_id = n.id AND status = 'available') as available_allocations,
                    (SELECT COUNT(*) FROM allocations WHERE node_id = n.id AND status = 'assigned') as assigned_allocations
                FROM nodes n
                WHERE n.id = ?`,
                [id]
            );

            if (nodes.length === 0) return null;

            const node = nodes[0];

            // Calculate usage percentages
            const memoryUsagePercent = node.total_memory > 0 
                ? Math.round((node.allocated_memory / node.total_memory) * 100) 
                : 0;

            const diskUsagePercent = node.total_disk > 0 
                ? Math.round((node.allocated_disk / node.total_disk) * 100) 
                : 0;

            return {
                ...node,
                memoryAvailable: node.total_memory - (node.allocated_memory || 0),
                diskAvailable: node.total_disk - (node.allocated_disk || 0),
                memoryUsagePercent,
                diskUsagePercent,
                isFull: memoryUsagePercent >= 90 || diskUsagePercent >= 90
            };

        } catch (error) {
            console.error('Node.findById error:', error.message);
            throw error;
        }
    }

    // ============================================
    // FIND NODE BY UUID
    // ============================================
    static async findByUuid(uuid) {
        try {
            const nodes = await query('SELECT id FROM nodes WHERE uuid = ?', [uuid]);
            
            if (nodes.length === 0) return null;
            
            return await Node.findById(nodes[0].id);
            
        } catch (error) {
            console.error('Node.findByUuid error:', error.message);
            throw error;
        }
    }

    // ============================================
    // FIND NODE BY FQDN
    // ============================================
    static async findByFqdn(fqdn) {
        try {
            const nodes = await query('SELECT id FROM nodes WHERE fqdn = ?', [fqdn.toLowerCase()]);
            
            if (nodes.length === 0) return null;
            
            return await Node.findById(nodes[0].id);
            
        } catch (error) {
            console.error('Node.findByFqdn error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET ALL NODES
    // ============================================
    static async findAll(filters = {}) {
        const {
            status = null,
            search = null,
            page = 1,
            limit = 20,
            sortBy = 'created_at',
            sortOrder = 'DESC'
        } = filters;

        try {
            let sql = `
                SELECT 
                    n.*,
                    (SELECT COUNT(*) FROM servers WHERE node_id = n.id) as server_count,
                    (SELECT COUNT(*) FROM allocations WHERE node_id = n.id AND status = 'available') as free_allocations
                FROM nodes n
            `;

            const conditions = [];
            const params = [];

            if (status) {
                conditions.push('n.status = ?');
                params.push(status);
            }

            if (search) {
                conditions.push('(n.name LIKE ? OR n.fqdn LIKE ? OR n.description LIKE ?)');
                params.push(`%${search}%`, `%${search}%`, `%${search}%`);
            }

            if (conditions.length > 0) {
                sql += ' WHERE ' + conditions.join(' AND ');
            }

            // Validate sort field
            const allowedSortFields = ['name', 'fqdn', 'total_memory', 'total_disk', 'status', 'created_at', 'server_count'];
            const sortField = allowedSortFields.includes(sortBy) ? sortBy : 'created_at';
            const sortDir = sortOrder === 'ASC' ? 'ASC' : 'DESC';

            sql += ` ORDER BY ${sortField} ${sortDir}`;

            const offset = (page - 1) * limit;
            sql += ' LIMIT ? OFFSET ?';
            params.push(parseInt(limit), parseInt(offset));

            const [nodes, countResult] = await Promise.all([
                query(sql, params),
                query('SELECT COUNT(*) as total FROM nodes')
            ]);

            // Calculate usage for each node
            const nodesWithUsage = nodes.map(node => ({
                ...node,
                memoryUsagePercent: node.total_memory > 0 
                    ? Math.round((node.allocated_memory / node.total_memory) * 100) 
                    : 0,
                diskUsagePercent: node.total_disk > 0 
                    ? Math.round((node.allocated_disk / node.total_disk) * 100) 
                    : 0,
                memoryAvailable: node.total_memory - (node.allocated_memory || 0),
                diskAvailable: node.total_disk - (node.allocated_disk || 0)
            }));

            return {
                nodes: nodesWithUsage,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: countResult[0].total,
                    pages: Math.ceil(countResult[0].total / limit)
                }
            };

        } catch (error) {
            console.error('Node.findAll error:', error.message);
            throw error;
        }
    }

    // ============================================
    // UPDATE NODE
    // ============================================
    static async update(id, data) {
        try {
            const allowedFields = [
                'name', 'description', 'fqdn', 'scheme',
                'total_memory', 'total_disk',
                'daemon_listen', 'daemon_sftp', 'status'
            ];

            const updates = [];
            const params = [];

            for (const [key, value] of Object.entries(data)) {
                if (allowedFields.includes(key) && value !== undefined) {
                    // Validate memory/disk changes
                    if (key === 'total_memory') {
                        const node = await query('SELECT allocated_memory FROM nodes WHERE id = ?', [id]);
                        if (node.length > 0 && value < node[0].allocated_memory) {
                            throw new Error('Cannot reduce memory below current allocation');
                        }
                    }
                    if (key === 'total_disk') {
                        const node = await query('SELECT allocated_disk FROM nodes WHERE id = ?', [id]);
                        if (node.length > 0 && value < node[0].allocated_disk) {
                            throw new Error('Cannot reduce disk below current allocation');
                        }
                    }
                    if (key === 'status') {
                        const validStatuses = ['active', 'inactive', 'maintenance'];
                        if (!validStatuses.includes(value)) {
                            throw new Error(`Invalid status: ${value}`);
                        }
                    }

                    updates.push(`${key} = ?`);
                    params.push(value);
                }
            }

            if (updates.length === 0) return false;

            params.push(id);

            await query(
                `UPDATE nodes SET ${updates.join(', ')} WHERE id = ?`,
                params
            );

            return true;

        } catch (error) {
            console.error('Node.update error:', error.message);
            throw error;
        }
    }

    // ============================================
    // DELETE NODE
    // ============================================
    static async delete(id) {
        try {
            // Check if node has servers
            const serverCount = await query(
                'SELECT COUNT(*) as count FROM servers WHERE node_id = ?',
                [id]
            );

            if (serverCount[0].count > 0) {
                throw new Error(`Cannot delete node with ${serverCount[0].count} server(s). Remove all servers first.`);
            }

            return await transaction(async (connection) => {
                // Delete allocations
                await connection.execute(
                    'DELETE FROM allocations WHERE node_id = ?',
                    [id]
                );

                // Delete node
                const [result] = await connection.execute(
                    'DELETE FROM nodes WHERE id = ?',
                    [id]
                );

                return result.affectedRows > 0;
            });

        } catch (error) {
            console.error('Node.delete error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET NODE STATISTICS
    // ============================================
    static async getStats(nodeId) {
        try {
            const stats = await query(
                `SELECT 
                    n.*,
                    (SELECT COUNT(*) FROM servers WHERE node_id = n.id) as total_servers,
                    (SELECT COUNT(*) FROM servers WHERE node_id = n.id AND status = 'running') as running_servers,
                    (SELECT COUNT(*) FROM servers WHERE node_id = n.id AND status = 'stopped') as stopped_servers,
                    (SELECT COUNT(*) FROM servers WHERE node_id = n.id AND status = 'installing') as installing_servers,
                    (SELECT SUM(memory) FROM servers WHERE node_id = n.id) as total_allocated_memory,
                    (SELECT SUM(disk) FROM servers WHERE node_id = n.id) as total_allocated_disk,
                    (SELECT SUM(cpu) FROM servers WHERE node_id = n.id) as total_allocated_cpu,
                    (SELECT COUNT(*) FROM allocations WHERE node_id = n.id) as total_ports,
                    (SELECT COUNT(*) FROM allocations WHERE node_id = n.id AND status = 'available') as available_ports,
                    (SELECT COUNT(*) FROM allocations WHERE node_id = n.id AND status = 'assigned') as used_ports
                FROM nodes n
                WHERE n.id = ?`,
                [nodeId]
            );

            if (stats.length === 0) return null;

            const nodeStats = stats[0];

            return {
                ...nodeStats,
                memoryUsagePercent: nodeStats.total_memory > 0 
                    ? Math.round((nodeStats.total_allocated_memory / nodeStats.total_memory) * 100) 
                    : 0,
                diskUsagePercent: nodeStats.total_disk > 0 
                    ? Math.round((nodeStats.total_allocated_disk / nodeStats.total_disk) * 100) 
                    : 0,
                portUsagePercent: nodeStats.total_ports > 0 
                    ? Math.round((nodeStats.used_ports / nodeStats.total_ports) * 100) 
                    : 0
            };

        } catch (error) {
            console.error('Node.getStats error:', error.message);
            throw error;
        }
    }

    // ============================================
    // REGENERATE DAEMON TOKEN
    // ============================================
    static async regenerateToken(id) {
        try {
            const newToken = crypto.randomBytes(32).toString('hex');

            await query(
                'UPDATE nodes SET daemon_token = ? WHERE id = ?',
                [newToken, id]
            );

            return newToken;

        } catch (error) {
            console.error('Node.regenerateToken error:', error.message);
            throw error;
        }
    }

    // ============================================
    // UPDATE NODE STATUS
    // ============================================
    static async updateStatus(id, status) {
        try {
            const validStatuses = ['active', 'inactive', 'maintenance'];
            
            if (!validStatuses.includes(status)) {
                throw new Error(`Invalid status: ${status}`);
            }

            // Check if deactivating node with running servers
            if (status === 'inactive') {
                const runningCount = await query(
                    "SELECT COUNT(*) as count FROM servers WHERE node_id = ? AND status = 'running'",
                    [id]
                );

                if (runningCount[0].count > 0) {
                    throw new Error('Cannot deactivate node with running servers');
                }
            }

            await query(
                'UPDATE nodes SET status = ? WHERE id = ?',
                [status, id]
            );

            return true;

        } catch (error) {
            console.error('Node.updateStatus error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET NODE ALLOCATIONS
    // ============================================
    static async getAllocations(nodeId, filters = {}) {
        const { status = null, page = 1, limit = 50 } = filters;

        try {
            let sql = `
                SELECT 
                    a.*,
                    s.name as server_name,
                    s.uuid as server_uuid
                FROM allocations a
                LEFT JOIN servers s ON a.server_id = s.id
                WHERE a.node_id = ?
            `;

            const params = [nodeId];

            if (status) {
                sql += ' AND a.status = ?';
                params.push(status);
            }

            sql += ' ORDER BY a.port ASC';

            const offset = (page - 1) * limit;
            sql += ' LIMIT ? OFFSET ?';
            params.push(parseInt(limit), parseInt(offset));

            const [allocations, countResult] = await Promise.all([
                query(sql, params),
                query('SELECT COUNT(*) as total FROM allocations WHERE node_id = ?', [nodeId])
            ]);

            return {
                allocations,
                summary: {
                    total: countResult[0].total,
                    available: allocations.filter(a => a.status === 'available').length,
                    assigned: allocations.filter(a => a.status === 'assigned').length
                },
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: countResult[0].total,
                    pages: Math.ceil(countResult[0].total / limit)
                }
            };

        } catch (error) {
            console.error('Node.getAllocations error:', error.message);
            throw error;
        }
    }

    // ============================================
    // GET AVAILABLE NODES FOR SERVER CREATION
    // ============================================
    static async getAvailableForServer(memoryRequired = 4096, diskRequired = 51200) {
        try {
            const nodes = await query(
                `SELECT 
                    id, name, fqdn,
                    total_memory, allocated_memory,
                    total_disk, allocated_disk,
                    (total_memory - allocated_memory) as available_memory,
                    (total_disk - allocated_disk) as available_disk,
                    (SELECT COUNT(*) FROM allocations WHERE node_id = nodes.id AND status = 'available') as available_ports
                FROM nodes
                WHERE status = 'active'
                AND (total_memory - allocated_memory) >= ?
                AND (total_disk - allocated_disk) >= ?
                AND (SELECT COUNT(*) FROM allocations WHERE node_id = nodes.id AND status = 'available') > 0
                ORDER BY available_memory DESC`,
                [memoryRequired, diskRequired]
            );

            return nodes;

        } catch (error) {
            console.error('Node.getAvailableForServer error:', error.message);
            throw error;
        }
    }
}

module.exports = Node;