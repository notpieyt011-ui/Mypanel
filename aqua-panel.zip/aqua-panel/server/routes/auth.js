// ============================================
// Aqua Panel - Authentication Routes
// Location: /var/www/aqua-panel/server/routes/auth.js
// ============================================

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { query } = require('../config/database');
const User = require('../models/User');
const auth = require('../middleware/auth');

// ============================================
// POST /api/auth/register
// Register a new user (first user becomes admin)
// ============================================
router.post('/register', async (req, res) => {
    try {
        const { username, email, password, confirmPassword } = req.body;

        // Validate required fields
        if (!username || !email || !password || !confirmPassword) {
            return res.status(400).json({
                error: 'All fields are required: username, email, password, confirmPassword'
            });
        }

        // Validate username
        if (username.length < 3 || username.length > 50) {
            return res.status(400).json({
                error: 'Username must be between 3 and 50 characters'
            });
        }

        if (!/^[a-zA-Z0-9_]+$/.test(username)) {
            return res.status(400).json({
                error: 'Username can only contain letters, numbers, and underscores'
            });
        }

        // Validate email
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            return res.status(400).json({
                error: 'Please provide a valid email address'
            });
        }

        // Validate password
        if (password.length < 8) {
            return res.status(400).json({
                error: 'Password must be at least 8 characters'
            });
        }

        if (password !== confirmPassword) {
            return res.status(400).json({
                error: 'Passwords do not match'
            });
        }

        // Check password strength
        const hasUpper = /[A-Z]/.test(password);
        const hasLower = /[a-z]/.test(password);
        const hasNumber = /[0-9]/.test(password);

        if (!hasUpper || !hasLower || !hasNumber) {
            return res.status(400).json({
                error: 'Password must contain uppercase, lowercase, and numbers'
            });
        }

        // Check if email already exists
        const existingEmail = await User.findByEmail(email);
        if (existingEmail) {
            return res.status(409).json({
                error: 'Email address is already registered'
            });
        }

        // Check if username already exists
        const existingUsername = await User.findByUsername(username);
        if (existingUsername) {
            return res.status(409).json({
                error: 'Username is already taken'
            });
        }

        // Create user
        const user = await User.create({ username, email, password });

        // Generate JWT token
        const token = jwt.sign(
            {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role,
                isFirstUser: user.isFirstUser
            },
            process.env.JWT_SECRET,
            { expiresIn: '30d' }
        );

        // Generate refresh token
        const refreshToken = jwt.sign(
            { id: user.id },
            process.env.JWT_SECRET + '_refresh',
            { expiresIn: '90d' }
        );

        // Log activity
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'register', ?, ?)`,
            [user.id, user.isFirstUser ? 'First user registered as ADMIN' : 'User registered', req.ip]
        );

        // Return success response
        res.status(201).json({
            success: true,
            message: user.isFirstUser
                ? 'Congratulations! You are the FIRST USER and ADMINISTRATOR!'
                : 'Registration successful! Welcome to Aqua Panel!',
            token,
            refreshToken,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role,
                isFirstUser: user.isFirstUser,
                credits: user.credits,
                serverLimit: user.serverLimit
            },
            isFirstUser: user.isFirstUser
        });

    } catch (error) {
        console.error('Register error:', error.message);
        res.status(500).json({
            error: 'Registration failed. Please try again later.'
        });
    }
});

// ============================================
// POST /api/auth/login
// Authenticate user and return JWT token
// ============================================
router.post('/login', async (req, res) => {
    try {
        const { email, password, rememberMe } = req.body;

        // Validate input
        if (!email || !password) {
            return res.status(400).json({
                error: 'Email and password are required'
            });
        }

        // Find user by email
        const user = await User.findByEmail(email);

        if (!user) {
            return res.status(401).json({
                error: 'Invalid email or password'
            });
        }

        // Check account status
        if (user.status === 'banned') {
            return res.status(403).json({
                error: 'Your account has been banned. Please contact support.'
            });
        }

        if (user.status === 'suspended') {
            return res.status(403).json({
                error: 'Your account has been suspended. Please contact support.'
            });
        }

        // Verify password
        const isValidPassword = await User.verifyPassword(user, password);

        if (!isValidPassword) {
            // Log failed login attempt
            await query(
                `INSERT INTO activity_logs (user_id, action, description, ip_address)
                 VALUES (?, 'login_failed', 'Failed login attempt', ?)`,
                [user.id, req.ip]
            );

            return res.status(401).json({
                error: 'Invalid email or password'
            });
        }

        // Generate JWT token
        const tokenExpiry = rememberMe ? '90d' : '30d';

        const token = jwt.sign(
            {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role,
                isFirstUser: user.isFirstUser
            },
            process.env.JWT_SECRET,
            { expiresIn: tokenExpiry }
        );

        // Generate refresh token
        const refreshToken = jwt.sign(
            { id: user.id },
            process.env.JWT_SECRET + '_refresh',
            { expiresIn: '180d' }
        );

        // Update last login
        await User.updateLastLogin(user.id, req.ip);

        // Log successful login
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'login', 'Successful login', ?)`,
            [user.id, req.ip]
        );

        // Get user details
        const userDetails = await User.findById(user.id);

        // Return success response
        res.json({
            success: true,
            message: `Welcome back, ${user.username}!`,
            token,
            refreshToken,
            user: {
                id: userDetails.id,
                username: userDetails.username,
                email: userDetails.email,
                role: userDetails.role,
                isFirstUser: userDetails.isFirstUser,
                avatar: userDetails.avatar,
                credits: userDetails.credits,
                serverLimit: userDetails.serverLimit,
                serverCount: userDetails.serverCount,
                permissions: userDetails.permissions
            }
        });

    } catch (error) {
        console.error('Login error:', error.message);
        res.status(500).json({
            error: 'Login failed. Please try again later.'
        });
    }
});

// ============================================
// POST /api/auth/refresh
// Refresh access token using refresh token
// ============================================
router.post('/refresh', async (req, res) => {
    try {
        const { refreshToken } = req.body;

        if (!refreshToken) {
            return res.status(400).json({
                error: 'Refresh token is required'
            });
        }

        // Verify refresh token
        let decoded;
        try {
            decoded = jwt.verify(refreshToken, process.env.JWT_SECRET + '_refresh');
        } catch (err) {
            return res.status(401).json({
                error: 'Invalid or expired refresh token'
            });
        }

        // Check if user still exists
        const user = await User.findById(decoded.id);

        if (!user) {
            return res.status(401).json({
                error: 'User not found'
            });
        }

        if (user.status !== 'active') {
            return res.status(403).json({
                error: 'Account is not active'
            });
        }

        // Generate new access token
        const newToken = jwt.sign(
            {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role,
                isFirstUser: user.isFirstUser
            },
            process.env.JWT_SECRET,
            { expiresIn: '30d' }
        );

        res.json({
            success: true,
            token: newToken
        });

    } catch (error) {
        console.error('Refresh token error:', error.message);
        res.status(500).json({
            error: 'Token refresh failed'
        });
    }
});

// ============================================
// POST /api/auth/logout
// Logout user (client-side token removal + logging)
// ============================================
router.post('/logout', auth, async (req, res) => {
    try {
        // Log logout activity
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'logout', 'User logged out', ?)`,
            [req.user.id, req.ip]
        );

        res.json({
            success: true,
            message: 'Logged out successfully'
        });

    } catch (error) {
        console.error('Logout error:', error.message);
        res.json({
            success: true,
            message: 'Logged out'
        });
    }
});

// ============================================
// GET /api/auth/me
// Get current authenticated user details
// ============================================
router.get('/me', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id);

        if (!user) {
            return res.status(404).json({
                error: 'User not found'
            });
        }

        res.json({
            success: true,
            user
        });

    } catch (error) {
        console.error('Get user error:', error.message);
        res.status(500).json({
            error: 'Failed to fetch user data'
        });
    }
});

// ============================================
// PUT /api/auth/password
// Change password (requires current password)
// ============================================
router.put('/password', auth, async (req, res) => {
    try {
        const { currentPassword, newPassword, confirmPassword } = req.body;

        if (!currentPassword || !newPassword || !confirmPassword) {
            return res.status(400).json({
                error: 'Current password, new password, and confirmation are required'
            });
        }

        if (newPassword !== confirmPassword) {
            return res.status(400).json({
                error: 'New passwords do not match'
            });
        }

        if (newPassword.length < 8) {
            return res.status(400).json({
                error: 'New password must be at least 8 characters'
            });
        }

        await User.changePassword(req.user.id, currentPassword, newPassword);

        res.json({
            success: true,
            message: 'Password changed successfully'
        });

    } catch (error) {
        console.error('Change password error:', error.message);
        res.status(400).json({
            error: error.message || 'Failed to change password'
        });
    }
});

// ============================================
// GET /api/auth/check-first
// Check if first user is still available
// ============================================
router.get('/check-first', async (req, res) => {
    try {
        const isAvailable = await User.isFirstUserAvailable();

        res.json({
            success: true,
            isFirstUserAvailable: isAvailable,
            message: isAvailable
                ? 'Be the first to register and become ADMIN!'
                : 'Registration is open'
        });

    } catch (error) {
        console.error('Check first user error:', error.message);
        res.status(500).json({
            error: 'Failed to check registration status'
        });
    }
});

// ============================================
// PUT /api/auth/profile
// Update user profile (username, email, avatar)
// ============================================
router.put('/profile', auth, async (req, res) => {
    try {
        const { username, email, avatar } = req.body;
        const updates = {};

        if (username) updates.username = username;
        if (email) updates.email = email;
        if (avatar) updates.avatar = avatar;

        if (Object.keys(updates).length === 0) {
            return res.status(400).json({
                error: 'No fields to update'
            });
        }

        await User.update(req.user.id, updates);

        res.json({
            success: true,
            message: 'Profile updated successfully'
        });

    } catch (error) {
        console.error('Update profile error:', error.message);
        res.status(400).json({
            error: error.message || 'Failed to update profile'
        });
    }
});

module.exports = router;