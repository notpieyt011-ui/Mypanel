// ============================================
// Aqua Panel - Node Management Routes
// Location: /var/www/aqua-panel/server/routes/nodes.js
// ============================================

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const Node = require('../models/Node');

// Apply auth middleware to all routes
router.use(auth);

// ============================================
// GET /api/nodes
// Get all nodes (admin only)
// ============================================
router.get('/', admin, async (req, res) => {
    try {
        const filters = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 20,
            search: req.query.search || null,
            status: req.query.status || null,
            sortBy: req.query.sort_by || 'created_at',
            sortOrder: req.query.sort_order || 'DESC'
        };

        const result = await Node.findAll(filters);

        res.json({
            success: true,
            nodes: result.nodes,
            pagination: result.pagination
        });

    } catch (error) {
        console.error('Get nodes error:', error.message);
        res.status(500).json({ error: 'Failed to fetch nodes' });
    }
});

// ============================================
// GET /api/nodes/available
// Get nodes with available capacity
// ============================================
router.get('/available', admin, async (req, res) => {
    try {
        const memoryRequired = parseInt(req.query.memory) || 4096;
        const diskRequired = parseInt(req.query.disk) || 51200;

        const nodes = await Node.getAvailableForServer(memoryRequired, diskRequired);

        res.json({
            success: true,
            nodes
        });

    } catch (error) {
        console.error('Get available nodes error:', error.message);
        res.status(500).json({ error: 'Failed to fetch available nodes' });
    }
});

// ============================================
// GET /api/nodes/:id
// Get single node details
// ============================================
router.get('/:id', admin, async (req, res) => {
    try {
        const nodeId = req.params.id;
        const node = await Node.findById(nodeId);

        if (!node) {
            return res.status(404).json({ error: 'Node not found' });
        }

        res.json({
            success: true,
            node
        });

    } catch (error) {
        console.error('Get node error:', error.message);
        res.status(500).json({ error: 'Failed to fetch node details' });
    }
});

// ============================================
// POST /api/nodes
// Create a new node (admin only)
// ============================================
router.post('/', admin, async (req, res) => {
    try {
        const {
            name,
            description,
            fqdn,
            totalMemory,
            totalDisk,
            portRangeStart,
            portRangeEnd,
            daemonListen,
            daemonSftp,
            scheme
        } = req.body;

        // Validate required fields
        if (!name || !fqdn || !totalMemory || !totalDisk) {
            return res.status(400).json({
                error: 'Node name, FQDN, total memory, and total disk are required'
            });
        }

        // Create node
        const node = await Node.create({
            name,
            description: description || null,
            fqdn,
            totalMemory: parseInt(totalMemory),
            totalDisk: parseInt(totalDisk),
            portRangeStart: portRangeStart || null,
            portRangeEnd: portRangeEnd || null,
            daemonListen: daemonListen ? parseInt(daemonListen) : 8080,
            daemonSftp: daemonSftp ? parseInt(daemonSftp) : 2022,
            scheme: scheme || 'https',
            createdBy: req.user.id
        });

        res.status(201).json({
            success: true,
            message: 'Node created successfully',
            node
        });

    } catch (error) {
        console.error('Create node error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to create node' });
    }
});

// ============================================
// PUT /api/nodes/:id
// Update node details (admin only)
// ============================================
router.put('/:id', admin, async (req, res) => {
    try {
        const nodeId = req.params.id;

        // Check node exists
        const node = await Node.findById(nodeId);
        if (!node) {
            return res.status(404).json({ error: 'Node not found' });
        }

        const allowedFields = [
            'name', 'description', 'fqdn', 'scheme',
            'total_memory', 'total_disk',
            'daemon_listen', 'daemon_sftp', 'status'
        ];

        const updates = {};
        for (const field of allowedFields) {
            if (req.body[field] !== undefined) {
                updates[field] = req.body[field];
            }
        }

        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ error: 'No valid fields to update' });
        }

        await Node.update(nodeId, updates);

        // Get updated node
        const updatedNode = await Node.findById(nodeId);

        res.json({
            success: true,
            message: 'Node updated successfully',
            node: updatedNode
        });

    } catch (error) {
        console.error('Update node error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to update node' });
    }
});

// ============================================
// DELETE /api/nodes/:id
// Delete a node (admin only)
// ============================================
router.delete('/:id', admin, async (req, res) => {
    try {
        const nodeId = req.params.id;

        const node = await Node.findById(nodeId);
        if (!node) {
            return res.status(404).json({ error: 'Node not found' });
        }

        // Check if node has servers
        if (node.server_count > 0) {
            return res.status(400).json({
                error: `Cannot delete node with ${node.server_count} server(s). Remove all servers first.`
            });
        }

        await Node.delete(nodeId);

        // Log activity
        const { query } = require('../config/database');
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'node_delete', ?, ?)`,
            [req.user.id, `Deleted node: ${node.name}`, req.ip]
        );

        res.json({
            success: true,
            message: 'Node deleted successfully'
        });

    } catch (error) {
        console.error('Delete node error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to delete node' });
    }
});

// ============================================
// GET /api/nodes/:id/allocations
// Get node port allocations
// ============================================
router.get('/:id/allocations', admin, async (req, res) => {
    try {
        const nodeId = req.params.id;
        const filters = {
            status: req.query.status || null,
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 50
        };

        const node = await Node.findById(nodeId);
        if (!node) {
            return res.status(404).json({ error: 'Node not found' });
        }

        const result = await Node.getAllocations(nodeId, filters);

        res.json({
            success: true,
            node: { id: node.id, name: node.name, fqdn: node.fqdn },
            allocations: result.allocations,
            summary: result.summary,
            pagination: result.pagination
        });

    } catch (error) {
        console.error('Get allocations error:', error.message);
        res.status(500).json({ error: 'Failed to fetch allocations' });
    }
});

// ============================================
// POST /api/nodes/:id/allocations
// Create new allocations for a node
// ============================================
router.post('/:id/allocations', admin, async (req, res) => {
    try {
        const nodeId = req.params.id;
        const { ip_address, port_start, port_end } = req.body;

        if (!ip_address || !port_start) {
            return res.status(400).json({
                error: 'IP address and starting port are required'
            });
        }

        const node = await Node.findById(nodeId);
        if (!node) {
            return res.status(404).json({ error: 'Node not found' });
        }

        const startPort = parseInt(port_start);
        const endPort = port_end ? parseInt(port_end) : startPort;

        if (endPort < startPort) {
            return res.status(400).json({ error: 'End port must be greater than or equal to start port' });
        }

        if (endPort - startPort > 100) {
            return res.status(400).json({ error: 'Port range cannot exceed 100 ports' });
        }

        const createdAllocations = [];
        const { query } = require('../config/database');

        for (let port = startPort; port <= endPort; port++) {
            // Check if allocation already exists
            const existing = await query(
                'SELECT id FROM allocations WHERE node_id = ? AND ip_address = ? AND port = ?',
                [nodeId, ip_address, port]
            );

            if (existing.length === 0) {
                await query(
                    `INSERT INTO allocations (node_id, ip_address, port, type, status)
                     VALUES (?, ?, ?, 'primary', 'available')`,
                    [nodeId, ip_address, port]
                );
                createdAllocations.push({ ip_address, port });
            }
        }

        res.status(201).json({
            success: true,
            message: `${createdAllocations.length} allocation(s) created`,
            allocations: createdAllocations
        });

    } catch (error) {
        console.error('Create allocations error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to create allocations' });
    }
});

// ============================================
// DELETE /api/nodes/:nodeId/allocations/:allocId
// Delete a specific allocation
// ============================================
router.delete('/:nodeId/allocations/:allocId', admin, async (req, res) => {
    try {
        const { nodeId, allocId } = req.params;
        const { query } = require('../config/database');

        const allocations = await query(
            'SELECT * FROM allocations WHERE id = ? AND node_id = ?',
            [allocId, nodeId]
        );

        if (allocations.length === 0) {
            return res.status(404).json({ error: 'Allocation not found' });
        }

        const allocation = allocations[0];

        if (allocation.status === 'assigned') {
            return res.status(400).json({
                error: 'Cannot delete an assigned allocation. Unassign it first.'
            });
        }

        await query('DELETE FROM allocations WHERE id = ?', [allocId]);

        res.json({
            success: true,
            message: 'Allocation deleted successfully'
        });

    } catch (error) {
        console.error('Delete allocation error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to delete allocation' });
    }
});

// ============================================
// GET /api/nodes/:id/stats
// Get node statistics
// ============================================
router.get('/:id/stats', admin, async (req, res) => {
    try {
        const nodeId = req.params.id;
        const stats = await Node.getStats(nodeId);

        if (!stats) {
            return res.status(404).json({ error: 'Node not found' });
        }

        res.json({
            success: true,
            stats
        });

    } catch (error) {
        console.error('Get node stats error:', error.message);
        res.status(500).json({ error: 'Failed to fetch node statistics' });
    }
});

// ============================================
// POST /api/nodes/:id/regenerate-token
// Regenerate daemon token
// ============================================
router.post('/:id/regenerate-token', admin, async (req, res) => {
    try {
        const nodeId = req.params.id;

        const node = await Node.findById(nodeId);
        if (!node) {
            return res.status(404).json({ error: 'Node not found' });
        }

        const newToken = await Node.regenerateToken(nodeId);

        // Log activity
        const { query } = require('../config/database');
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'node_token_regenerate', ?, ?)`,
            [req.user.id, `Regenerated token for node: ${node.name}`, req.ip]
        );

        res.json({
            success: true,
            message: 'Daemon token regenerated successfully',
            token: newToken
        });

    } catch (error) {
        console.error('Regenerate token error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to regenerate token' });
    }
});

// ============================================
// POST /api/nodes/:id/status
// Update node status
// ============================================
router.post('/:id/status', admin, async (req, res) => {
    try {
        const nodeId = req.params.id;
        const { status } = req.body;

        const validStatuses = ['active', 'inactive', 'maintenance'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({
                error: `Invalid status. Must be one of: ${validStatuses.join(', ')}`
            });
        }

        const node = await Node.findById(nodeId);
        if (!node) {
            return res.status(404).json({ error: 'Node not found' });
        }

        await Node.updateStatus(nodeId, status);

        res.json({
            success: true,
            message: `Node status updated to ${status}`,
            status
        });

    } catch (error) {
        console.error('Update node status error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to update node status' });
    }
});

module.exports = router;