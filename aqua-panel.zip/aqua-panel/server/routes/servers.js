// ============================================
// Aqua Panel - Server Management Routes
// Location: /var/www/aqua-panel/server/routes/servers.js
// ============================================

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const Server = require('../models/Server');

// Apply auth middleware to all routes
router.use(auth);

// ============================================
// GET /api/servers
// Get all servers (admin sees all, user sees own)
// ============================================
router.get('/', async (req, res) => {
    try {
        const isAdmin = req.user.role === 'admin';
        
        const filters = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 20,
            search: req.query.search || null,
            status: req.query.status || null,
            nodeId: req.query.node_id || null,
            locationId: req.query.location_id || null,
            gameType: req.query.game_type || null,
            expiringSoon: req.query.expiring === 'true',
            sortBy: req.query.sort_by || 'created_at',
            sortOrder: req.query.sort_order || 'DESC'
        };

        // Non-admin users can only see their own servers
        if (!isAdmin) {
            filters.userId = req.user.id;
        } else if (req.query.user_id) {
            filters.userId = req.query.user_id;
        }

        const result = await Server.findAll(filters);

        res.json({
            success: true,
            servers: result.servers,
            pagination: result.pagination
        });

    } catch (error) {
        console.error('Get servers error:', error.message);
        res.status(500).json({ error: 'Failed to fetch servers' });
    }
});

// ============================================
// GET /api/servers/:id
// Get single server details
// ============================================
router.get('/:id', async (req, res) => {
    try {
        const serverId = req.params.id;
        const isAdmin = req.user.role === 'admin';

        const server = await Server.findById(serverId);

        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        // Check ownership (admin can view all)
        if (!isAdmin && server.user_id !== req.user.id) {
            return res.status(403).json({ error: 'Access denied' });
        }

        res.json({
            success: true,
            server
        });

    } catch (error) {
        console.error('Get server error:', error.message);
        res.status(500).json({ error: 'Failed to fetch server details' });
    }
});

// ============================================
// POST /api/servers
// Create a new server
// ============================================
router.post('/', async (req, res) => {
    try {
        const {
            name,
            nodeId,
            locationId,
            eggId,
            memory,
            cpu,
            disk,
            allocation,
            gameType,
            gameVersion,
            description,
            expiresInDays
        } = req.body;

        // Validate required fields
        if (!name || !nodeId || !locationId) {
            return res.status(400).json({
                error: 'Server name, node ID, and location ID are required'
            });
        }

        // Check user server limit
        const user = req.user;
        if (user.role !== 'admin') {
            const User = require('../models/User');
            const userDetails = await User.findById(user.id);
            
            if (userDetails && userDetails.serverCount >= userDetails.serverLimit) {
                return res.status(403).json({
                    error: `Server limit reached (${userDetails.serverLimit} max)`
                });
            }
        }

        // Create server
        const server = await Server.create({
            name,
            userId: req.user.id,
            nodeId: parseInt(nodeId),
            locationId: parseInt(locationId),
            eggId: eggId ? parseInt(eggId) : null,
            memory: memory ? parseInt(memory) : 4096,
            cpu: cpu ? parseInt(cpu) : 200,
            disk: disk ? parseInt(disk) : 51200,
            allocation: allocation || null,
            gameType: gameType || 'paper',
            gameVersion: gameVersion || '1.21.11',
            description: description || null,
            expiresInDays: expiresInDays ? parseInt(expiresInDays) : 30
        });

        res.status(201).json({
            success: true,
            message: 'Server created successfully! Installation started...',
            server
        });

    } catch (error) {
        console.error('Create server error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to create server' });
    }
});

// ============================================
// PUT /api/servers/:id
// Update server details
// ============================================
router.put('/:id', async (req, res) => {
    try {
        const serverId = req.params.id;
        const isAdmin = req.user.role === 'admin';

        // Check server exists
        const server = await Server.findById(serverId);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        // Check ownership
        if (!isAdmin && server.user_id !== req.user.id) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const allowedFields = [
            'name', 'description', 'memory', 'cpu', 'disk',
            'game_version', 'allocation', 'node_id', 'location_id', 'egg_id'
        ];

        const updates = {};
        for (const field of allowedFields) {
            if (req.body[field] !== undefined) {
                updates[field] = req.body[field];
            }
        }

        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ error: 'No valid fields to update' });
        }

        await Server.update(serverId, updates);

        // Get updated server
        const updatedServer = await Server.findById(serverId);

        res.json({
            success: true,
            message: 'Server updated successfully',
            server: updatedServer
        });

    } catch (error) {
        console.error('Update server error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to update server' });
    }
});

// ============================================
// DELETE /api/servers/:id
// Delete a server
// ============================================
router.delete('/:id', async (req, res) => {
    try {
        const serverId = req.params.id;
        const isAdmin = req.user.role === 'admin';

        const server = await Server.findById(serverId);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        // Check ownership
        if (!isAdmin && server.user_id !== req.user.id) {
            return res.status(403).json({ error: 'Access denied' });
        }

        // Check if server is running
        if (server.status === 'running') {
            return res.status(400).json({
                error: 'Please stop the server before deleting it'
            });
        }

        await Server.delete(serverId);

        // Log activity
        const { query } = require('../config/database');
        await query(
            `INSERT INTO activity_logs (user_id, server_id, action, description, ip_address)
             VALUES (?, ?, 'server_delete', ?, ?)`,
            [req.user.id, serverId, `Deleted server: ${server.name}`, req.ip]
        );

        res.json({
            success: true,
            message: 'Server deleted successfully'
        });

    } catch (error) {
        console.error('Delete server error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to delete server' });
    }
});

// ============================================
// POST /api/servers/:id/power
// Server power actions (start, stop, restart, kill)
// ============================================
router.post('/:id/power', async (req, res) => {
    try {
        const serverId = req.params.id;
        const { action } = req.body;
        const isAdmin = req.user.role === 'admin';

        // Validate action
        const validActions = ['start', 'stop', 'restart', 'kill'];
        if (!validActions.includes(action)) {
            return res.status(400).json({
                error: `Invalid action. Must be one of: ${validActions.join(', ')}`
            });
        }

        // Check server exists
        const server = await Server.findById(serverId);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        // Check ownership
        if (!isAdmin && server.user_id !== req.user.id) {
            return res.status(403).json({ error: 'Access denied' });
        }

        // Map action to status
        const statusMap = {
            start: 'starting',
            stop: 'stopping',
            restart: 'starting',
            kill: 'stopped'
        };

        const finalStatus = statusMap[action];

        // Validate current status for action
        if (action === 'start' && server.status === 'running') {
            return res.status(400).json({ error: 'Server is already running' });
        }

        if (action === 'stop' && server.status === 'stopped') {
            return res.status(400).json({ error: 'Server is already stopped' });
        }

        if (action === 'start' && server.status === 'installing') {
            return res.status(400).json({ error: 'Cannot start server while installing' });
        }

        // Update status
        await Server.updateStatus(serverId, finalStatus);

        // Log activity
        const { query } = require('../config/database');
        await query(
            `INSERT INTO activity_logs (user_id, server_id, action, description, ip_address)
             VALUES (?, ?, ?, ?, ?)`,
            [req.user.id, serverId, `server_${action}`, `${action} server: ${server.name}`, req.ip]
        );

        res.json({
            success: true,
            message: `Server ${action} command sent successfully`,
            status: finalStatus
        });

    } catch (error) {
        console.error('Power action error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to execute power action' });
    }
});

// ============================================
// POST /api/servers/:id/extend
// Extend server expiry date
// ============================================
router.post('/:id/extend', async (req, res) => {
    try {
        const serverId = req.params.id;
        const { days } = req.body;
        const isAdmin = req.user.role === 'admin';

        if (!days || days < 1 || days > 365) {
            return res.status(400).json({
                error: 'Days must be between 1 and 365'
            });
        }

        const server = await Server.findById(serverId);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        if (!isAdmin && server.user_id !== req.user.id) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const result = await Server.extendExpiry(serverId, parseInt(days));

        res.json({
            success: true,
            message: `Server extended by ${days} days`,
            newExpiry: result.newExpiry,
            daysAdded: result.daysAdded
        });

    } catch (error) {
        console.error('Extend server error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to extend server' });
    }
});

// ============================================
// GET /api/servers/:id/stats
// Get server resource statistics
// ============================================
router.get('/:id/stats', async (req, res) => {
    try {
        const serverId = req.params.id;
        const isAdmin = req.user.role === 'admin';

        const server = await Server.findById(serverId);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        if (!isAdmin && server.user_id !== req.user.id) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const stats = await Server.getStats(serverId);
        const resources = await Server.getResourceUsage(serverId);

        res.json({
            success: true,
            stats,
            resources
        });

    } catch (error) {
        console.error('Get server stats error:', error.message);
        res.status(500).json({ error: 'Failed to fetch server statistics' });
    }
});

// ============================================
// POST /api/servers/bulk
// Bulk operations on servers (admin only)
// ============================================
router.post('/bulk', admin, async (req, res) => {
    try {
        const { server_ids, action } = req.body;

        if (!server_ids || !Array.isArray(server_ids) || server_ids.length === 0) {
            return res.status(400).json({ error: 'Server IDs array is required' });
        }

        const validActions = ['delete', 'stop', 'start', 'restart'];
        if (!validActions.includes(action)) {
            return res.status(400).json({
                error: `Invalid action. Must be one of: ${validActions.join(', ')}`
            });
        }

        let affectedCount = 0;

        switch (action) {
            case 'delete':
                affectedCount = await Server.bulkDelete(server_ids);
                break;
            case 'stop':
                affectedCount = await Server.bulkUpdateStatus(server_ids, 'stopped');
                break;
            case 'start':
                for (const id of server_ids) {
                    try {
                        await Server.updateStatus(id, 'starting');
                        affectedCount++;
                    } catch (err) {
                        console.error(`Failed to start server ${id}:`, err.message);
                    }
                }
                break;
            case 'restart':
                for (const id of server_ids) {
                    try {
                        await Server.updateStatus(id, 'starting');
                        affectedCount++;
                    } catch (err) {
                        console.error(`Failed to restart server ${id}:`, err.message);
                    }
                }
                break;
        }

        res.json({
            success: true,
            message: `Bulk ${action} completed`,
            affected: affectedCount
        });

    } catch (error) {
        console.error('Bulk operation error:', error.message);
        res.status(400).json({ error: error.message || 'Bulk operation failed' });
    }
});

module.exports = router;