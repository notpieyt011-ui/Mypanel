// ============================================
// Aqua Panel - Admin Management Routes
// Location: /var/www/aqua-panel/server/routes/admin.js
// ============================================

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const { query, transaction } = require('../config/database');
const User = require('../models/User');
const Server = require('../models/Server');
const Node = require('../models/Node');
const Location = require('../models/Location');
const os = require('os');

// Apply auth and admin middleware to all routes
router.use(auth);
router.use(admin);

// ============================================
// GET /api/admin/dashboard
// Get admin dashboard statistics
// ============================================
router.get('/dashboard', async (req, res) => {
    try {
        // Get counts
        const [
            userCount,
            serverCount,
            nodeCount,
            locationCount,
            apiKeyCount,
            backupCount
        ] = await Promise.all([
            query('SELECT COUNT(*) as count FROM users'),
            query('SELECT COUNT(*) as count FROM servers'),
            query('SELECT COUNT(*) as count FROM nodes'),
            query('SELECT COUNT(*) as count FROM locations'),
            query("SELECT COUNT(*) as count FROM api_keys WHERE status = 'active'"),
            query('SELECT COUNT(*) as count FROM backups')
        ]);

        // Get server status distribution
        const serverStatus = await query(
            `SELECT status, COUNT(*) as count 
             FROM servers GROUP BY status`
        );

        // Get resource usage across all nodes
        const resourceUsage = await query(
            `SELECT 
                SUM(total_memory) as total_memory,
                SUM(allocated_memory) as used_memory,
                SUM(total_disk) as total_disk,
                SUM(allocated_disk) as used_disk
             FROM nodes WHERE status = 'active'`
        );

        // Get recent activity
        const recentActivity = await query(
            `SELECT al.*, u.username 
             FROM activity_logs al
             LEFT JOIN users u ON al.user_id = u.id
             ORDER BY al.created_at DESC 
             LIMIT 10`
        );

        // Get expiring servers (7 days)
        const expiringServers = await query(
            `SELECT COUNT(*) as count 
             FROM servers 
             WHERE expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)`
        );

        // Get new users this month
        const newUsersThisMonth = await query(
            `SELECT COUNT(*) as count 
             FROM users 
             WHERE created_at >= DATE_FORMAT(NOW(), '%Y-%m-01')`
        );

        // Get new servers this month
        const newServersThisMonth = await query(
            `SELECT COUNT(*) as count 
             FROM servers 
             WHERE created_at >= DATE_FORMAT(NOW(), '%Y-%m-01')`
        );

        res.json({
            success: true,
            stats: {
                users: userCount[0].count,
                servers: serverCount[0].count,
                nodes: nodeCount[0].count,
                locations: locationCount[0].count,
                apiKeys: apiKeyCount[0].count,
                backups: backupCount[0].count,
                serverStatus,
                resourceUsage: {
                    memory: {
                        total: resourceUsage[0].total_memory || 0,
                        used: resourceUsage[0].used_memory || 0,
                        percent: resourceUsage[0].total_memory > 0 
                            ? Math.round((resourceUsage[0].used_memory / resourceUsage[0].total_memory) * 100)
                            : 0
                    },
                    disk: {
                        total: resourceUsage[0].total_disk || 0,
                        used: resourceUsage[0].used_disk || 0,
                        percent: resourceUsage[0].total_disk > 0 
                            ? Math.round((resourceUsage[0].used_disk / resourceUsage[0].total_disk) * 100)
                            : 0
                    }
                },
                expiringServers: expiringServers[0].count,
                newUsersThisMonth: newUsersThisMonth[0].count,
                newServersThisMonth: newServersThisMonth[0].count,
                recentActivity
            }
        });

    } catch (error) {
        console.error('Dashboard error:', error.message);
        res.status(500).json({ error: 'Failed to load dashboard statistics' });
    }
});

// ============================================
// USER MANAGEMENT
// ============================================

// GET /api/admin/users - Get all users
router.get('/users', async (req, res) => {
    try {
        const filters = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 20,
            search: req.query.search || null,
            role: req.query.role || null,
            status: req.query.status || null,
            sortBy: req.query.sort_by || 'created_at',
            sortOrder: req.query.sort_order || 'DESC'
        };

        const result = await User.findAll(filters);

        res.json({
            success: true,
            users: result.users,
            pagination: result.pagination
        });

    } catch (error) {
        console.error('Get users error:', error.message);
        res.status(500).json({ error: 'Failed to fetch users' });
    }
});

// GET /api/admin/users/:id - Get single user
router.get('/users/:id', async (req, res) => {
    try {
        const userId = req.params.id;
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({
            success: true,
            user
        });

    } catch (error) {
        console.error('Get user error:', error.message);
        res.status(500).json({ error: 'Failed to fetch user details' });
    }
});

// PUT /api/admin/users/:id - Update user
router.put('/users/:id', async (req, res) => {
    try {
        const userId = req.params.id;
        
        // Prevent self-role-change
        if (userId == req.user.id && req.body.role && req.body.role !== req.user.role) {
            return res.status(400).json({ error: 'Cannot change your own role' });
        }

        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        const allowedFields = [
            'username', 'email', 'role', 'status',
            'server_limit', 'credits', 'avatar'
        ];

        const updates = {};
        for (const field of allowedFields) {
            if (req.body[field] !== undefined) {
                updates[field] = req.body[field];
            }
        }

        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ error: 'No valid fields to update' });
        }

        await User.update(userId, updates);

        const updatedUser = await User.findById(userId);

        res.json({
            success: true,
            message: 'User updated successfully',
            user: updatedUser
        });

    } catch (error) {
        console.error('Update user error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to update user' });
    }
});

// DELETE /api/admin/users/:id - Delete user
router.delete('/users/:id', async (req, res) => {
    try {
        const userId = req.params.id;

        // Prevent self-delete
        if (userId == req.user.id) {
            return res.status(400).json({ error: 'Cannot delete yourself' });
        }

        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Prevent deleting first admin unless super admin
        if (user.isFirstUser && !req.admin.isSuperAdmin) {
            return res.status(403).json({ error: 'Cannot delete the primary administrator' });
        }

        await User.delete(userId);

        res.json({
            success: true,
            message: 'User deleted successfully'
        });

    } catch (error) {
        console.error('Delete user error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to delete user' });
    }
});

// POST /api/admin/users/:id/suspend - Suspend user
router.post('/users/:id/suspend', async (req, res) => {
    try {
        const userId = req.params.id;

        if (userId == req.user.id) {
            return res.status(400).json({ error: 'Cannot suspend yourself' });
        }

        await User.suspend(userId);

        res.json({
            success: true,
            message: 'User suspended successfully'
        });

    } catch (error) {
        console.error('Suspend user error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to suspend user' });
    }
});

// POST /api/admin/users/:id/unsuspend - Unsuspend user
router.post('/users/:id/unsuspend', async (req, res) => {
    try {
        const userId = req.params.id;
        await User.unsuspend(userId);

        res.json({
            success: true,
            message: 'User unsuspended successfully'
        });

    } catch (error) {
        console.error('Unsuspend user error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to unsuspend user' });
    }
});

// ============================================
// SETTINGS MANAGEMENT
// ============================================

// GET /api/admin/settings - Get all settings
router.get('/settings', async (req, res) => {
    try {
        const settings = await query(
            'SELECT * FROM settings ORDER BY setting_key'
        );

        res.json({
            success: true,
            settings
        });

    } catch (error) {
        console.error('Get settings error:', error.message);
        res.status(500).json({ error: 'Failed to fetch settings' });
    }
});

// PUT /api/admin/settings - Update settings
router.put('/settings', async (req, res) => {
    try {
        const { settings } = req.body;

        if (!settings || !Array.isArray(settings)) {
            return res.status(400).json({ error: 'Settings array is required' });
        }

        for (const setting of settings) {
            if (!setting.key || setting.value === undefined) continue;

            await query(
                `INSERT INTO settings (setting_key, setting_value)
                 VALUES (?, ?)
                 ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)`,
                [setting.key, setting.value]
            );
        }

        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'settings_update', 'Updated panel settings', ?)`,
            [req.user.id, req.ip]
        );

        res.json({
            success: true,
            message: 'Settings updated successfully'
        });

    } catch (error) {
        console.error('Update settings error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to update settings' });
    }
});

// ============================================
// ACTIVITY LOGS
// ============================================

// GET /api/admin/activity - Get activity logs
router.get('/activity', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 50;
        const offset = (page - 1) * limit;
        const action = req.query.action || null;
        const userId = req.query.user_id || null;

        let sql = `
            SELECT al.*, u.username 
            FROM activity_logs al
            LEFT JOIN users u ON al.user_id = u.id
        `;

        const conditions = [];
        const params = [];

        if (action) {
            conditions.push('al.action = ?');
            params.push(action);
        }

        if (userId) {
            conditions.push('al.user_id = ?');
            params.push(userId);
        }

        if (conditions.length > 0) {
            sql += ' WHERE ' + conditions.join(' AND ');
        }

        sql += ' ORDER BY al.created_at DESC LIMIT ? OFFSET ?';
        params.push(limit, offset);

        const [logs, countResult] = await Promise.all([
            query(sql, params),
            query('SELECT COUNT(*) as total FROM activity_logs')
        ]);

        res.json({
            success: true,
            logs,
            pagination: {
                page,
                limit,
                total: countResult[0].total,
                pages: Math.ceil(countResult[0].total / limit)
            }
        });

    } catch (error) {
        console.error('Get activity error:', error.message);
        res.status(500).json({ error: 'Failed to fetch activity logs' });
    }
});

// ============================================
// SYSTEM INFORMATION
// ============================================

// GET /api/admin/system - Get system information
router.get('/system', async (req, res) => {
    try {
        const systemInfo = {
            platform: os.platform(),
            arch: os.arch(),
            cpus: os.cpus().length,
            totalMemory: Math.round(os.totalmem() / (1024 * 1024)),
            freeMemory: Math.round(os.freemem() / (1024 * 1024)),
            uptime: Math.floor(os.uptime()),
            nodeVersion: process.version,
            panelVersion: '1.0.0',
            hostname: os.hostname(),
            loadAverage: os.loadavg()
        };

        res.json({
            success: true,
            system: systemInfo
        });

    } catch (error) {
        console.error('Get system info error:', error.message);
        res.status(500).json({ error: 'Failed to get system information' });
    }
});

// ============================================
// BULK OPERATIONS
// ============================================

// POST /api/admin/bulk/servers - Bulk server operations
router.post('/bulk/servers', async (req, res) => {
    try {
        const { server_ids, action } = req.body;

        if (!server_ids || !Array.isArray(server_ids) || server_ids.length === 0) {
            return res.status(400).json({ error: 'Server IDs array is required' });
        }

        const validActions = ['delete', 'suspend', 'unsuspend', 'stop'];
        if (!validActions.includes(action)) {
            return res.status(400).json({
                error: `Invalid action. Must be one of: ${validActions.join(', ')}`
            });
        }

        let affectedCount = 0;

        switch (action) {
            case 'delete':
                affectedCount = await Server.bulkDelete(server_ids);
                break;
            case 'suspend':
                await query(
                    "UPDATE servers SET status = 'suspended' WHERE id IN (?)",
                    [server_ids]
                );
                affectedCount = server_ids.length;
                break;
            case 'unsuspend':
                await query(
                    "UPDATE servers SET status = 'stopped' WHERE id IN (?) AND status = 'suspended'",
                    [server_ids]
                );
                affectedCount = server_ids.length;
                break;
            case 'stop':
                affectedCount = await Server.bulkUpdateStatus(server_ids, 'stopped');
                break;
        }

        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, ?, ?, ?)`,
            [req.user.id, `bulk_${action}`, `Bulk ${action} on ${affectedCount} servers`, req.ip]
        );

        res.json({
            success: true,
            message: `${action} operation completed`,
            affected: affectedCount
        });

    } catch (error) {
        console.error('Bulk operation error:', error.message);
        res.status(400).json({ error: error.message || 'Bulk operation failed' });
    }
});

module.exports = router;