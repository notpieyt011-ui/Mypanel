// ============================================
// Aqua Panel - API Key Management Routes
// Location: /var/www/aqua-panel/server/routes/api.js
// ============================================

const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const { query } = require('../config/database');

// Apply auth middleware to all routes
router.use(auth);

// ============================================
// POST /api/keys/generate
// Generate a new API key
// ============================================
router.post('/generate', async (req, res) => {
    try {
        const userId = req.user.id;
        const { description, permissions, allowed_ips, expires_in_days } = req.body;

        // Validate description
        if (!description || description.length < 3 || description.length > 255) {
            return res.status(400).json({
                error: 'Description must be between 3 and 255 characters'
            });
        }

        // Check key limit per user (max 10 active keys)
        const keyCount = await query(
            "SELECT COUNT(*) as count FROM api_keys WHERE user_id = ? AND status = 'active'",
            [userId]
        );

        if (keyCount[0].count >= 10) {
            return res.status(400).json({
                error: 'Maximum 10 active API keys allowed. Revoke unused keys first.'
            });
        }

        // Generate unique API key
        const keyPrefix = 'aqp_';
        const randomBytes = crypto.randomBytes(32).toString('hex');
        const apiKey = keyPrefix + randomBytes;

        // Hash the key for storage
        const hashedKey = crypto.createHash('sha256').update(apiKey).digest('hex');

        // Set default permissions if not provided
        const defaultPermissions = [
            'servers.read',
            'servers.write',
            'nodes.read',
            'locations.read'
        ];

        const keyPermissions = permissions || defaultPermissions;

        // Calculate expiry date
        let expiresAt = null;
        if (expires_in_days) {
            const days = parseInt(expires_in_days);
            if (days < 1 || days > 3650) {
                return res.status(400).json({
                    error: 'Expiry days must be between 1 and 3650'
                });
            }
            expiresAt = new Date();
            expiresAt.setDate(expiresAt.getDate() + days);
        }

        // Create API key
        await query(
            `INSERT INTO api_keys (
                user_id, key_value, description, permissions, 
                allowed_ips, expires_at, status
            ) VALUES (?, ?, ?, ?, ?, ?, 'active')`,
            [
                userId,
                hashedKey,
                description,
                JSON.stringify(keyPermissions),
                allowed_ips || null,
                expiresAt
            ]
        );

        // Log activity
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'api_key_create', ?, ?)`,
            [userId, `Created API key: ${description}`, req.ip]
        );

        // Return the key (only shown once!)
        res.status(201).json({
            success: true,
            message: 'API key generated successfully. Save it now - it will not be shown again!',
            api_key: apiKey,
            prefix: keyPrefix,
            description: description,
            permissions: keyPermissions,
            expires_at: expiresAt,
            warning: 'Store this key securely. You will not be able to see it again!'
        });

    } catch (error) {
        console.error('Generate API key error:', error.message);
        res.status(500).json({ error: 'Failed to generate API key' });
    }
});

// ============================================
// GET /api/keys
// List user's API keys
// ============================================
router.get('/', async (req, res) => {
    try {
        const userId = req.user.id;
        const isAdmin = req.user.role === 'admin';

        let sql = `
            SELECT 
                ak.id,
                ak.description,
                ak.permissions,
                ak.allowed_ips,
                ak.last_used,
                ak.expires_at,
                ak.status,
                ak.created_at,
                CONCAT('aqp_', REPEAT('*', 32)) as masked_key,
                u.username as owner_username
            FROM api_keys ak
            LEFT JOIN users u ON ak.user_id = u.id
        `;

        const params = [];

        // Admin sees all, users see only their own
        if (!isAdmin) {
            sql += ' WHERE ak.user_id = ?';
            params.push(userId);
        }

        // Filter by status
        if (req.query.status) {
            const whereClause = params.length > 0 ? ' AND' : ' WHERE';
            sql += `${whereClause} ak.status = ?`;
            params.push(req.query.status);
        }

        sql += ' ORDER BY ak.created_at DESC';

        const keys = await query(sql, params);

        // Parse permissions JSON
        const parsedKeys = keys.map(key => ({
            ...key,
            permissions: key.permissions ? JSON.parse(key.permissions) : []
        }));

        res.json({
            success: true,
            keys: parsedKeys,
            total: parsedKeys.length
        });

    } catch (error) {
        console.error('List API keys error:', error.message);
        res.status(500).json({ error: 'Failed to fetch API keys' });
    }
});

// ============================================
// GET /api/keys/:id
// Get single API key details
// ============================================
router.get('/:id', async (req, res) => {
    try {
        const keyId = req.params.id;
        const userId = req.user.id;
        const isAdmin = req.user.role === 'admin';

        const keys = await query(
            `SELECT ak.*, u.username as owner_username, u.email as owner_email
             FROM api_keys ak
             LEFT JOIN users u ON ak.user_id = u.id
             WHERE ak.id = ?`,
            [keyId]
        );

        if (keys.length === 0) {
            return res.status(404).json({ error: 'API key not found' });
        }

        const key = keys[0];

        // Check ownership (admin can view all)
        if (!isAdmin && key.user_id !== userId) {
            return res.status(403).json({ error: 'Access denied' });
        }

        // Get usage history (last 30 days)
        const usageHistory = await query(
            `SELECT action, description, created_at 
             FROM activity_logs 
             WHERE user_id = ? 
             AND action LIKE 'api_%'
             AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
             ORDER BY created_at DESC 
             LIMIT 100`,
            [key.user_id]
        );

        res.json({
            success: true,
            key: {
                id: key.id,
                description: key.description,
                permissions: key.permissions ? JSON.parse(key.permissions) : [],
                allowed_ips: key.allowed_ips,
                last_used: key.last_used,
                expires_at: key.expires_at,
                status: key.status,
                created_at: key.created_at,
                masked_key: 'aqp_' + '*'.repeat(32),
                owner: {
                    username: key.owner_username,
                    email: key.owner_email
                },
                usage_history: usageHistory
            }
        });

    } catch (error) {
        console.error('Get API key error:', error.message);
        res.status(500).json({ error: 'Failed to fetch API key details' });
    }
});

// ============================================
// PUT /api/keys/:id
// Update API key
// ============================================
router.put('/:id', async (req, res) => {
    try {
        const keyId = req.params.id;
        const userId = req.user.id;
        const isAdmin = req.user.role === 'admin';

        // Check key exists
        const keys = await query('SELECT * FROM api_keys WHERE id = ?', [keyId]);

        if (keys.length === 0) {
            return res.status(404).json({ error: 'API key not found' });
        }

        const key = keys[0];

        // Check ownership
        if (!isAdmin && key.user_id !== userId) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const { description, permissions, allowed_ips, status } = req.body;
        const updates = [];
        const params = [];

        if (description) {
            if (description.length < 3 || description.length > 255) {
                return res.status(400).json({
                    error: 'Description must be between 3 and 255 characters'
                });
            }
            updates.push('description = ?');
            params.push(description);
        }

        if (permissions) {
            if (!Array.isArray(permissions) || permissions.length === 0) {
                return res.status(400).json({
                    error: 'At least one permission is required'
                });
            }
            updates.push('permissions = ?');
            params.push(JSON.stringify(permissions));
        }

        if (allowed_ips !== undefined) {
            updates.push('allowed_ips = ?');
            params.push(allowed_ips);
        }

        if (status) {
            const validStatuses = ['active', 'revoked'];
            if (!validStatuses.includes(status)) {
                return res.status(400).json({ error: 'Invalid status' });
            }
            updates.push('status = ?');
            params.push(status);
        }

        if (updates.length === 0) {
            return res.status(400).json({ error: 'No fields to update' });
        }

        params.push(keyId);

        await query(
            `UPDATE api_keys SET ${updates.join(', ')} WHERE id = ?`,
            params
        );

        // Log activity
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'api_key_update', ?, ?)`,
            [userId, `Updated API key: ${key.description}`, req.ip]
        );

        res.json({
            success: true,
            message: 'API key updated successfully'
        });

    } catch (error) {
        console.error('Update API key error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to update API key' });
    }
});

// ============================================
// POST /api/keys/:id/revoke
// Revoke an API key
// ============================================
router.post('/:id/revoke', async (req, res) => {
    try {
        const keyId = req.params.id;
        const userId = req.user.id;
        const isAdmin = req.user.role === 'admin';

        const keys = await query('SELECT * FROM api_keys WHERE id = ?', [keyId]);

        if (keys.length === 0) {
            return res.status(404).json({ error: 'API key not found' });
        }

        const key = keys[0];

        // Check ownership
        if (!isAdmin && key.user_id !== userId) {
            return res.status(403).json({ error: 'Access denied' });
        }

        if (key.status === 'revoked') {
            return res.status(400).json({ error: 'API key is already revoked' });
        }

        await query(
            "UPDATE api_keys SET status = 'revoked' WHERE id = ?",
            [keyId]
        );

        // Log activity
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'api_key_revoke', ?, ?)`,
            [userId, `Revoked API key: ${key.description}`, req.ip]
        );

        res.json({
            success: true,
            message: 'API key revoked successfully'
        });

    } catch (error) {
        console.error('Revoke API key error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to revoke API key' });
    }
});

// ============================================
// DELETE /api/keys/:id
// Permanently delete an API key
// ============================================
router.delete('/:id', async (req, res) => {
    try {
        const keyId = req.params.id;
        const userId = req.user.id;
        const isAdmin = req.user.role === 'admin';

        const keys = await query('SELECT * FROM api_keys WHERE id = ?', [keyId]);

        if (keys.length === 0) {
            return res.status(404).json({ error: 'API key not found' });
        }

        const key = keys[0];

        // Check ownership
        if (!isAdmin && key.user_id !== userId) {
            return res.status(403).json({ error: 'Access denied' });
        }

        await query('DELETE FROM api_keys WHERE id = ?', [keyId]);

        // Log activity
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'api_key_delete', ?, ?)`,
            [userId, `Deleted API key: ${key.description}`, req.ip]
        );

        res.json({
            success: true,
            message: 'API key deleted permanently'
        });

    } catch (error) {
        console.error('Delete API key error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to delete API key' });
    }
});

// ============================================
// POST /api/keys/validate
// Validate an API key (public endpoint)
// ============================================
router.post('/validate', async (req, res) => {
    try {
        const { api_key } = req.body;

        if (!api_key) {
            return res.status(400).json({ error: 'API key is required' });
        }

        // Hash the provided key
        const hashedKey = crypto.createHash('sha256').update(api_key).digest('hex');

        // Find the key
        const keys = await query(
            `SELECT ak.*, u.username, u.role, u.status as user_status
             FROM api_keys ak
             LEFT JOIN users u ON ak.user_id = u.id
             WHERE ak.key_value = ? AND ak.status = 'active'`,
            [hashedKey]
        );

        if (keys.length === 0) {
            return res.status(401).json({ error: 'Invalid or revoked API key' });
        }

        const key = keys[0];

        // Check if user is active
        if (key.user_status !== 'active') {
            return res.status(403).json({ error: 'User account is not active' });
        }

        // Check expiry
        if (key.expires_at && new Date(key.expires_at) < new Date()) {
            await query(
                "UPDATE api_keys SET status = 'revoked' WHERE id = ?",
                [key.id]
            );
            return res.status(401).json({ error: 'API key has expired' });
        }

        // Check IP restriction
        if (key.allowed_ips) {
            const allowedIPs = key.allowed_ips.split(',').map(ip => ip.trim());
            const clientIP = req.ip.replace('::ffff:', '');

            if (!allowedIPs.includes(clientIP) && !allowedIPs.includes('*')) {
                return res.status(403).json({
                    error: 'IP address not allowed for this API key'
                });
            }
        }

        // Update last used
        await query(
            'UPDATE api_keys SET last_used = NOW() WHERE id = ?',
            [key.id]
        );

        // Log API usage
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'api_request', ?, ?)`,
            [key.user_id, `API request from key: ${key.description}`, req.ip]
        );

        res.json({
            success: true,
            valid: true,
            user: {
                id: key.user_id,
                username: key.username,
                role: key.role
            },
            permissions: key.permissions ? JSON.parse(key.permissions) : [],
            key_description: key.description
        });

    } catch (error) {
        console.error('Validate API key error:', error.message);
        res.status(500).json({ error: 'Failed to validate API key' });
    }
});

// ============================================
// GET /api/keys/admin/all - Admin: List all keys
// ============================================
router.get('/admin/all', admin, async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 50;
        const offset = (page - 1) * limit;
        const status = req.query.status || null;
        const search = req.query.search || null;

        let sql = `
            SELECT 
                ak.id, ak.description, ak.permissions, ak.last_used,
                ak.expires_at, ak.status, ak.created_at,
                CONCAT('aqp_', REPEAT('*', 32)) as masked_key,
                u.username as owner_username, u.email as owner_email,
                (SELECT COUNT(*) FROM activity_logs WHERE user_id = ak.user_id AND action LIKE 'api_%') as usage_count
            FROM api_keys ak
            LEFT JOIN users u ON ak.user_id = u.id
        `;

        const conditions = [];
        const params = [];

        if (status) {
            conditions.push('ak.status = ?');
            params.push(status);
        }

        if (search) {
            conditions.push('(ak.description LIKE ? OR u.username LIKE ?)');
            params.push(`%${search}%`, `%${search}%`);
        }

        if (conditions.length > 0) {
            sql += ' WHERE ' + conditions.join(' AND ');
        }

        sql += ' ORDER BY ak.created_at DESC LIMIT ? OFFSET ?';
        params.push(limit, offset);

        const [keys, countResult] = await Promise.all([
            query(sql, params),
            query('SELECT COUNT(*) as total FROM api_keys')
        ]);

        res.json({
            success: true,
            keys: keys.map(key => ({
                ...key,
                permissions: key.permissions ? JSON.parse(key.permissions) : []
            })),
            pagination: {
                page,
                limit,
                total: countResult[0].total,
                pages: Math.ceil(countResult[0].total / limit)
            }
        });

    } catch (error) {
        console.error('Admin list keys error:', error.message);
        res.status(500).json({ error: 'Failed to fetch all API keys' });
    }
});

// ============================================
// POST /api/keys/admin/bulk-revoke - Admin: Bulk revoke
// ============================================
router.post('/admin/bulk-revoke', admin, async (req, res) => {
    try {
        const { key_ids } = req.body;

        if (!key_ids || !Array.isArray(key_ids) || key_ids.length === 0) {
            return res.status(400).json({ error: 'Key IDs array is required' });
        }

        await query(
            "UPDATE api_keys SET status = 'revoked' WHERE id IN (?)",
            [key_ids]
        );

        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'api_key_bulk_revoke', ?, ?)`,
            [req.user.id, `Bulk revoked ${key_ids.length} API keys`, req.ip]
        );

        res.json({
            success: true,
            message: `${key_ids.length} API key(s) revoked`,
            affected: key_ids.length
        });

    } catch (error) {
        console.error('Bulk revoke error:', error.message);
        res.status(400).json({ error: error.message || 'Bulk revoke failed' });
    }
});

module.exports = router;