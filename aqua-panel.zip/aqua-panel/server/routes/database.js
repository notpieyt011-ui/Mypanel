// ============================================
// Aqua Panel - Database Management Routes
// Location: /var/www/aqua-panel/server/routes/database.js
// ============================================

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const { query, getDatabaseStats } = require('../config/database');

// Apply auth and admin middleware to all routes
router.use(auth);
router.use(admin);

// ============================================
// GET /api/database/stats
// Get database statistics
// ============================================
router.get('/stats', async (req, res) => {
    try {
        const stats = await getDatabaseStats();

        res.json({
            success: true,
            database: {
                name: process.env.DB_NAME || 'aqua_panel',
                ...stats.size,
                uptime: stats.connections.uptime || 0
            },
            tables: stats.tables,
            connections: {
                current: stats.connections.threads_connected || 0,
                running: stats.connections.threads_running || 0,
                maxUsed: stats.connections.max_used_connections || 0,
                total: stats.connections.connections || 0,
                aborted: stats.connections.aborted_connects || 0
            }
        });

    } catch (error) {
        console.error('Database stats error:', error.message);
        res.status(500).json({ error: 'Failed to fetch database statistics' });
    }
});

// ============================================
// GET /api/database/tables
// Get all tables with structure
// ============================================
router.get('/tables', async (req, res) => {
    try {
        const dbName = process.env.DB_NAME || 'aqua_panel';

        const tables = await query(
            `SELECT 
                TABLE_NAME as name,
                TABLE_ROWS as rows,
                ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024, 2) as size_kb,
                TABLE_TYPE as engine,
                TABLE_COLLATION as collation,
                CREATE_TIME as created,
                UPDATE_TIME as last_updated
             FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = ?
             ORDER BY TABLE_NAME`,
            [dbName]
        );

        // Get columns for each table
        const tablesWithColumns = await Promise.all(
            tables.map(async (table) => {
                const columns = await query(
                    `SELECT 
                        COLUMN_NAME as name,
                        COLUMN_TYPE as type,
                        IS_NULLABLE as nullable,
                        COLUMN_KEY as key_type,
                        COLUMN_DEFAULT as default_value,
                        EXTRA as extra
                     FROM information_schema.COLUMNS
                     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
                     ORDER BY ORDINAL_POSITION`,
                    [dbName, table.name]
                );
                return { ...table, columns };
            })
        );

        res.json({
            success: true,
            tables: tablesWithColumns
        });

    } catch (error) {
        console.error('Get tables error:', error.message);
        res.status(500).json({ error: 'Failed to fetch tables' });
    }
});

// ============================================
// GET /api/database/tables/:name
// Get table data with pagination
// ============================================
router.get('/tables/:name', async (req, res) => {
    try {
        const tableName = req.params.name;
        const dbName = process.env.DB_NAME || 'aqua_panel';

        // Validate table name (prevent SQL injection)
        if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(tableName)) {
            return res.status(400).json({ error: 'Invalid table name' });
        }

        // Check if table exists
        const tableExists = await query(
            `SELECT TABLE_NAME 
             FROM information_schema.TABLES 
             WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?`,
            [dbName, tableName]
        );

        if (tableExists.length === 0) {
            return res.status(404).json({ error: 'Table not found' });
        }

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 50;
        const offset = (page - 1) * limit;
        const search = req.query.search || null;
        const orderBy = req.query.order_by || null;
        const orderDir = req.query.order_dir === 'ASC' ? 'ASC' : 'DESC';

        // Get table columns
        const columns = await query(
            `SELECT COLUMN_NAME as name, COLUMN_TYPE as type
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
             ORDER BY ORDINAL_POSITION`,
            [dbName, tableName]
        );

        // Build data query
        let dataQuery = `SELECT * FROM \`${tableName}\``;
        let countQuery = `SELECT COUNT(*) as total FROM \`${tableName}\``;
        const params = [];

        // Add search
        if (search && columns.length > 0) {
            const searchableColumns = columns.filter(col =>
                col.type.includes('char') || col.type.includes('text') || col.type.includes('varchar')
            );

            if (searchableColumns.length > 0) {
                const searchConditions = searchableColumns
                    .map(col => `\`${col.name}\` LIKE ?`)
                    .join(' OR ');

                dataQuery += ` WHERE ${searchConditions}`;
                countQuery += ` WHERE ${searchConditions}`;

                for (let i = 0; i < searchableColumns.length; i++) {
                    params.push(`%${search}%`);
                }
            }
        }

        // Add ordering
        if (orderBy && columns.find(c => c.name === orderBy)) {
            dataQuery += ` ORDER BY \`${orderBy}\` ${orderDir}`;
        }

        // Add pagination
        dataQuery += ' LIMIT ? OFFSET ?';
        const dataParams = [...params, limit, offset];

        const [data, total] = await Promise.all([
            query(dataQuery, dataParams),
            query(countQuery, params)
        ]);

        res.json({
            success: true,
            table: tableName,
            columns,
            data,
            pagination: {
                page,
                limit,
                total: total[0].total,
                pages: Math.ceil(total[0].total / limit)
            }
        });

    } catch (error) {
        console.error('Get table data error:', error.message);
        res.status(500).json({ error: 'Failed to fetch table data' });
    }
});

// ============================================
// POST /api/database/tables/:name/optimize
// Optimize a table
// ============================================
router.post('/tables/:name/optimize', async (req, res) => {
    try {
        const tableName = req.params.name;

        if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(tableName)) {
            return res.status(400).json({ error: 'Invalid table name' });
        }

        await query(`OPTIMIZE TABLE \`${tableName}\``);

        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'db_optimize', ?, ?)`,
            [req.user.id, `Optimized table: ${tableName}`, req.ip]
        );

        res.json({
            success: true,
            message: `Table '${tableName}' optimized successfully`
        });

    } catch (error) {
        console.error('Optimize table error:', error.message);
        res.status(500).json({ error: 'Failed to optimize table' });
    }
});

// ============================================
// POST /api/database/tables/:name/repair
// Repair a table
// ============================================
router.post('/tables/:name/repair', async (req, res) => {
    try {
        const tableName = req.params.name;

        if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(tableName)) {
            return res.status(400).json({ error: 'Invalid table name' });
        }

        await query(`REPAIR TABLE \`${tableName}\``);

        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'db_repair', ?, ?)`,
            [req.user.id, `Repaired table: ${tableName}`, req.ip]
        );

        res.json({
            success: true,
            message: `Table '${tableName}' repaired successfully`
        });

    } catch (error) {
        console.error('Repair table error:', error.message);
        res.status(500).json({ error: 'Failed to repair table' });
    }
});

// ============================================
// POST /api/database/tables/:name/truncate
// Truncate a table (non-critical tables only)
// ============================================
router.post('/tables/:name/truncate', async (req, res) => {
    try {
        const tableName = req.params.name;

        if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(tableName)) {
            return res.status(400).json({ error: 'Invalid table name' });
        }

        // Prevent truncating critical tables
        const criticalTables = ['users', 'servers', 'nodes', 'settings', 'api_keys'];
        if (criticalTables.includes(tableName)) {
            return res.status(403).json({
                error: `Cannot truncate critical table: ${tableName}`
            });
        }

        await query(`TRUNCATE TABLE \`${tableName}\``);

        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'db_truncate', ?, ?)`,
            [req.user.id, `Truncated table: ${tableName}`, req.ip]
        );

        res.json({
            success: true,
            message: `Table '${tableName}' truncated successfully`
        });

    } catch (error) {
        console.error('Truncate table error:', error.message);
        res.status(500).json({ error: 'Failed to truncate table' });
    }
});

// ============================================
// POST /api/database/query
// Run a custom SELECT/SHOW/DESCRIBE query
// ============================================
router.post('/query', async (req, res) => {
    try {
        const { sql } = req.body;

        if (!sql || sql.trim().length === 0) {
            return res.status(400).json({ error: 'SQL query is required' });
        }

        // Only allow SELECT, SHOW, DESCRIBE, EXPLAIN queries
        const trimmedSQL = sql.trim().toUpperCase();
        const allowedCommands = ['SELECT', 'SHOW', 'DESCRIBE', 'EXPLAIN'];

        const startsWithAllowed = allowedCommands.some(cmd =>
            trimmedSQL.startsWith(cmd)
        );

        if (!startsWithAllowed) {
            return res.status(403).json({
                error: 'Only SELECT, SHOW, DESCRIBE, and EXPLAIN queries are allowed'
            });
        }

        // Prevent multiple queries
        const statements = sql.split(';').filter(s => s.trim().length > 0);
        if (statements.length > 1) {
            return res.status(403).json({
                error: 'Multiple queries are not allowed for security reasons'
            });
        }

        // Execute query
        const startTime = Date.now();
        const results = await query(sql);
        const executionTime = Date.now() - startTime;

        // Log query execution
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address, metadata)
             VALUES (?, 'db_query', ?, ?, ?)`,
            [
                req.user.id,
                `Executed query (${executionTime}ms)`,
                req.ip,
                JSON.stringify({ sql: sql.substring(0, 200), executionTime })
            ]
        );

        res.json({
            success: true,
            results,
            rowCount: Array.isArray(results) ? results.length : 0,
            executionTime: executionTime + 'ms'
        });

    } catch (error) {
        console.error('Query execution error:', error.message);

        // Log failed query
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address, metadata)
             VALUES (?, 'db_query_failed', ?, ?, ?)`,
            [
                req.user.id,
                `Failed query: ${error.message}`,
                req.ip,
                JSON.stringify({ sql: req.body.sql?.substring(0, 200) || '' })
            ]
        ).catch(() => {});

        res.status(400).json({
            error: 'Query execution failed',
            message: error.message
        });
    }
});

// ============================================
// POST /api/database/backup
// Create a database backup
// ============================================
router.post('/backup', async (req, res) => {
    try {
        const dbName = process.env.DB_NAME || 'aqua_panel';
        const { tables } = req.body;

        // Get all tables or specified tables
        let tableList = [];
        if (tables && Array.isArray(tables) && tables.length > 0) {
            // Validate table names
            for (const table of tables) {
                if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
                    return res.status(400).json({
                        error: `Invalid table name: ${table}`
                    });
                }
            }
            tableList = tables;
        } else {
            const allTables = await query('SHOW TABLES');
            tableList = allTables.map(t => Object.values(t)[0]);
        }

        // Generate backup SQL
        let backupSQL = `-- Aqua Panel Database Backup\n`;
        backupSQL += `-- Database: ${dbName}\n`;
        backupSQL += `-- Date: ${new Date().toISOString()}\n`;
        backupSQL += `-- Generated by: ${req.user.username}\n\n`;
        backupSQL += `SET FOREIGN_KEY_CHECKS=0;\n\n`;

        for (const tableName of tableList) {
            // Get create table statement
            const createTable = await query(`SHOW CREATE TABLE \`${tableName}\``);
            backupSQL += `\n-- Table: ${tableName}\n`;
            backupSQL += `DROP TABLE IF EXISTS \`${tableName}\`;\n`;
            backupSQL += `${createTable[0]['Create Table']};\n\n`;

            // Get table data
            const rows = await query(`SELECT * FROM \`${tableName}\``);
            if (rows.length > 0) {
                const columns = Object.keys(rows[0]);
                const values = rows.map(row => {
                    const vals = columns.map(col => {
                        const val = row[col];
                        if (val === null) return 'NULL';
                        if (typeof val === 'number') return val;
                        if (val instanceof Date) return `'${val.toISOString()}'`;
                        return `'${String(val).replace(/'/g, "\\'").replace(/\n/g, '\\n')}'`;
                    });
                    return `INSERT INTO \`${tableName}\` (\`${columns.join('`, `')}\`) VALUES (${vals.join(', ')});`;
                });
                backupSQL += values.join('\n') + '\n\n';
            }
        }

        backupSQL += `SET FOREIGN_KEY_CHECKS=1;\n`;

        // Save backup file
        const backupDir = path.join(__dirname, '..', 'backups');
        if (!fs.existsSync(backupDir)) {
            fs.mkdirSync(backupDir, { recursive: true });
        }

        const timestamp = new Date().toISOString().replace(/:/g, '-').replace(/\..+/, '');
        const filename = `backup_${dbName}_${timestamp}.sql`;
        const filepath = path.join(backupDir, filename);
        fs.writeFileSync(filepath, backupSQL, 'utf8');

        const fileStats = fs.statSync(filepath);

        // Log activity
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address, metadata)
             VALUES (?, 'db_backup', ?, ?, ?)`,
            [
                req.user.id,
                `Database backup created: ${filename}`,
                req.ip,
                JSON.stringify({ filename, size: fileStats.size, tables: tableList.length })
            ]
        );

        res.json({
            success: true,
            message: 'Database backup created successfully',
            filename,
            size: fileStats.size,
            sizeFormatted: formatBytes(fileStats.size),
            tables: tableList.length
        });

    } catch (error) {
        console.error('Backup error:', error.message);
        res.status(500).json({ error: 'Failed to create database backup' });
    }
});

// ============================================
// GET /api/database/backups
// List database backups
// ============================================
router.get('/backups', async (req, res) => {
    try {
        const backupDir = path.join(__dirname, '..', 'backups');

        if (!fs.existsSync(backupDir)) {
            return res.json({ success: true, backups: [] });
        }

        const files = fs.readdirSync(backupDir)
            .filter(f => f.endsWith('.sql') || f.endsWith('.gz'))
            .map(f => {
                const stats = fs.statSync(path.join(backupDir, f));
                return {
                    filename: f,
                    size: stats.size,
                    sizeFormatted: formatBytes(stats.size),
                    created: stats.birthtime,
                    modified: stats.mtime
                };
            })
            .sort((a, b) => new Date(b.modified) - new Date(a.modified));

        res.json({
            success: true,
            backups: files
        });

    } catch (error) {
        console.error('List backups error:', error.message);
        res.status(500).json({ error: 'Failed to list backups' });
    }
});

// ============================================
// GET /api/database/backups/:filename
// Download a backup file
// ============================================
router.get('/backups/:filename', async (req, res) => {
    try {
        const filename = req.params.filename;

        // Validate filename
        if (!/^[a-zA-Z0-9_\-\.]+$/.test(filename)) {
            return res.status(400).json({ error: 'Invalid filename' });
        }

        const backupDir = path.join(__dirname, '..', 'backups');
        const filepath = path.join(backupDir, filename);

        if (!fs.existsSync(filepath)) {
            return res.status(404).json({ error: 'Backup file not found' });
        }

        res.download(filepath, filename);

    } catch (error) {
        console.error('Download backup error:', error.message);
        res.status(500).json({ error: 'Failed to download backup' });
    }
});

// ============================================
// DELETE /api/database/backups/:filename
// Delete a backup file
// ============================================
router.delete('/backups/:filename', async (req, res) => {
    try {
        const filename = req.params.filename;

        if (!/^[a-zA-Z0-9_\-\.]+$/.test(filename)) {
            return res.status(400).json({ error: 'Invalid filename' });
        }

        const backupDir = path.join(__dirname, '..', 'backups');
        const filepath = path.join(backupDir, filename);

        if (!fs.existsSync(filepath)) {
            return res.status(404).json({ error: 'Backup file not found' });
        }

        fs.unlinkSync(filepath);

        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'db_backup_delete', ?, ?)`,
            [req.user.id, `Deleted backup: ${filename}`, req.ip]
        );

        res.json({
            success: true,
            message: 'Backup deleted successfully'
        });

    } catch (error) {
        console.error('Delete backup error:', error.message);
        res.status(500).json({ error: 'Failed to delete backup' });
    }
});

// ============================================
// Helper: Format bytes to human readable
// ============================================
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

module.exports = router;