// ============================================
// Aqua Panel - Location Management Routes
// Location: /var/www/aqua-panel/server/routes/locations.js
// ============================================

const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const Location = require('../models/Location');

// Apply auth middleware to all routes
router.use(auth);

// ============================================
// GET /api/locations
// Get all locations
// ============================================
router.get('/', async (req, res) => {
    try {
        const filters = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 50,
            search: req.query.search || null,
            status: req.query.status || null,
            countryCode: req.query.country_code || null,
            sortBy: req.query.sort_by || 'name',
            sortOrder: req.query.sort_order || 'ASC'
        };

        const result = await Location.findAll(filters);

        res.json({
            success: true,
            locations: result.locations,
            pagination: result.pagination
        });

    } catch (error) {
        console.error('Get locations error:', error.message);
        res.status(500).json({ error: 'Failed to fetch locations' });
    }
});

// ============================================
// GET /api/locations/countries
// Get list of supported countries
// ============================================
router.get('/countries', async (req, res) => {
    try {
        const countries = Location.getSupportedCountries();

        res.json({
            success: true,
            countries
        });

    } catch (error) {
        console.error('Get countries error:', error.message);
        res.status(500).json({ error: 'Failed to fetch countries' });
    }
});

// ============================================
// GET /api/locations/continents/:continent
// Get locations by continent
// ============================================
router.get('/continents/:continent', async (req, res) => {
    try {
        const { continent } = req.params;
        const locations = await Location.getByContinent(continent);

        res.json({
            success: true,
            continent,
            locations
        });

    } catch (error) {
        console.error('Get locations by continent error:', error.message);
        res.status(500).json({ error: 'Failed to fetch locations by continent' });
    }
});

// ============================================
// GET /api/locations/popular
// Get popular locations
// ============================================
router.get('/popular', async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 5;
        const locations = await Location.getPopular(limit);

        res.json({
            success: true,
            locations
        });

    } catch (error) {
        console.error('Get popular locations error:', error.message);
        res.status(500).json({ error: 'Failed to fetch popular locations' });
    }
});

// ============================================
// GET /api/locations/:id
// Get single location details
// ============================================
router.get('/:id', async (req, res) => {
    try {
        const locationId = req.params.id;
        const location = await Location.findById(locationId);

        if (!location) {
            return res.status(404).json({ error: 'Location not found' });
        }

        res.json({
            success: true,
            location
        });

    } catch (error) {
        console.error('Get location error:', error.message);
        res.status(500).json({ error: 'Failed to fetch location details' });
    }
});

// ============================================
// POST /api/locations
// Create a new location (admin only)
// ============================================
router.post('/', admin, async (req, res) => {
    try {
        const {
            name,
            shortCode,
            description,
            flag,
            countryCode,
            city,
            timezone
        } = req.body;

        // Validate required fields
        if (!name || !shortCode) {
            return res.status(400).json({
                error: 'Location name and short code are required'
            });
        }

        // Create location
        const location = await Location.create({
            name,
            shortCode,
            description: description || null,
            flag: flag || null,
            countryCode: countryCode || null,
            city: city || null,
            timezone: timezone || 'UTC',
            createdBy: req.user.id
        });

        res.status(201).json({
            success: true,
            message: 'Location created successfully',
            location
        });

    } catch (error) {
        console.error('Create location error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to create location' });
    }
});

// ============================================
// PUT /api/locations/:id
// Update location details (admin only)
// ============================================
router.put('/:id', admin, async (req, res) => {
    try {
        const locationId = req.params.id;

        // Check location exists
        const location = await Location.findById(locationId);
        if (!location) {
            return res.status(404).json({ error: 'Location not found' });
        }

        const allowedFields = [
            'name', 'short_code', 'description', 'flag',
            'country_code', 'city', 'timezone', 'status'
        ];

        const updates = {};
        for (const field of allowedFields) {
            if (req.body[field] !== undefined) {
                updates[field] = req.body[field];
            }
        }

        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ error: 'No valid fields to update' });
        }

        await Location.update(locationId, updates);

        // Get updated location
        const updatedLocation = await Location.findById(locationId);

        res.json({
            success: true,
            message: 'Location updated successfully',
            location: updatedLocation
        });

    } catch (error) {
        console.error('Update location error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to update location' });
    }
});

// ============================================
// DELETE /api/locations/:id
// Delete a location (admin only)
// ============================================
router.delete('/:id', admin, async (req, res) => {
    try {
        const locationId = req.params.id;

        const location = await Location.findById(locationId);
        if (!location) {
            return res.status(404).json({ error: 'Location not found' });
        }

        // Check if location has servers
        if (location.server_count > 0) {
            return res.status(400).json({
                error: `Cannot delete location with ${location.server_count} server(s). Reassign or delete servers first.`
            });
        }

        await Location.delete(locationId);

        // Log activity
        const { query } = require('../config/database');
        await query(
            `INSERT INTO activity_logs (user_id, action, description, ip_address)
             VALUES (?, 'location_delete', ?, ?)`,
            [req.user.id, `Deleted location: ${location.name}`, req.ip]
        );

        res.json({
            success: true,
            message: 'Location deleted successfully'
        });

    } catch (error) {
        console.error('Delete location error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to delete location' });
    }
});

// ============================================
// GET /api/locations/:id/stats
// Get location statistics
// ============================================
router.get('/:id/stats', async (req, res) => {
    try {
        const locationId = req.params.id;
        const stats = await Location.getStats(locationId);

        if (!stats) {
            return res.status(404).json({ error: 'Location not found' });
        }

        res.json({
            success: true,
            stats
        });

    } catch (error) {
        console.error('Get location stats error:', error.message);
        res.status(500).json({ error: 'Failed to fetch location statistics' });
    }
});

// ============================================
// GET /api/locations/:id/servers
// Get servers in a specific location
// ============================================
router.get('/:id/servers', async (req, res) => {
    try {
        const locationId = req.params.id;
        const { query } = require('../config/database');

        // Check location exists
        const location = await Location.findById(locationId);
        if (!location) {
            return res.status(404).json({ error: 'Location not found' });
        }

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20;
        const offset = (page - 1) * limit;

        const servers = await query(
            `SELECT s.id, s.name, s.status, s.memory, s.cpu, s.disk,
                    s.game_type, s.game_version, s.created_at,
                    u.username as owner_name
             FROM servers s
             LEFT JOIN users u ON s.user_id = u.id
             WHERE s.location_id = ?
             ORDER BY s.created_at DESC
             LIMIT ? OFFSET ?`,
            [locationId, limit, offset]
        );

        const countResult = await query(
            'SELECT COUNT(*) as total FROM servers WHERE location_id = ?',
            [locationId]
        );

        res.json({
            success: true,
            location: { id: location.id, name: location.name, flag: location.flag },
            servers,
            pagination: {
                page,
                limit,
                total: countResult[0].total,
                pages: Math.ceil(countResult[0].total / limit)
            }
        });

    } catch (error) {
        console.error('Get location servers error:', error.message);
        res.status(500).json({ error: 'Failed to fetch location servers' });
    }
});

// ============================================
// POST /api/locations/defaults
// Create default locations (admin only)
// ============================================
router.post('/defaults', admin, async (req, res) => {
    try {
        const created = await Location.createDefaults(req.user.id);

        res.status(201).json({
            success: true,
            message: `${created.length} default location(s) created`,
            locations: created
        });

    } catch (error) {
        console.error('Create defaults error:', error.message);
        res.status(400).json({ error: error.message || 'Failed to create default locations' });
    }
});

module.exports = router;