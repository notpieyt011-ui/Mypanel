// ============================================
// Aqua Panel - Database Configuration
// Location: /var/www/aqua-panel/server/config/database.js
// ============================================

const mysql = require('mysql2/promise');
require('dotenv').config();

// ============================================
// Create Connection Pool
// ============================================
const pool = mysql.createPool({
    // Database host
    host: process.env.DB_HOST || 'localhost',
    
    // Database port
    port: parseInt(process.env.DB_PORT) || 3306,
    
    // Database username
    user: process.env.DB_USER || 'aquapanel',
    
    // Database password
    password: process.env.DB_PASSWORD || 'AquaPanel@123',
    
    // Database name
    database: process.env.DB_NAME || 'aqua_panel',
    
    // Wait for connections when pool is full
    waitForConnections: true,
    
    // Maximum number of connections in pool
    connectionLimit: 10,
    
    // Maximum number of queued connection requests (0 = unlimited)
    queueLimit: 0,
    
    // Keep connections alive
    enableKeepAlive: true,
    keepAliveInitialDelay: 0,
    
    // Connection timeout (milliseconds)
    connectTimeout: 10000,
    
    // Acquire timeout (milliseconds)
    acquireTimeout: 10000,
    
    // Idle connection timeout (milliseconds)
    idleTimeout: 60000,
    
    // Character set
    charset: 'utf8mb4',
    
    // Collation
    charsetNumber: 224, // utf8mb4_unicode_ci
    
    // Timezone
    timezone: '+00:00',
    
    // Support big numbers as strings
    supportBigNumbers: true,
    bigNumberStrings: true,
    
    // Return dates as strings
    dateStrings: true,
    
    // Debug mode
    debug: false,
    
    // Trace all queries
    trace: false,
    
    // Multiple statements
    multipleStatements: false,
    
    // Type casting
    typeCast: true,
    
    // Named placeholders
    namedPlaceholders: false,
    
    // Connection flags
    flags: []
});

// ============================================
// Test Database Connection
// ============================================
const testConnection = async () => {
    let connection;
    try {
        connection = await pool.getConnection();
        console.log('Database connected successfully');
        console.log('Host:', pool.pool.config.connectionConfig.host);
        console.log('Database:', pool.pool.config.connectionConfig.database);
        
        // Run a test query
        const [rows] = await connection.query('SELECT 1 as test');
        console.log('Query test:', rows[0].test === 1 ? 'PASSED' : 'FAILED');
        
        // Check MySQL version
        const [version] = await connection.query('SELECT VERSION() as version');
        console.log('MySQL Version:', version[0].version);
        
        connection.release();
        return true;
    } catch (error) {
        console.error('Database connection failed:', error.message);
        console.error('Please check your database configuration in .env file');
        
        if (connection) {
            connection.release();
        }
        return false;
    }
};

// ============================================
// Execute Query Helper
// ============================================
const query = async (sql, params = []) => {
    const start = Date.now();
    try {
        const [rows, fields] = await pool.execute(sql, params);
        const duration = Date.now() - start;
        
        // Log slow queries (more than 1000ms)
        if (duration > 1000) {
            console.warn(`SLOW QUERY (${duration}ms):`, sql.substring(0, 200));
        }
        
        // Log in development
        if (process.env.NODE_ENV === 'development') {
            console.log(`Query (${duration}ms):`, sql.substring(0, 100));
        }
        
        return rows;
    } catch (error) {
        console.error('Query error:', error.message);
        console.error('SQL:', sql.substring(0, 200));
        console.error('Params:', JSON.stringify(params).substring(0, 200));
        throw error;
    }
};

// ============================================
// Transaction Helper
// ============================================
const transaction = async (callback) => {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const result = await callback(connection);
        await connection.commit();
        return result;
    } catch (error) {
        await connection.rollback();
        console.error('Transaction failed, rolled back:', error.message);
        throw error;
    } finally {
        connection.release();
    }
};

// ============================================
// Get Pool Status
// ============================================
const getPoolStatus = () => {
    return {
        totalConnections: pool.pool._allConnections.length,
        freeConnections: pool.pool._freeConnections.length,
        queueLength: pool.pool._connectionQueue.length,
        pendingRequests: pool.pool._acquiringConnections.length
    };
};

// ============================================
// Get Database Statistics
// ============================================
const getDatabaseStats = async () => {
    try {
        const dbName = process.env.DB_NAME || 'aqua_panel';
        
        // Get database size
        const [sizeResult] = await pool.execute(`
            SELECT 
                ROUND(SUM(DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) as total_size_mb,
                ROUND(SUM(DATA_LENGTH) / 1024 / 1024, 2) as data_size_mb,
                ROUND(SUM(INDEX_LENGTH) / 1024 / 1024, 2) as index_size_mb
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = ?
        `, [dbName]);
        
        // Get table list with sizes
        const [tables] = await pool.execute(`
            SELECT 
                TABLE_NAME as name,
                TABLE_ROWS as rows,
                ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) as size_mb,
                TABLE_TYPE as engine,
                CREATE_TIME as created_at,
                UPDATE_TIME as updated_at
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = ?
            ORDER BY (DATA_LENGTH + INDEX_LENGTH) DESC
        `, [dbName]);
        
        // Get connection stats
        const [connections] = await pool.execute(`
            SHOW STATUS WHERE Variable_name IN (
                'Threads_connected',
                'Threads_running',
                'Max_used_connections',
                'Connections',
                'Aborted_connects',
                'Uptime'
            )
        `);
        
        return {
            size: sizeResult[0],
            tables,
            connections: connections.reduce((acc, row) => {
                acc[row.Variable_name.toLowerCase()] = row.Value;
                return acc;
            }, {})
        };
    } catch (error) {
        console.error('Get database stats error:', error);
        throw error;
    }
};

// ============================================
// Initialize Database Tables
// ============================================
const initializeTables = async () => {
    const tables = [
        // Users table
        `CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL,
            email VARCHAR(100) NOT NULL,
            password VARCHAR(255) NOT NULL,
            role ENUM('admin', 'user') DEFAULT 'user',
            is_first_user BOOLEAN DEFAULT FALSE,
            avatar VARCHAR(255) DEFAULT NULL,
            credits DECIMAL(10,2) DEFAULT 0.00,
            server_limit INT DEFAULT 5,
            status ENUM('active', 'suspended', 'banned') DEFAULT 'active',
            last_login TIMESTAMP NULL DEFAULT NULL,
            last_ip VARCHAR(45) DEFAULT NULL,
            last_active TIMESTAMP NULL DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_username (username),
            UNIQUE KEY unique_email (email),
            INDEX idx_role (role),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

        // Servers table
        `CREATE TABLE IF NOT EXISTS servers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            uuid VARCHAR(36) NOT NULL,
            name VARCHAR(100) NOT NULL,
            description TEXT DEFAULT NULL,
            user_id INT NOT NULL,
            node_id INT DEFAULT NULL,
            location_id INT DEFAULT NULL,
            egg_id INT DEFAULT NULL,
            memory INT DEFAULT 4096 COMMENT 'RAM in MB',
            cpu INT DEFAULT 200 COMMENT 'CPU percentage',
            disk INT DEFAULT 51200 COMMENT 'Disk in MB',
            allocation VARCHAR(100) DEFAULT NULL,
            game_type VARCHAR(50) DEFAULT 'paper',
            game_version VARCHAR(20) DEFAULT '1.21.11',
            status ENUM('installing', 'running', 'stopped', 'starting', 'stopping', 'error', 'suspended') DEFAULT 'installing',
            startup_command TEXT DEFAULT NULL,
            docker_image VARCHAR(255) DEFAULT NULL,
            expires_at DATE DEFAULT NULL,
            last_started TIMESTAMP NULL DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_uuid (uuid),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_id (user_id),
            INDEX idx_node_id (node_id),
            INDEX idx_status (status),
            INDEX idx_expires_at (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

        // Nodes table
        `CREATE TABLE IF NOT EXISTS nodes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            uuid VARCHAR(36) NOT NULL,
            name VARCHAR(100) NOT NULL,
            description TEXT DEFAULT NULL,
            fqdn VARCHAR(255) NOT NULL,
            scheme VARCHAR(10) DEFAULT 'https',
            total_memory INT NOT NULL,
            total_disk INT NOT NULL,
            allocated_memory INT DEFAULT 0,
            allocated_disk INT DEFAULT 0,
            port_range_start VARCHAR(50) DEFAULT NULL,
            port_range_end VARCHAR(50) DEFAULT NULL,
            daemon_listen INT DEFAULT 8080,
            daemon_sftp INT DEFAULT 2022,
            daemon_token VARCHAR(255) DEFAULT NULL,
            status ENUM('active', 'inactive', 'maintenance') DEFAULT 'active',
            last_ping TIMESTAMP NULL DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_uuid (uuid),
            UNIQUE KEY unique_fqdn (fqdn)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

        // Locations table
        `CREATE TABLE IF NOT EXISTS locations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            short_code VARCHAR(10) NOT NULL,
            description TEXT DEFAULT NULL,
            flag VARCHAR(10) DEFAULT NULL,
            country_code VARCHAR(5) DEFAULT NULL,
            city VARCHAR(100) DEFAULT NULL,
            timezone VARCHAR(50) DEFAULT 'UTC',
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY unique_short_code (short_code)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

        // API Keys table
        `CREATE TABLE IF NOT EXISTS api_keys (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            key_value VARCHAR(64) NOT NULL,
            description VARCHAR(255) DEFAULT NULL,
            permissions TEXT DEFAULT NULL,
            allowed_ips TEXT DEFAULT NULL,
            last_used TIMESTAMP NULL DEFAULT NULL,
            expires_at TIMESTAMP NULL DEFAULT NULL,
            status ENUM('active', 'revoked') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY unique_key (key_value),
            INDEX idx_user_id (user_id),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

        // Settings table
        `CREATE TABLE IF NOT EXISTS settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) NOT NULL,
            setting_value TEXT DEFAULT NULL,
            setting_type ENUM('string', 'boolean', 'integer', 'json', 'color', 'file') DEFAULT 'string',
            description VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_key (setting_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

        // Backups table
        `CREATE TABLE IF NOT EXISTS backups (
            id INT AUTO_INCREMENT PRIMARY KEY,
            uuid VARCHAR(36) NOT NULL,
            server_id INT NOT NULL,
            name VARCHAR(255) NOT NULL,
            file_name VARCHAR(255) DEFAULT NULL,
            size BIGINT DEFAULT 0,
            path VARCHAR(500) DEFAULT NULL,
            type ENUM('full', 'partial', 'incremental') DEFAULT 'full',
            status ENUM('pending', 'running', 'completed', 'failed') DEFAULT 'pending',
            completed_at TIMESTAMP NULL DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
            UNIQUE KEY unique_uuid (uuid)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

        // Activity Logs table
        `CREATE TABLE IF NOT EXISTS activity_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT DEFAULT NULL,
            server_id INT DEFAULT NULL,
            action VARCHAR(100) NOT NULL,
            description TEXT DEFAULT NULL,
            ip_address VARCHAR(45) DEFAULT NULL,
            user_agent TEXT DEFAULT NULL,
            metadata JSON DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_id (user_id),
            INDEX idx_action (action),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

        // Allocations table
        `CREATE TABLE IF NOT EXISTS allocations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            node_id INT NOT NULL,
            server_id INT DEFAULT NULL,
            ip_address VARCHAR(45) NOT NULL,
            port INT NOT NULL,
            type ENUM('primary', 'additional') DEFAULT 'primary',
            status ENUM('available', 'assigned') DEFAULT 'available',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (node_id) REFERENCES nodes(id) ON DELETE CASCADE,
            FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE SET NULL,
            UNIQUE KEY unique_ip_port (ip_address, port)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

        // Eggs table
        `CREATE TABLE IF NOT EXISTS eggs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            type VARCHAR(50) NOT NULL,
            version VARCHAR(50) DEFAULT NULL,
            description TEXT DEFAULT NULL,
            docker_image VARCHAR(255) DEFAULT NULL,
            default_memory INT DEFAULT 4096,
            default_cpu INT DEFAULT 200,
            default_disk INT DEFAULT 51200,
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY unique_egg (name, type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`
    ];

    try {
        for (const tableSQL of tables) {
            await pool.execute(tableSQL);
        }
        console.log('All database tables initialized successfully');
    } catch (error) {
        console.error('Error initializing tables:', error.message);
        throw error;
    }
};

// ============================================
// Insert Default Data
// ============================================
const insertDefaultData = async () => {
    try {
        // Default Eggs
        const eggs = [
            ['Paper', 'minecraft', '1.21.11', 'High performance Spigot fork with optimizations', 4096, 200, 51200],
            ['Spigot', 'minecraft', '1.21.11', 'Popular Minecraft server with plugin support', 4096, 200, 51200],
            ['Forge', 'minecraft', '1.21.4', 'Minecraft server with mod support', 6144, 300, 102400],
            ['Bedrock', 'minecraft', '1.26.0', 'Minecraft Bedrock Edition server', 2048, 100, 25600],
            ['BungeeCord', 'proxy', 'latest', 'Minecraft proxy server', 1024, 50, 10240],
            ['Velocity', 'proxy', 'latest', 'Modern Minecraft proxy server', 1024, 50, 10240]
        ];

        for (const egg of eggs) {
            await pool.execute(
                `INSERT IGNORE INTO eggs (name, type, version, description, default_memory, default_cpu, default_disk) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)`,
                egg
            );
        }

        // Default Locations
        const locations = [
            ['New York, USA', 'us-east', 'East Coast US data center', 'US', 'US', 'New York', 'America/New_York'],
            ['London, UK', 'uk-london', 'European data center', 'GB', 'GB', 'London', 'Europe/London'],
            ['Frankfurt, Germany', 'de-frankfurt', 'Central European data center', 'DE', 'DE', 'Frankfurt', 'Europe/Berlin'],
            ['Singapore', 'sg-singapore', 'Asian data center', 'SG', 'SG', 'Singapore', 'Asia/Singapore'],
            ['Mumbai, India', 'in-mumbai', 'South Asian data center', 'IN', 'IN', 'Mumbai', 'Asia/Kolkata'],
            ['Tokyo, Japan', 'jp-tokyo', 'East Asian data center', 'JP', 'JP', 'Tokyo', 'Asia/Tokyo'],
            ['Sydney, Australia', 'au-sydney', 'Oceanic data center', 'AU', 'AU', 'Sydney', 'Australia/Sydney']
        ];

        for (const loc of locations) {
            await pool.execute(
                `INSERT IGNORE INTO locations (name, short_code, description, flag, country_code, city, timezone) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)`,
                loc
            );
        }

        // Default Settings
        const settings = [
            ['panel_name', 'Aqua Panel', 'string', 'Panel display name'],
            ['panel_theme', 'purple', 'color', 'Default theme color'],
            ['panel_font', 'Inter', 'string', 'Default font family'],
            ['glow_intensity', '50', 'integer', 'Glow effect intensity'],
            ['glow_preset', 'purple', 'string', 'Default glow preset'],
            ['background_type', 'particles', 'string', 'Background animation type'],
            ['registration_enabled', 'true', 'boolean', 'Allow new registrations'],
            ['max_servers_per_user', '5', 'integer', 'Maximum servers per user'],
            ['default_server_expiry', '30', 'integer', 'Default server expiry in days'],
            ['maintenance_mode', 'false', 'boolean', 'Maintenance mode'],
            ['language', 'en', 'string', 'Default language'],
            ['timezone', 'UTC', 'string', 'Default timezone']
        ];

        for (const setting of settings) {
            await pool.execute(
                `INSERT IGNORE INTO settings (setting_key, setting_value, setting_type, description) 
                 VALUES (?, ?, ?, ?)`,
                setting
            );
        }

        console.log('Default data inserted successfully');
    } catch (error) {
        console.error('Error inserting default data:', error.message);
    }
};

// ============================================
// Close Pool (Graceful Shutdown)
// ============================================
const closePool = async () => {
    try {
        await pool.end();
        console.log('Database connection pool closed');
    } catch (error) {
        console.error('Error closing pool:', error.message);
    }
};

// ============================================
// Handle Process Termination
// ============================================
process.on('SIGINT', async () => {
    console.log('\nReceived SIGINT. Closing database pool...');
    await closePool();
    process.exit(0);
});

process.on('SIGTERM', async () => {
    console.log('\nReceived SIGTERM. Closing database pool...');
    await closePool();
    process.exit(0);
});

// ============================================
// Export Module
// ============================================
module.exports = {
    pool,
    query,
    transaction,
    testConnection,
    getPoolStatus,
    getDatabaseStats,
    initializeTables,
    insertDefaultData,
    closePool
};