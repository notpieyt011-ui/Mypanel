// ============================================
// Aqua Panel - Main Server File
// Location: /var/www/aqua-panel/server/server.js
// ============================================

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const session = require('express-session');
const http = require('http');
const { Server } = require('socket.io');

// Database
const { testConnection, initializeTables, insertDefaultData } = require('./config/database');

// Initialize Express
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: { origin: '*', methods: ['GET', 'POST'] }
});

// ============================================
// Middleware
// ============================================

// Security headers
app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false,
    crossOriginResourcePolicy: { policy: 'cross-origin' }
}));

// CORS
app.use(cors({
    origin: process.env.CORS_ORIGIN || '*',
    credentials: true
}));

// Compression
app.use(compression());

// Logging
app.use(morgan('combined'));

// Body parsing
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Rate limiting
const globalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 1000, // 1000 requests per window
    message: { error: 'Too many requests, please try again later.' }
});
app.use('/api/', globalLimiter);

// API-specific rate limiter
const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: { error: 'Too many API requests, please try again later.' }
});
app.use('/api/auth/', apiLimiter);

// Session
app.use(session({
    secret: process.env.SESSION_SECRET || 'aqua_panel_session_secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
}));

// ============================================
// Static Files
// ============================================

// Public assets
app.use('/css', express.static(path.join(__dirname, '..', 'public', 'css')));
app.use('/js', express.static(path.join(__dirname, '..', 'public', 'js')));
app.use('/images', express.static(path.join(__dirname, '..', 'public', 'images')));

// Uploads directory
const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}
app.use('/uploads', express.static(uploadsDir));

// ============================================
// API Routes
// ============================================

// Health check
app.get('/api/health', async (req, res) => {
    try {
        const dbConnected = await testConnection();
        res.json({
            status: 'ok',
            uptime: process.uptime(),
            timestamp: new Date().toISOString(),
            database: dbConnected ? 'connected' : 'disconnected',
            version: '1.0.0',
            memory: process.memoryUsage()
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: error.message
        });
    }
});

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/servers', require('./routes/servers'));
app.use('/api/nodes', require('./routes/nodes'));
app.use('/api/locations', require('./routes/locations'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/keys', require('./routes/api'));
app.use('/api/database', require('./routes/database'));

// ============================================
// Frontend Routes
// ============================================

// Helper to serve HTML files
const serveHtml = (filename) => (req, res) => {
    const filePath = path.join(__dirname, '..', filename);
    if (fs.existsSync(filePath)) {
        res.sendFile(filePath);
    } else {
        res.status(404).send('Page not found');
    }
};

// Main pages
app.get('/', serveHtml('landing.html'));
app.get('/register', serveHtml('register.html'));
app.get('/login', serveHtml('login.html'));
app.get('/dashboard', serveHtml('dashboard.html'));
app.get('/console', serveHtml('console.html'));
app.get('/admin', serveHtml('admin.html'));

// ============================================
// WebSocket (Socket.io)
// ============================================

io.on('connection', (socket) => {
    console.log(`[WS] User connected: ${socket.id}`);

    // Join server room
    socket.on('join-server', (serverId) => {
        socket.join(`server-${serverId}`);
        console.log(`[WS] ${socket.id} joined server-${serverId}`);
    });

    // Console commands
    socket.on('console-command', (data) => {
        console.log(`[WS] Console command from ${socket.id}: ${data.command}`);
        // Broadcast to server room
        socket.to(`server-${data.serverId}`).emit('console-output', {
            type: 'command',
            message: `> ${data.command}`,
            timestamp: new Date().toISOString()
        });
    });

    // Server power actions
    socket.on('server-power', (data) => {
        console.log(`[WS] Power action from ${socket.id}: ${data.action}`);
        socket.to(`server-${data.serverId}`).emit('power-status', {
            action: data.action,
            timestamp: new Date().toISOString()
        });
    });

    // Disconnect
    socket.on('disconnect', () => {
        console.log(`[WS] User disconnected: ${socket.id}`);
    });
});

// ============================================
// Error Handling
// ============================================

// 404 handler
app.use((req, res, next) => {
    if (req.path.startsWith('/api/')) {
        return res.status(404).json({
            error: 'API endpoint not found',
            path: req.path
        });
    }
    res.status(404).sendFile(path.join(__dirname, '..', 'public', '404.html'));
});

// Global error handler
app.use((err, req, res, next) => {
    console.error(`[ERROR] ${err.message}`);
    console.error(err.stack);

    if (req.path.startsWith('/api/')) {
        return res.status(err.status || 500).json({
            error: process.env.NODE_ENV === 'production'
                ? 'Internal server error'
                : err.message
        });
    }

    res.status(500).send('Internal Server Error');
});

// ============================================
// Graceful Shutdown
// ============================================
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

async function gracefulShutdown() {
    console.log('\n[SHUTDOWN] Received shutdown signal...');
    console.log('[SHUTDOWN] Closing HTTP server...');
    
    server.close(() => {
        console.log('[SHUTDOWN] HTTP server closed');
    });

    // Close database pool
    try {
        const { closePool } = require('./config/database');
        await closePool();
        console.log('[SHUTDOWN] Database pool closed');
    } catch (error) {
        console.error('[SHUTDOWN] Error closing database:', error.message);
    }

    console.log('[SHUTDOWN] Goodbye!');
    process.exit(0);
}

// ============================================
// Start Server
// ============================================
async function startServer() {
    const PORT = process.env.PORT || 3000;
    const NODE_ENV = process.env.NODE_ENV || 'development';

    try {
        // Initialize database
        console.log('[INIT] Checking database connection...');
        const dbConnected = await testConnection();

        if (dbConnected) {
            console.log('[INIT] Initializing database tables...');
            await initializeTables();
            console.log('[INIT] Inserting default data...');
            await insertDefaultData();
        } else {
            console.warn('[WARN] Database not available. Running without database.');
        }

        // Start listening
        server.listen(PORT, () => {
            console.log('');
            console.log('============================================');
            console.log('  AQUA PANEL - Server Started');
            console.log('============================================');
            console.log(`  Environment: ${NODE_ENV}`);
            console.log(`  Port: ${PORT}`);
            console.log(`  URL: http://localhost:${PORT}`);
            console.log(`  Database: ${dbConnected ? 'Connected' : 'Disconnected'}`);
            console.log('============================================');
            console.log('');
        });

    } catch (error) {
        console.error('[FATAL] Failed to start server:', error.message);
        console.error('[FATAL] Stack:', error.stack);
        process.exit(1);
    }
}

// Handle uncaught errors
process.on('uncaughtException', (error) => {
    console.error('[FATAL] Uncaught Exception:', error.message);
    console.error(error.stack);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('[FATAL] Unhandled Rejection at:', promise);
    console.error('[FATAL] Reason:', reason);
});

// Start the server
startServer();

module.exports = app;