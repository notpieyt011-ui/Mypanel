// ============================================
// Aqua Panel - Authentication Middleware
// Location: /var/www/aqua-panel/server/middleware/auth.js
// ============================================

const jwt = require('jsonwebtoken');
const { query } = require('../config/database');

/**
 * Main Authentication Middleware
 * Verifies JWT token and attaches user to request object
 * 
 * Token Sources (checked in order):
 * 1. Authorization header (Bearer token)
 * 2. Cookie (aqua_token)
 * 3. Query parameter (?token=)
 * 4. X-API-Key header
 */
const auth = async (req, res, next) => {
    try {
        let token = null;
        let tokenSource = 'header';

        // 1. Check Authorization header (Bearer token)
        const authHeader = req.header('Authorization');
        if (authHeader && authHeader.startsWith('Bearer ')) {
            token = authHeader.replace('Bearer ', '');
            tokenSource = 'header';
        }

        // 2. Check Cookie
        if (!token && req.cookies && req.cookies.aqua_token) {
            token = req.cookies.aqua_token;
            tokenSource = 'cookie';
        }

        // 3. Check query parameter
        if (!token && req.query.token) {
            token = req.query.token;
            tokenSource = 'query';
        }

        // 4. Check X-API-Key header
        if (!token && req.header('X-API-Key')) {
            token = req.header('X-API-Key');
            tokenSource = 'api-key';
        }

        // No token found
        if (!token) {
            return res.status(401).json({
                success: false,
                error: 'Access denied. No authentication token provided.',
                code: 'NO_TOKEN'
            });
        }

        // Verify JWT token
        let decoded;
        try {
            decoded = jwt.verify(token, process.env.JWT_SECRET);
        } catch (jwtError) {
            let errorMessage = 'Invalid authentication token.';
            let errorCode = 'INVALID_TOKEN';

            switch (jwtError.name) {
                case 'TokenExpiredError':
                    errorMessage = 'Token has expired. Please login again.';
                    errorCode = 'TOKEN_EXPIRED';
                    break;
                case 'JsonWebTokenError':
                    errorMessage = 'Token is malformed or invalid.';
                    errorCode = 'TOKEN_MALFORMED';
                    break;
                case 'NotBeforeError':
                    errorMessage = 'Token is not yet active.';
                    errorCode = 'TOKEN_NOT_ACTIVE';
                    break;
            }

            return res.status(401).json({
                success: false,
                error: errorMessage,
                code: errorCode
            });
        }

        // Validate decoded token structure
        if (!decoded.id) {
            return res.status(401).json({
                success: false,
                error: 'Invalid token payload.',
                code: 'INVALID_PAYLOAD'
            });
        }

        // Check if user exists and is active
        const users = await query(
            `SELECT 
                id, username, email, role, is_first_user, 
                status, avatar, credits, server_limit, last_login
             FROM users 
             WHERE id = ? AND status = 'active'`,
            [decoded.id]
        );

        if (users.length === 0) {
            return res.status(401).json({
                success: false,
                error: 'User account not found or inactive.',
                code: 'USER_NOT_FOUND'
            });
        }

        const user = users[0];

        // Check if token was issued before last password change
        if (decoded.iat && user.last_password_change) {
            const tokenIssuedAt = new Date(decoded.iat * 1000);
            const passwordChangedAt = new Date(user.last_password_change);
            
            if (tokenIssuedAt < passwordChangedAt) {
                return res.status(401).json({
                    success: false,
                    error: 'Token invalidated due to password change. Please login again.',
                    code: 'PASSWORD_CHANGED'
                });
            }
        }

        // Attach user to request object
        req.user = {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            isFirstUser: user.is_first_user,
            status: user.status,
            avatar: user.avatar,
            credits: user.credits,
            serverLimit: user.server_limit,
            lastLogin: user.last_login
        };

        // Attach token info
        req.token = {
            value: token,
            source: tokenSource,
            expiresAt: decoded.exp ? new Date(decoded.exp * 1000) : null,
            issuedAt: decoded.iat ? new Date(decoded.iat * 1000) : null
        };

        // Update last active timestamp (throttled to every 5 minutes)
        const now = new Date();
        const lastActive = user.last_active || user.last_login;
        
        if (!lastActive || (now - new Date(lastActive)) > 5 * 60 * 1000) {
            query(
                'UPDATE users SET last_active = NOW() WHERE id = ?',
                [user.id]
            ).catch(err => console.error('Update last active error:', err.message));
        }

        // Log API requests in development
        if (process.env.NODE_ENV === 'development') {
            console.log(
                `[AUTH] ${user.username} (${user.role}) | ${req.method} ${req.path} | Source: ${tokenSource}`
            );
        }

        // Continue to next middleware/route
        next();

    } catch (error) {
        console.error('Auth middleware error:', error.message);
        return res.status(500).json({
            success: false,
            error: 'Internal authentication error.',
            code: 'AUTH_ERROR'
        });
    }
};

/**
 * Optional Authentication Middleware
 * Attaches user if token is valid but doesn't require authentication
 * Useful for public routes that behave differently for logged-in users
 */
const optionalAuth = async (req, res, next) => {
    try {
        const authHeader = req.header('Authorization');
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            req.user = null;
            return next();
        }

        const token = authHeader.replace('Bearer ', '');
        
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            
            if (decoded.id) {
                const users = await query(
                    `SELECT id, username, email, role, is_first_user, status 
                     FROM users WHERE id = ? AND status = 'active'`,
                    [decoded.id]
                );
                
                req.user = users.length > 0 ? users[0] : null;
            }
        } catch (jwtError) {
            req.user = null;
        }

        next();
    } catch (error) {
        req.user = null;
        next();
    }
};

/**
 * Role-Based Authorization Middleware Factory
 * Creates middleware that checks for specific user roles
 * 
 * @param {...string} roles - Allowed roles ('admin', 'user')
 * @returns {Function} Express middleware
 * 
 * Usage: router.get('/admin', auth, requireRole('admin'), adminController);
 */
const requireRole = (...roles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required.',
                code: 'AUTH_REQUIRED'
            });
        }

        if (!roles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                error: `Access denied. Required role: ${roles.join(' or ')}.`,
                code: 'INSUFFICIENT_ROLE',
                requiredRoles: roles,
                userRole: req.user.role
            });
        }

        next();
    };
};

/**
 * Resource Ownership Middleware Factory
 * Checks if the authenticated user owns the requested resource
 * Admins bypass this check automatically
 * 
 * @param {string} resourceType - Type of resource ('server', 'api_key')
 * @param {string} paramName - URL parameter name for resource ID
 * @returns {Function} Express middleware
 * 
 * Usage: router.delete('/servers/:id', auth, requireOwnership('server', 'id'), deleteServer);
 */
const requireOwnership = (resourceType, paramName = 'id') => {
    return async (req, res, next) => {
        try {
            const resourceId = req.params[paramName];
            
            if (!resourceId) {
                return res.status(400).json({
                    success: false,
                    error: 'Resource ID is required.',
                    code: 'MISSING_RESOURCE_ID'
                });
            }

            // Admin bypass
            if (req.user.role === 'admin') {
                return next();
            }

            let isOwner = false;

            switch (resourceType) {
                case 'server':
                    const servers = await query(
                        'SELECT user_id FROM servers WHERE id = ?',
                        [resourceId]
                    );
                    isOwner = servers.length > 0 && servers[0].user_id === req.user.id;
                    break;

                case 'api_key':
                    const keys = await query(
                        'SELECT user_id FROM api_keys WHERE id = ?',
                        [resourceId]
                    );
                    isOwner = keys.length > 0 && keys[0].user_id === req.user.id;
                    break;

                case 'backup':
                    const backups = await query(
                        `SELECT s.user_id FROM backups b
                         JOIN servers s ON b.server_id = s.id
                         WHERE b.id = ?`,
                        [resourceId]
                    );
                    isOwner = backups.length > 0 && backups[0].user_id === req.user.id;
                    break;

                default:
                    return res.status(400).json({
                        success: false,
                        error: `Unknown resource type: ${resourceType}.`,
                        code: 'UNKNOWN_RESOURCE_TYPE'
                    });
            }

            if (!isOwner) {
                return res.status(403).json({
                    success: false,
                    error: `You do not own this ${resourceType}.`,
                    code: 'NOT_OWNER'
                });
            }

            next();
        } catch (error) {
            console.error('Ownership check error:', error.message);
            return res.status(500).json({
                success: false,
                error: 'Failed to verify resource ownership.',
                code: 'OWNERSHIP_CHECK_ERROR'
            });
        }
    };
};

/**
 * Rate Limiter by User Middleware
 * Simple in-memory rate limiter per authenticated user
 * 
 * @param {number} maxRequests - Maximum requests allowed in window
 * @param {number} windowMs - Time window in milliseconds
 * @returns {Function} Express middleware
 */
const userRateLimit = (maxRequests = 60, windowMs = 60000) => {
    const requestCounts = new Map();

    // Clean up old entries periodically
    setInterval(() => {
        const now = Date.now();
        for (const [key, data] of requestCounts.entries()) {
            if (now - data.windowStart > windowMs) {
                requestCounts.delete(key);
            }
        }
    }, windowMs);

    return (req, res, next) => {
        if (!req.user) {
            return next();
        }

        const userId = req.user.id;
        const now = Date.now();
        
        if (!requestCounts.has(userId)) {
            requestCounts.set(userId, {
                windowStart: now,
                count: 1
            });
            return next();
        }

        const userData = requestCounts.get(userId);
        
        if (now - userData.windowStart > windowMs) {
            userData.windowStart = now;
            userData.count = 1;
            return next();
        }

        userData.count++;

        if (userData.count > maxRequests) {
            return res.status(429).json({
                success: false,
                error: 'Too many requests. Please slow down.',
                code: 'RATE_LIMIT_EXCEEDED',
                retryAfter: Math.ceil((userData.windowStart + windowMs - now) / 1000)
            });
        }

        next();
    };
};

/**
 * Maintenance Mode Middleware
 * Blocks non-admin users during maintenance mode
 */
const maintenanceMode = async (req, res, next) => {
    try {
        // Admin can always access
        if (req.user && req.user.role === 'admin') {
            return next();
        }

        // Check maintenance mode from database
        const settings = await query(
            "SELECT setting_value FROM settings WHERE setting_key = 'maintenance_mode'"
        );
        
        const isMaintenance = settings.length > 0 && settings[0].setting_value === 'true';

        if (isMaintenance) {
            // Allow auth routes during maintenance
            if (req.path.startsWith('/api/auth/')) {
                return next();
            }
            
            return res.status(503).json({
                success: false,
                error: 'Aqua Panel is currently under maintenance. Please try again later.',
                code: 'MAINTENANCE_MODE'
            });
        }

        next();
    } catch (error) {
        // If database check fails, allow access
        next();
    }
};

// ============================================
// Export All Middleware
// ============================================
module.exports = auth;
module.exports.optional = optionalAuth;
module.exports.requireRole = requireRole;
module.exports.requireOwnership = requireOwnership;
module.exports.userRateLimit = userRateLimit;
module.exports.maintenanceMode = maintenanceMode;