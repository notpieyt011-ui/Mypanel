// ============================================
// Aqua Panel - Admin Middleware
// Location: /var/www/aqua-panel/server/middleware/admin.js
// ============================================

const { query } = require('../config/database');

/**
 * Admin Authorization Middleware
 * Checks if the authenticated user has admin role
 * Must be used AFTER auth middleware
 */
const admin = async (req, res, next) => {
    try {
        // Check if user is attached (auth middleware should run first)
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required. Please login first.',
                code: 'AUTH_REQUIRED'
            });
        }

        // Check if user has admin role
        if (req.user.role !== 'admin') {
            // Log unauthorized access attempt
            await query(
                `INSERT INTO activity_logs (user_id, action, description, ip_address, metadata) 
                 VALUES (?, ?, ?, ?, ?)`,
                [
                    req.user.id,
                    'admin_access_denied',
                    `Unauthorized admin access: ${req.method} ${req.originalUrl}`,
                    req.ip,
                    JSON.stringify({
                        method: req.method,
                        url: req.originalUrl,
                        userAgent: req.get('User-Agent') || 'Unknown'
                    })
                ]
            ).catch(err => console.error('Log admin denial error:', err.message));

            return res.status(403).json({
                success: false,
                error: 'Access denied. Administrator privileges required.',
                code: 'ADMIN_REQUIRED',
                hint: 'This area is restricted to administrators only.'
            });
        }

        // Check if admin account is still active
        if (req.user.status !== 'active') {
            return res.status(403).json({
                success: false,
                error: 'Your admin account is not active.',
                code: 'ADMIN_INACTIVE'
            });
        }

        // Determine if super admin (first user)
        const isSuperAdmin = req.user.isFirstUser === true || req.user.isFirstUser === 1;

        // Attach admin-specific info to request
        req.admin = {
            isSuperAdmin: isSuperAdmin,
            canDeleteUsers: isSuperAdmin,
            canModifySettings: true,
            canManageNodes: true,
            canViewLogs: true,
            canManagePlugins: true,
            canDeleteServers: true
        };

        // Log admin access
        console.log(
            `[ADMIN] ${req.user.username} | ${req.method} ${req.originalUrl} | IP: ${req.ip}`
        );

        // Continue to next middleware/route
        next();

    } catch (error) {
        console.error('Admin middleware error:', error.message);
        return res.status(500).json({
            success: false,
            error: 'Internal server error during admin verification.',
            code: 'ADMIN_CHECK_ERROR'
        });
    }
};

/**
 * Super Admin Middleware
 * Only allows the first registered user (super admin)
 * For critical operations like deleting other admins
 */
const superAdmin = async (req, res, next) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required.',
                code: 'AUTH_REQUIRED'
            });
        }

        // Check if user is the first user (super admin)
        const users = await query(
            'SELECT is_first_user FROM users WHERE id = ?',
            [req.user.id]
        );

        if (users.length === 0) {
            return res.status(401).json({
                success: false,
                error: 'User not found.',
                code: 'USER_NOT_FOUND'
            });
        }

        const isFirstUser = users[0].is_first_user === 1 || users[0].is_first_user === true;

        if (!isFirstUser) {
            return res.status(403).json({
                success: false,
                error: 'Only the primary administrator can perform this action.',
                code: 'SUPER_ADMIN_REQUIRED',
                hint: 'This operation requires super admin privileges.'
            });
        }

        // Attach super admin flag
        req.isSuperAdmin = true;

        next();

    } catch (error) {
        console.error('Super admin middleware error:', error.message);
        return res.status(500).json({
            success: false,
            error: 'Failed to verify super admin status.',
            code: 'SUPER_ADMIN_CHECK_ERROR'
        });
    }
};

/**
 * Admin Permission Middleware Factory
 * Checks for specific admin permissions
 * 
 * @param {...string} permissions - Required permissions
 * @returns {Function} Express middleware
 * 
 * Usage: router.delete('/servers/:id', auth, admin, requirePermission('servers.delete'), deleteServer);
 */
const requirePermission = (...permissions) => {
    return async (req, res, next) => {
        try {
            if (!req.user || req.user.role !== 'admin') {
                return res.status(403).json({
                    success: false,
                    error: 'Admin access required.',
                    code: 'ADMIN_REQUIRED'
                });
            }

            // Super admin has all permissions
            if (req.user.isFirstUser) {
                return next();
            }

            // Get admin's specific permissions from database
            const adminPerms = await query(
                'SELECT permissions FROM admin_permissions WHERE user_id = ?',
                [req.user.id]
            );

            let userPermissions = [];
            if (adminPerms.length > 0 && adminPerms[0].permissions) {
                try {
                    userPermissions = JSON.parse(adminPerms[0].permissions);
                } catch (e) {
                    userPermissions = [];
                }
            }

            // Check if user has all required permissions
            const hasAllPermissions = permissions.every(
                perm => userPermissions.includes(perm) || userPermissions.includes('*')
            );

            if (!hasAllPermissions) {
                return res.status(403).json({
                    success: false,
                    error: 'Insufficient admin permissions.',
                    code: 'INSUFFICIENT_PERMISSIONS',
                    required: permissions,
                    granted: userPermissions
                });
            }

            next();

        } catch (error) {
            console.error('Permission check error:', error.message);
            return res.status(500).json({
                success: false,
                error: 'Failed to verify permissions.',
                code: 'PERMISSION_CHECK_ERROR'
            });
        }
    };
};

/**
 * Admin Activity Logger Middleware
 * Automatically logs all admin actions
 * 
 * @param {string} action - Action name
 * @param {string} description - Action description
 * @returns {Function} Express middleware
 */
const logActivity = (action, description) => {
    return async (req, res, next) => {
        try {
            // Store original json method
            const originalJson = res.json.bind(res);

            // Override json method to log after response
            res.json = function(data) {
                // Only log successful operations
                if (data && data.success === true && req.user) {
                    query(
                        `INSERT INTO activity_logs (user_id, action, description, ip_address, metadata) 
                         VALUES (?, ?, ?, ?, ?)`,
                        [
                            req.user.id,
                            action || `admin_${req.method.toLowerCase()}`,
                            description || `${req.method} ${req.originalUrl}`,
                            req.ip,
                            JSON.stringify({
                                method: req.method,
                                url: req.originalUrl,
                                body: req.body ? JSON.stringify(req.body).substring(0, 500) : null,
                                responseStatus: res.statusCode
                            })
                        ]
                    ).catch(err => console.error('Activity log error:', err.message));
                }

                // Call original json method
                return originalJson(data);
            };

            next();

        } catch (error) {
            console.error('Activity logger error:', error.message);
            next();
        }
    };
};

/**
 * Admin IP Whitelist Middleware
 * Restricts admin access to specific IP addresses
 * Super admin bypasses this check
 * 
 * @param {Array<string>} allowedIPs - Array of allowed IP addresses
 * @returns {Function} Express middleware
 */
const ipWhitelist = (allowedIPs) => {
    return (req, res, next) => {
        if (!req.user || req.user.role !== 'admin') {
            return next();
        }

        // Super admin bypass
        if (req.user.isFirstUser) {
            return next();
        }

        const clientIP = req.ip || req.connection.remoteAddress || '0.0.0.0';
        
        // Normalize IPs (remove IPv6 prefix)
        const normalizedClientIP = clientIP.replace('::ffff:', '');
        const normalizedAllowedIPs = allowedIPs.map(ip => ip.replace('::ffff:', ''));

        if (!normalizedAllowedIPs.includes(normalizedClientIP) && !normalizedAllowedIPs.includes('*')) {
            return res.status(403).json({
                success: false,
                error: 'Admin access not allowed from your IP address.',
                code: 'IP_NOT_ALLOWED',
                clientIP: normalizedClientIP
            });
        }

        next();
    };
};

/**
 * Two-Factor Authentication Middleware
 * Checks if 2FA is required and verified for admin actions
 */
const require2FA = async (req, res, next) => {
    try {
        if (!req.user || req.user.role !== 'admin') {
            return next();
        }

        // Check if 2FA is enabled for this admin
        const twoFactorData = await query(
            'SELECT two_factor_enabled, two_factor_verified FROM users WHERE id = ?',
            [req.user.id]
        );

        if (twoFactorData.length === 0) {
            return next();
        }

        const { two_factor_enabled } = twoFactorData[0];

        // If 2FA is not enabled, skip
        if (!two_factor_enabled) {
            return next();
        }

        // If 2FA is enabled but not verified for this session
        if (!req.session || !req.session.twoFactorVerified) {
            return res.status(403).json({
                success: false,
                error: 'Two-factor authentication required.',
                code: '2FA_REQUIRED',
                action: 'verify_2fa'
            });
        }

        next();

    } catch (error) {
        console.error('2FA middleware error:', error.message);
        // Don't block on 2FA check error
        next();
    }
};

/**
 * Admin Rate Limit Middleware
 * Stricter rate limiting for sensitive admin operations
 * 
 * @param {number} maxRequests - Maximum requests per window
 * @param {number} windowMs - Time window in milliseconds
 * @returns {Function} Express middleware
 */
const adminRateLimit = (maxRequests = 30, windowMs = 60000) => {
    const requestCounts = new Map();

    // Clean up old entries periodically
    setInterval(() => {
        const now = Date.now();
        for (const [key, data] of requestCounts.entries()) {
            if (now - data.windowStart > windowMs) {
                requestCounts.delete(key);
            }
        }
    }, windowMs);

    return (req, res, next) => {
        if (!req.user || req.user.role !== 'admin') {
            return next();
        }

        const key = `admin_${req.user.id}`;
        const now = Date.now();

        if (!requestCounts.has(key)) {
            requestCounts.set(key, { windowStart: now, count: 1 });
            return next();
        }

        const data = requestCounts.get(key);

        if (now - data.windowStart > windowMs) {
            data.windowStart = now;
            data.count = 1;
            return next();
        }

        data.count++;

        if (data.count > maxRequests) {
            return res.status(429).json({
                success: false,
                error: 'Too many admin requests. Please slow down.',
                code: 'ADMIN_RATE_LIMIT',
                retryAfter: Math.ceil((data.windowStart + windowMs - now) / 1000)
            });
        }

        next();
    };
};

/**
 * Session Timeout Middleware for Admin
 * Requires re-authentication after specified idle time
 * 
 * @param {number} timeoutMinutes - Session timeout in minutes
 * @returns {Function} Express middleware
 */
const sessionTimeout = (timeoutMinutes = 30) => {
    return (req, res, next) => {
        if (!req.user || req.user.role !== 'admin') {
            return next();
        }

        if (!req.session) {
            return next();
        }

        if (!req.session.lastAdminAction) {
            req.session.lastAdminAction = Date.now();
            return next();
        }

        const timeSinceLastAction = Date.now() - req.session.lastAdminAction;
        const timeoutMs = timeoutMinutes * 60 * 1000;

        if (timeSinceLastAction > timeoutMs) {
            return res.status(401).json({
                success: false,
                error: `Admin session expired after ${timeoutMinutes} minutes of inactivity. Please login again.`,
                code: 'SESSION_EXPIRED',
                action: 'relogin'
            });
        }

        // Update last action time
        req.session.lastAdminAction = Date.now();
        next();
    };
};

// ============================================
// Export All Middleware
// ============================================
module.exports = admin;
module.exports.superAdmin = superAdmin;
module.exports.requirePermission = requirePermission;
module.exports.logActivity = logActivity;
module.exports.ipWhitelist = ipWhitelist;
module.exports.require2FA = require2FA;
module.exports.rateLimit = adminRateLimit;
module.exports.sessionTimeout = sessionTimeout;