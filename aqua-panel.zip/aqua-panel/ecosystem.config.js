// ============================================
// Aqua Panel - PM2 Ecosystem Configuration
// ============================================
// Start: pm2 start ecosystem.config.js
// ============================================

module.exports = {
  apps: [
    {
      // Application name
      name: 'aqua-panel',

      // Main script
      script: 'server/server.js',

      // Working directory
      cwd: '/var/www/aqua-panel',

      // Number of instances (1 = single, 'max' = all CPU cores)
      instances: 1,

      // Execution mode
      exec_mode: 'fork',

      // Watch for file changes (disable in production)
      watch: false,

      // Files to ignore when watching
      ignore_watch: [
        'node_modules',
        'uploads',
        'logs',
        'backups',
        '*.log',
        '.git'
      ],

      // Maximum memory before auto-restart
      max_memory_restart: '1G',

      // Environment variables
      env: {
        NODE_ENV: 'production',
        PORT: 3000
      },

      // Development environment
      env_development: {
        NODE_ENV: 'development',
        PORT: 3000
      },

      // Log files
      error_file: 'logs/error.log',
      out_file: 'logs/out.log',
      log_file: 'logs/combined.log',

      // Log date format
      time: true,

      // Merge logs from all instances
      merge_logs: true,

      // Auto restart if app crashes
      autorestart: true,

      // Maximum auto restarts per day
      max_restarts: 10,

      // Minimum uptime before considering app started
      min_uptime: '10s',

      // Delay between restarts
      restart_delay: 4000,

      // Kill timeout
      kill_timeout: 5000,

      // Node arguments
      node_args: '--max-old-space-size=1024',

      // Instance identifier
      instance_var: 'INSTANCE_ID',

      // Cron restart (optional - restart at 4 AM daily)
      // cron_restart: '0 4 * * *'
    }
  ],

  // ============================================
  // Deployment Configuration
  // ============================================
  deploy: {
    production: {
      // SSH user
      user: 'root',

      // Server IP or hostname
      host: 'YOUR_SERVER_IP',

      // Git branch
      ref: 'origin/main',

      // Git repository URL
      repo: 'https://github.com/yourusername/aqua-panel.git',

      // Deployment path
      path: '/var/www/aqua-panel',

      // Pre-deployment commands
      'pre-deploy': 'git fetch --all',

      // Post-deployment commands
      'post-deploy': 'npm install --production && pm2 reload ecosystem.config.js --env production',

      // Pre-setup commands
      'pre-setup': 'apt update && apt install -y nodejs npm mysql-server nginx'
    },

    staging: {
      user: 'root',
      host: 'YOUR_STAGING_IP',
      ref: 'origin/develop',
      repo: 'https://github.com/yourusername/aqua-panel.git',
      path: '/var/www/aqua-panel-staging',
      'post-deploy': 'npm install && pm2 reload ecosystem.config.js --env development'
    }
  }
};