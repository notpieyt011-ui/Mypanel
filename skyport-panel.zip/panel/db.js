const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

const dbPath = path.join(__dirname, 'skyport.db');
const db = new Database(dbPath);

db.pragma('journal_mode = WAL');

// Create all tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user' CHECK(role IN ('admin', 'user', 'viewer')),
    theme TEXT DEFAULT 'dark',
    avatar TEXT,
    last_login DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS servers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    user_id INTEGER NOT NULL,
    image TEXT NOT NULL,
    ports TEXT,
    env TEXT,
    memory INTEGER DEFAULT 1024,
    cpu REAL DEFAULT 1.0,
    volumes TEXT,
    notes TEXT,
    auto_start INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    display_name TEXT NOT NULL,
    image TEXT NOT NULL,
    default_ports TEXT,
    default_env TEXT,
    default_memory INTEGER,
    default_cpu REAL,
    icon TEXT,
    category TEXT,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS backups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_id TEXT NOT NULL,
    filename TEXT NOT NULL,
    size INTEGER,
    type TEXT DEFAULT 'manual',
    status TEXT DEFAULT 'completed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (server_id) REFERENCES servers(id)
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS api_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    key TEXT UNIQUE NOT NULL,
    permissions TEXT DEFAULT 'read',
    last_used DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

// Create default admin if not exists
const adminExists = db.prepare('SELECT id FROM users WHERE username = ?').get('admin');
if (!adminExists) {
  const hash = bcrypt.hashSync('admin123', 10);
  db.prepare('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)')
    .run('admin', 'admin@skyport.local', hash, 'admin');
  console.log('✅ Default admin: admin / admin123');
}

// Create default templates if none exist
const templateCount = db.prepare('SELECT COUNT(*) as count FROM templates').get();
if (templateCount.count === 0) {
  const templates = [
    ['minecraft-java', 'Minecraft Java', 'itzg/minecraft-server', '{"25565/tcp":[{"HostPort":"25565"}]}', 'EULA=TRUE', 2048, 2.0, '🧱', 'games', 'Minecraft Java Edition'],
    ['minecraft-bedrock', 'Minecraft Bedrock', 'itzg/minecraft-bedrock-server', '{"19132/udp":[{"HostPort":"19132"}]}', 'EULA=TRUE', 1024, 1.0, '🧱', 'games', 'Minecraft Bedrock'],
    ['cs2', 'Counter-Strike 2', 'joedwards32/cs2', '{"27015/tcp":[{"HostPort":"27015"}],"27015/udp":[{"HostPort":"27015"}]}', 'SERVER_HOSTNAME=CS2 Server', 2048, 2.0, '🔫', 'games', 'CS2 Server'],
    ['nodejs', 'Node.js App', 'node:18-alpine', '{"3000/tcp":[{"HostPort":"3000"}]}', 'NODE_ENV=production', 512, 0.5, '💚', 'dev', 'Node.js App'],
  ];

  const insert = db.prepare('INSERT INTO templates (name, display_name, image, default_ports, default_env, default_memory, default_cpu, icon, category, description) VALUES (?,?,?,?,?,?,?,?,?,?)');
  
  const insertAll = db.transaction((items) => {
    for (const t of items) insert.run(...t);
  });
  
  insertAll(templates);
  console.log('✅ Templates created');
}

// Default settings
const settingsExist = db.prepare('SELECT COUNT(*) as count FROM settings').get();
if (settingsExist.count === 0) {
  const settings = [
    ['panel_name', 'Skyport Panel'],
    ['primary_color', '#6366f1'],
    ['enable_registration', 'false'],
    ['max_servers_per_user', '5'],
  ];

  const insert = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)');
  for (const s of settings) insert.run(...s);
  console.log('✅ Settings created');
}

module.exports = db;