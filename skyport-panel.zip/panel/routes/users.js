const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { authenticate, requireAdmin } = require('../auth');

// Get all users (admin only)
router.get('/', authenticate, requireAdmin, (req, res) => {
  try {
    const users = db.prepare('SELECT id, username, email, role, theme, avatar, last_login, created_at FROM users ORDER BY id').all();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single user
router.get('/:id', authenticate, (req, res) => {
  try {
    // Users can only see their own profile (unless admin)
    if (req.user.role !== 'admin' && req.user.id !== parseInt(req.params.id)) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const user = db.prepare('SELECT id, username, email, role, theme, avatar, last_login, created_at FROM users WHERE id = ?').get(req.params.id);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create user (admin only)
router.post('/', authenticate, requireAdmin, (req, res) => {
  try {
    const { username, email, password, role } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    if (username.length < 3) {
      return res.status(400).json({ error: 'Username must be at least 3 characters' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const existing = db.prepare('SELECT id FROM users WHERE username = ? OR email = ?').get(username, email || null);
    if (existing) {
      return res.status(409).json({ error: 'Username or email already exists' });
    }

    const hash = bcrypt.hashSync(password, 10);
    const result = db.prepare('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)').run(
      username, 
      email || null, 
      hash, 
      role || 'user'
    );

    res.status(201).json({ 
      message: 'User created successfully',
      user: {
        id: result.lastInsertRowid,
        username,
        email,
        role: role || 'user'
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update user (admin or own profile)
router.put('/:id', authenticate, (req, res) => {
  try {
    // Only admin or the user themselves can update
    if (req.user.role !== 'admin' && req.user.id !== parseInt(req.params.id)) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const { email, avatar } = req.body;
    
    // Non-admins cannot change role
    if (req.user.role !== 'admin' && req.body.role) {
      return res.status(403).json({ error: 'Cannot change your own role' });
    }

    const updates = [];
    const values = [];

    if (email !== undefined) {
      updates.push('email = ?');
      values.push(email);
    }

    if (avatar !== undefined) {
      updates.push('avatar = ?');
      values.push(avatar);
    }

    if (req.body.role && req.user.role === 'admin') {
      if (!['admin', 'user', 'viewer'].includes(req.body.role)) {
        return res.status(400).json({ error: 'Invalid role. Use: admin, user, or viewer' });
      }
      updates.push('role = ?');
      values.push(req.body.role);
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    values.push(req.params.id);
    db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...values);

    res.json({ message: 'User updated successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete user (admin only)
router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    if (parseInt(req.params.id) === req.user.id) {
      return res.status(400).json({ error: 'Cannot delete your own account' });
    }

    const user = db.prepare('SELECT id FROM users WHERE id = ?').get(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Delete user's servers first
    db.prepare('DELETE FROM servers WHERE user_id = ?').run(req.params.id);
    
    // Delete user's API keys
    db.prepare('DELETE FROM api_keys WHERE user_id = ?').run(req.params.id);
    
    // Delete user
    db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id);

    res.json({ message: 'User and all associated servers deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Change password
router.put('/:id/password', authenticate, (req, res) => {
  try {
    // Only the user themselves or admin can change password
    if (req.user.role !== 'admin' && req.user.id !== parseInt(req.params.id)) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const { currentPassword, newPassword } = req.body;

    // Admin can change without current password
    if (req.user.role !== 'admin') {
      if (!currentPassword) {
        return res.status(400).json({ error: 'Current password is required' });
      }

      const user = db.prepare('SELECT password FROM users WHERE id = ?').get(req.params.id);
      if (!bcrypt.compareSync(currentPassword, user.password)) {
        return res.status(400).json({ error: 'Current password is incorrect' });
      }
    }

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters' });
    }

    const hash = bcrypt.hashSync(newPassword, 10);
    db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hash, req.params.id);

    res.json({ message: 'Password changed successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get user's servers
router.get('/:id/servers', authenticate, (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.id !== parseInt(req.params.id)) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const servers = db.prepare('SELECT * FROM servers WHERE user_id = ? ORDER BY created_at DESC').all(req.params.id);
    res.json(servers);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get panel settings
router.get('/settings/panel', authenticate, requireAdmin, (req, res) => {
  try {
    const settings = db.prepare('SELECT * FROM settings').all();
    const settingsObj = {};
    settings.forEach(s => {
      settingsObj[s.key] = s.value;
    });
    res.json(settingsObj);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update panel settings
router.put('/settings/panel', authenticate, requireAdmin, (req, res) => {
  try {
    const updates = req.body;
    const stmt = db.prepare('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)');
    
    const updateMany = db.transaction((updates) => {
      for (const [key, value] of Object.entries(updates)) {
        stmt.run(key, String(value));
      }
    });
    
    updateMany(updates);
    res.json({ message: 'Settings updated successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Generate API key
router.post('/:id/apikey', authenticate, (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.id !== parseInt(req.params.id)) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const { name, permissions } = req.body;
    if (!name) {
      return res.status(400).json({ error: 'API key name is required' });
    }

    const crypto = require('crypto');
    const key = 'sk-' + crypto.randomBytes(32).toString('hex');

    db.prepare('INSERT INTO api_keys (user_id, name, key, permissions) VALUES (?, ?, ?, ?)').run(
      req.params.id,
      name,
      key,
      permissions || 'read'
    );

    res.status(201).json({ 
      message: 'API key created',
      key: key,
      name: name
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get user's API keys
router.get('/:id/apikeys', authenticate, (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.id !== parseInt(req.params.id)) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const keys = db.prepare('SELECT id, name, permissions, last_used, created_at FROM api_keys WHERE user_id = ?').all(req.params.id);
    res.json(keys);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete API key
router.delete('/:id/apikey/:keyId', authenticate, (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.id !== parseInt(req.params.id)) {
      return res.status(403).json({ error: 'Access denied' });
    }

    db.prepare('DELETE FROM api_keys WHERE id = ? AND user_id = ?').run(req.params.keyId, req.params.id);
    res.json({ message: 'API key deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;