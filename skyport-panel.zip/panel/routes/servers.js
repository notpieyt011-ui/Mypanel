const express = require('express');
const router = express.Router();
const db = require('../db');
const { authenticate, requireAdmin, checkServerOwnership } = require('../auth');
const { createServer, listServers, serverAction, getStats, execCommand } = require('../docker');

// Get all servers
router.get('/', authenticate, async (req, res) => {
  try {
    const containers = await listServers();
    const dbServers = db.prepare('SELECT * FROM servers').all();
    
    const servers = containers.map(container => {
      const dbServer = dbServers.find(s => s.id === container.id);
      
      if (req.user.role !== 'admin' && dbServer && dbServer.user_id !== req.user.id) {
        return null;
      }
      
      return {
        ...container,
        owner_id: dbServer?.user_id,
        memory: dbServer?.memory,
        cpu: dbServer?.cpu,
        notes: dbServer?.notes,
        auto_start: dbServer?.auto_start
      };
    }).filter(Boolean);

    res.json(servers);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create server
router.post('/', authenticate, async (req, res) => {
  try {
    const maxServers = parseInt(db.prepare('SELECT value FROM settings WHERE key = ?').get('max_servers_per_user')?.value || '5');
    
    if (req.user.role !== 'admin') {
      const userServerCount = db.prepare('SELECT COUNT(*) as count FROM servers WHERE user_id = ?').get(req.user.id);
      if (userServerCount.count >= maxServers) {
        return res.status(403).json({ error: `Maximum ${maxServers} servers allowed per user` });
      }
    }

    const { name, image, ports, env, memory, cpu, volumes, template } = req.body;

    let finalImage = image;
    let finalPorts = ports;
    let finalEnv = env;
    let finalMemory = memory;
    let finalCpu = cpu;

    if (template) {
      const templateData = db.prepare('SELECT * FROM templates WHERE name = ?').get(template);
      if (templateData) {
        finalImage = image || templateData.image;
        finalPorts = ports || JSON.parse(templateData.default_ports);
        finalEnv = env || templateData.default_env.split('\n');
        finalMemory = memory || templateData.default_memory;
        finalCpu = cpu || templateData.default_cpu;
      }
    }

    if (!finalImage) {
      return res.status(400).json({ error: 'Image is required' });
    }

    const containerName = name.toLowerCase().replace(/[^a-z0-9-]/g, '-');
    const fullName = `${containerName}-${Date.now().toString(36)}`;

    const id = await createServer({
      name: fullName,
      image: finalImage,
      ports: finalPorts,
      env: Array.isArray(finalEnv) ? finalEnv : finalEnv?.split('\n') || [],
      memory: finalMemory || 1024,
      cpu: finalCpu || 1.0,
      volumes: volumes
    });

    const shortId = id.substring(0, 12);
    
    db.prepare(`
      INSERT INTO servers (id, name, user_id, image, ports, env, memory, cpu, volumes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      shortId, name, req.user.id, finalImage,
      JSON.stringify(finalPorts), JSON.stringify(finalEnv),
      finalMemory, finalCpu, JSON.stringify(volumes)
    );

    res.status(201).json({
      id: shortId,
      name,
      image: finalImage,
      message: 'Server created successfully'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single server
router.get('/:id', authenticate, checkServerOwnership, async (req, res) => {
  try {
    const dbServer = db.prepare('SELECT * FROM servers WHERE id = ?').get(req.params.id);
    if (!dbServer) {
      return res.status(404).json({ error: 'Server not found' });
    }

    const stats = await getStats(req.params.id);
    res.json({ ...dbServer, stats });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Server actions
router.post('/:id/:action', authenticate, checkServerOwnership, async (req, res) => {
  try {
    const { id, action } = req.params;
    
    const validActions = ['start', 'stop', 'restart', 'remove', 'logs'];
    if (!validActions.includes(action)) {
      return res.status(400).json({ error: 'Invalid action. Use: start, stop, restart, remove, logs' });
    }

    const result = await serverAction(id, action);

    if (action === 'remove') {
      db.prepare('DELETE FROM servers WHERE id = ?').run(id);
    }

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get live stats
router.get('/:id/stats', authenticate, checkServerOwnership, async (req, res) => {
  try {
    const stats = await getStats(req.params.id);
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Execute command in container
router.post('/:id/exec', authenticate, checkServerOwnership, async (req, res) => {
  try {
    const { command } = req.body;
    if (!command) {
      return res.status(400).json({ error: 'Command is required' });
    }

    const output = await execCommand(req.params.id, command);
    res.json({ output });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update server notes
router.put('/:id/notes', authenticate, checkServerOwnership, async (req, res) => {
  try {
    const { notes } = req.body;
    db.prepare('UPDATE servers SET notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(notes, req.params.id);
    res.json({ message: 'Notes updated successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get server templates
router.get('/templates/list', authenticate, (req, res) => {
  try {
    const templates = db.prepare('SELECT * FROM templates ORDER BY category, display_name').all();
    res.json(templates);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;