const jwt = require('jsonwebtoken');
const db = require('./db');

// Main authentication middleware
function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authorization token required' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret-key-change-me');
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// Optional auth - doesn't fail if no token
function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    req.user = null;
    return next();
  }

  const token = authHeader.split(' ')[1];
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET || 'secret-key-change-me');
  } catch (err) {
    req.user = null;
  }
  next();
}

// Admin only middleware
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

// Check server ownership
function checkServerOwnership(req, res, next) {
  const serverId = req.params.id;
  if (!serverId) return next();

  // Admins can access all servers
  if (req.user.role === 'admin') return next();

  const server = db.prepare('SELECT * FROM servers WHERE id = ? AND user_id = ?')
    .get(serverId, req.user.id);

  if (!server) {
    return res.status(403).json({ error: 'Access denied: You do not own this server' });
  }

  req.server = server;
  next();
}

module.exports = { 
  authenticate, 
  optionalAuth, 
  requireAdmin, 
  checkServerOwnership 
};