const Docker = require('dockerode');
const docker = new Docker({ socketPath: '/var/run/docker.sock' });

// Pull image from Docker Hub
async function pullImage(image) {
  return new Promise((resolve, reject) => {
    docker.pull(image, (err, stream) => {
      if (err) return reject(err);
      docker.modem.followProgress(stream, (err, output) => {
        if (err) return reject(err);
        resolve(output);
      });
    });
  });
}

// Create and start a container
async function createServer({ name, image, ports, env, memory, cpu, volumes }) {
  try {
    await docker.getImage(image).inspect();
  } catch {
    console.log(`Pulling image: ${image}...`);
    await pullImage(image);
  }

  const containerConfig = {
    Image: image,
    name: name,
    Env: env || [],
    HostConfig: {
      PortBindings: ports || {},
      Memory: memory ? memory * 1024 * 1024 : 0,
      NanoCpus: cpu ? cpu * 1e9 : 0,
      RestartPolicy: { Name: 'unless-stopped' },
      Binds: volumes || []
    }
  };

  const container = await docker.createContainer(containerConfig);
  await container.start();
  return container.id;
}

// List all containers
async function listServers() {
  const containers = await docker.listContainers({ all: true });
  return containers.map(c => ({
    id: c.Id.substring(0, 12),
    name: c.Names[0] ? c.Names[0].replace('/', '') : 'unnamed',
    image: c.Image,
    state: c.State,
    status: c.Status,
    ports: c.Ports,
    created: c.Created
  }));
}

// Start/Stop/Restart/Remove/Logs
async function serverAction(id, action) {
  const container = docker.getContainer(id);
  
  switch(action) {
    case 'start':
      await container.start();
      break;
    case 'stop':
      await container.stop();
      break;
    case 'restart':
      await container.restart();
      break;
    case 'remove':
      await container.stop().catch(() => {});
      await container.remove({ force: true });
      break;
    case 'logs':
      const logs = await container.logs({ 
        stdout: true, 
        stderr: true, 
        tail: 100 
      });
      return logs.toString('utf8');
    default:
      throw new Error(`Unknown action: ${action}`);
  }
  
  return { success: true, action };
}

// Get live stats
async function getStats(id) {
  const container = docker.getContainer(id);
  
  try {
    const stats = await container.stats({ stream: false });
    
    const cpuDelta = stats.cpu_stats.cpu_usage.total_usage - stats.precpu_stats.cpu_usage.total_usage;
    const systemDelta = stats.cpu_stats.system_cpu_usage - stats.precpu_stats.system_cpu_usage;
    const cpuCores = stats.cpu_stats.online_cpus || 1;
    const cpuPercent = systemDelta > 0 ? (cpuDelta / systemDelta) * cpuCores * 100 : 0;

    const memUsage = stats.memory_stats.usage || 0;
    const memLimit = stats.memory_stats.limit || 1;
    const memPercent = (memUsage / memLimit) * 100;

    return {
      cpuPercent: Math.min(cpuPercent, 100).toFixed(1),
      memUsageMB: (memUsage / 1024 / 1024).toFixed(0),
      memLimitMB: (memLimit / 1024 / 1024).toFixed(0),
      memPercent: memPercent.toFixed(1),
      netRx: stats.networks?.eth0?.rx_bytes || 0,
      netTx: stats.networks?.eth0?.tx_bytes || 0,
      timestamp: Date.now()
    };
  } catch (err) {
    return { error: 'Container not running', cpuPercent: 0, memUsageMB: 0, memLimitMB: 0, memPercent: 0 };
  }
}

// Execute command inside container
async function execCommand(id, command) {
  const container = docker.getContainer(id);
  const exec = await container.exec({
    Cmd: ['sh', '-c', command],
    AttachStdout: true,
    AttachStderr: true
  });
  
  const stream = await exec.start({ hijack: true, stdin: false });
  return new Promise((resolve, reject) => {
    let output = '';
    stream.on('data', chunk => output += chunk.toString());
    stream.on('end', () => resolve(output));
    stream.on('error', reject);
  });
}

module.exports = { createServer, listServers, serverAction, getStats, execCommand };