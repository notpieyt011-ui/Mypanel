require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: { origin: '*' }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/servers', require('./routes/servers'));
app.use('/api/users', require('./routes/users'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    uptime: process.uptime(),
    timestamp: Date.now()
  });
});

// WebSocket for real-time stats
io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  socket.on('subscribe', (serverId) => {
    socket.join(`server-${serverId}`);
  });

  socket.on('unsubscribe', (serverId) => {
    socket.leave(`server-${serverId}`);
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

app.set('io', io);

// Start server
const PORT = process.env.PORT || 3001;
server.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('╔══════════════════════════════════╗');
  console.log('║     🚀 Skyport Panel v2.0       ║');
  console.log(`║  Server: http://0.0.0.0:${PORT}    ║`);
  console.log('║  Login:  admin / admin123       ║');
  console.log('╚══════════════════════════════════╝');
  console.log('');
});